package com.abc.abcofficialapp;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterJogo extends RecyclerView.Adapter<AdapterJogo.MyViewHolder> {

    private Context context;
    private ArrayList<Jogo> jogoArrayList;

    public AdapterJogo(Context context, ArrayList<Jogo> jogoArrayList) {
        this.context = context;
        this.jogoArrayList = jogoArrayList;
    }

    @NonNull
    @Override
    public AdapterJogo.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_jogo, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Jogo jogo = jogoArrayList.get(position);



        holder.dataJogo.setText(jogo.getDia());
        holder.localJogo.setText(jogo.getLocal());
        holder.idEquipa.setText(jogo.getIdEquipa());
    }


    @Override
    public int getItemCount() {
        return jogoArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView dataJogo;
        TextView localJogo;
        TextView idEquipa;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            dataJogo = itemView.findViewById(R.id.dataCardJogo);
            localJogo = itemView.findViewById(R.id.localCardjogo);
            idEquipa = itemView.findViewById(R.id.equipaCardjogo);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Jogo jogo = jogoArrayList.get(getAdapterPosition());
            Intent intent = new Intent(context,EditarJogo.class);
            intent.putExtra("Jogo", (Parcelable) jogo);
            context.startActivity(intent);
        }
    }

}

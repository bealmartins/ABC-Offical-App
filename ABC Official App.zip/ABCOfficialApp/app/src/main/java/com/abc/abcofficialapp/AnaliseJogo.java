package com.abc.abcofficialapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AnaliseJogo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analise_jogo);
    }
}
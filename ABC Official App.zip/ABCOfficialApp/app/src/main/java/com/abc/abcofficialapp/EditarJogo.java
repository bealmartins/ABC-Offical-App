package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class EditarJogo extends AppCompatActivity {

    private EditText idequipa;
    private EditText nome;
    private EditText dia;
    private EditText hora;
    private EditText local;
    private EditText adversario;
    private EditText descr;
    private Button voltar;
    private Button analise;
    private Button remover;
    private Button guardar;
    private FirebaseFirestore db;
    private Jogo jogo;
    ImageButton imageButton111, imageButton112, imageButton113, imageButton114, imageButton115;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_jogo);

        idequipa = findViewById(R.id.editTextTextPersonName76);
        nome = findViewById(R.id.editTextTextPersonName77);
        dia = findViewById(R.id.editTextTextPersonName78);
        hora = findViewById(R.id.editTextTextPersonName79);
        local = findViewById(R.id.editTextTextPersonName80);
        adversario = findViewById(R.id.editTextTextPersonName81);
        descr = findViewById(R.id.editTextTextMultiLine3);
        voltar = findViewById(R.id.button53);
        analise = findViewById(R.id.button28);
        remover = findViewById(R.id.button23);
        guardar = findViewById(R.id.button40);
        jogo = (Jogo) getIntent().getSerializableExtra("Jogo");
        db = FirebaseFirestore.getInstance();

        idequipa.setText(jogo.getIdEquipa());
        nome.setText(jogo.getNome_jogo());
        dia.setText(jogo.getDia());
        hora.setText(jogo.getHora());
        local.setText(jogo.getLocal());
        adversario.setText(jogo.getAdversario());
        descr.setText(jogo.getDescricao());

        imageButton111 = findViewById(R.id.imageButton111);
        imageButton112 = findViewById(R.id.imageButton112);
        imageButton113 = findViewById(R.id.imageButton113);
        imageButton114 = findViewById(R.id.imageButton114);
        imageButton115 = findViewById(R.id.imageButton115);

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Id = idequipa.getText().toString().trim();
                String Nome = nome.getText().toString().trim();
                String Dia = dia.getText().toString().trim();
                String Hora = hora.getText().toString().trim();
                String Local = local.getText().toString().trim();
                String Adver = adversario.getText().toString().trim();
                String Descr = descr.getText().toString().trim();


                if(!hasValidationErrors(Id, Nome, Dia, Hora, Local, Adver, Descr)){
                    Jogo j = new Jogo(Id, Nome, Adver, Dia, Hora, Local, Descr);
                    DocumentReference dd = db.collection("Jogos").document(jogo.getId_jogo());
                    dd.update("Nome", nome.getText().toString());
                    dd.update("Data", dia.getText().toString());
                    dd.update("Hora", hora.getText().toString());
                    dd.update("Local", local.getText().toString());
                    dd.update("Adversario", adversario.getText().toString());
                    dd.update("Descricao", descr.getText().toString());
                    startActivity(new Intent(getApplicationContext(), Jogos.class));
                    finish();
                }
                //finish();
            }
        });

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        remover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.collection("Jogos").document(jogo.getId_jogo()).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(EditarJogo.this,"Jogo Removido!",Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                });
            }
        });

        analise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), AnaliseJogo.class));
            }
        });

        imageButton111.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });

        imageButton112.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton113.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton114.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton115.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });
    }
    private boolean hasValidationErrors(String id, String Id, String Nome, String Dia, String Hora, String Local, String Adver) {
        if (Id.isEmpty()) {
            idequipa.setError("Insira um Id");
            idequipa.requestFocus();
            return true;
        }
        if (Nome.isEmpty()) {
            nome.setError("Insira um Nome");
            nome.requestFocus();
            return true;
        }
        if (Dia.isEmpty()) {
            dia.setError("Insira um Dia");
            dia.requestFocus();
            return true;
        }
        if (Hora.isEmpty()) {
            hora.setError("Insira uma Hora");
            hora.requestFocus();
            return true;
        }
        if (Local.isEmpty()) {
            local.setError("Insira um Local");
            local.requestFocus();
            return true;
        }
        if (Adver.isEmpty()) {
            adversario.setError("Insira um Adversário");
            adversario.requestFocus();
            return true;
        }
        return false;
    }
}
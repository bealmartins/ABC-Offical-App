package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class EditarTreino extends AppCompatActivity {

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;
    private TreinoModel treinoModel;

    Button buttonEliminarTreino,buttonVoltarListarTreinos,buttonGuardarEditarTreino;
    EditText txtIdEditarTreino,txtDuracaoEditarTreino,txtEditarDiaTreino,txtEditarHoraTreino,txtEditarLocalTreino
            ,editTextTextMultiLine6;
    ImageButton imageButton116, imageButton117, imageButton118, imageButton119, imageButton120;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_treino);

        treinoModel = (TreinoModel) getIntent().getSerializableExtra("Treino");
        fAuth= FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        buttonEliminarTreino = findViewById(R.id.buttonEliminarTreino);
        buttonVoltarListarTreinos = findViewById(R.id.buttonVoltarListarTreinos);
        buttonGuardarEditarTreino = findViewById(R.id.buttonGuardarEditarTreino);
        txtIdEditarTreino = findViewById(R.id.txtIdEditarTreino);
        txtDuracaoEditarTreino = findViewById(R.id.txtDuracaoEditarTreino);
        txtEditarDiaTreino = findViewById(R.id.txtEditarDiaTreino);
        txtEditarHoraTreino = findViewById(R.id.txtEditarHoraTreino);
        txtEditarLocalTreino = findViewById(R.id.txtEditarLocalTreino);
        editTextTextMultiLine6 = findViewById(R.id.editTextTextMultiLine6);

        imageButton116 = findViewById(R.id.imageButton116);
        imageButton117 = findViewById(R.id.imageButton117);
        imageButton118 = findViewById(R.id.imageButton118);
        imageButton119 = findViewById(R.id.imageButton119);
        imageButton120 = findViewById(R.id.imageButton120);

        imageButton116.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });

        imageButton117.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton118.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton119.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton120.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        //Set das Inf:
        txtIdEditarTreino.setText(treinoModel.getId());
        DocumentReference dd = fStore.collection("Treinos").document(treinoModel.getId());
        dd.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                txtDuracaoEditarTreino.setText(documentSnapshot.getString("Duracao"));
                txtEditarDiaTreino.setText(documentSnapshot.getString("Data"));
                txtEditarHoraTreino.setText(documentSnapshot.getString("Hora"));
                txtEditarLocalTreino.setText(documentSnapshot.getString("Local"));
                editTextTextMultiLine6.setText(documentSnapshot.getString("Descricao"));
            }
        });

        findViewById(R.id.buttonGuardarEditarTreino).setOnClickListener((View.OnClickListener) this);
        findViewById(R.id.buttonEliminarTreino).setOnClickListener((View.OnClickListener) this);
    }


    private void updater() {
        String data = txtEditarDiaTreino.getText().toString();
        String duracao= txtDuracaoEditarTreino.getText().toString();
        String hora = txtEditarHoraTreino.getText().toString();
        String local = txtEditarLocalTreino.getText().toString();
        String desc = editTextTextMultiLine6.getText().toString();

        if(!hasValidationErrors(txtEditarDiaTreino.getText().toString()) && !hasValidationErrors(txtDuracaoEditarTreino.getText().toString()) && !hasValidationErrors(txtEditarHoraTreino.getText().toString()) && !hasValidationErrors(txtEditarLocalTreino.getText().toString()) && !hasValidationErrors(editTextTextMultiLine6.getText().toString())) {
            DocumentReference dd = fStore.collection("Treinos").document(treinoModel.getId());
            Map<String, Object> userInfo = new HashMap<>();
            userInfo.put("Data",data);
            userInfo.put("Duracao",duracao);
            userInfo.put("Hora",hora);
            userInfo.put("Local",local);
            userInfo.put("Descricao",desc);
            userInfo.put("IdTreinador", uid);
            dd.set(userInfo);
            Toast.makeText(EditarTreino.this, "Atualizado!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(EditarTreino.this,Treinos.class));

        }
    }

    private void deleteTreino(){
        fStore.collection("Treinos").document(treinoModel.getId()).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(EditarTreino.this,"Treinos Cancelado!!",Toast.LENGTH_SHORT).show();
                    finish();
                    startActivity(new Intent(EditarTreino.this,Treinos.class));
                }
            }
        });
    }

    private boolean hasValidationErrors(String d) {
        if (d.isEmpty()) {
            txtDuracaoEditarTreino.setError("Erro");
            txtDuracaoEditarTreino.requestFocus();
            return true;
        }
        if (d.isEmpty()) {
            txtEditarDiaTreino.setError("Erro");
            txtEditarDiaTreino.requestFocus();
            return true;
        }
        if (d.isEmpty()) {
            txtEditarHoraTreino.setError("Erro");
            txtEditarHoraTreino.requestFocus();
            return true;
        }
        if (d.isEmpty()) {
            txtEditarLocalTreino.setError("Erro");
            txtEditarLocalTreino.requestFocus();
            return true;
        }

        return false;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonGuardarEditarTreino:
                updater();
                break;
            case R.id.buttonEliminarTreino:
                AlertDialog.Builder builder= new AlertDialog.Builder(this);
                builder.setTitle("Tem certeza que quer cancelar?");
                builder.setMessage("Irá cancelar...");
                builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        deleteTreino();
                    }
                });
                builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                AlertDialog add = builder.create();
                add.show();
                break;
        }
    }
}
package com.abc.abcofficialapp;

public class Jogo {

    private String id_jogo;
    private String nome_jogo;
    private String adversario;
    private String dia;
    private String hora;
    private String local;
    private String descricao;
    private String idEquipa;

    public Jogo(String id_jogo, String nome_jogo, String adversario, String dia, String hora, String local, String descricao) {
        this.id_jogo = id_jogo;
        this.nome_jogo = nome_jogo;
        this.adversario = adversario;
        this.dia = dia;
        this.hora = hora;
        this.local = local;
        this.descricao = descricao;
    }

    public String getId_jogo() {
        return id_jogo;
    }

    public void setId_jogo(String id_jogo) {
        this.id_jogo = id_jogo;
    }

    public String getNome_jogo() {
        return nome_jogo;
    }

    public void setNome_jogo(String nome_jogo) {
        this.nome_jogo = nome_jogo;
    }

    public String getAdversario() {
        return adversario;
    }

    public void setAdversario(String adversario) {
        this.adversario = adversario;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getIdEquipa() {
        return idEquipa;
    }

    public void setIdEquipa(String idEquipa) {
        this.idEquipa = idEquipa;
    }
}

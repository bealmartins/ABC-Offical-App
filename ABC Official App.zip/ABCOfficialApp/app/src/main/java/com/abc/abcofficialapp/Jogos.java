package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class Jogos extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Jogo> jogoArrayList;
    AdapterJogo adapterJogo;
    FirebaseFirestore db;
    ProgressDialog progressDialog;
    Button adicionarJogo;
    ImageButton imageButton70, imageButton71, imageButton72, imageButton73, imageButton74;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jogos);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Fetching data...");
        progressDialog.show();

        recyclerView = findViewById(R.id.rvJogos);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();
        jogoArrayList = new ArrayList<Jogo>();
        adapterJogo = new AdapterJogo(Jogos.this, jogoArrayList);

        recyclerView.setAdapter(adapterJogo);

        imageButton70 = findViewById(R.id.imageButton70);
        imageButton71 = findViewById(R.id.imageButton117);
        imageButton72 = findViewById(R.id.imageButton118);
        imageButton73 = findViewById(R.id.imageButton119);
        imageButton74 = findViewById(R.id.imageButton120);

        adicionarJogo = findViewById(R.id.button17);
        adicionarJogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MarcarJogos.class));
                //finish();
            }
        });


        imageButton70.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton71.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton72.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton73.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton74.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        EventChangeListener();
    }

    private void EventChangeListener() {
        //db.collection("Jogos").orderBy("Local", Query.Direction.ASCENDING).addSnapshotListener(new EventListener<QuerySnapshot>() {
        db.collection("Jogos").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null){
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                    Log.e("Erro na BD", error.getMessage());
                    return;
                }
                for (DocumentChange dc : value.getDocumentChanges()){
                    if(dc.getType() == DocumentChange.Type.ADDED){
                        Jogo j = dc.getDocument().toObject(Jogo.class);
                        j.setId_jogo(dc.getDocument().getId());
                        jogoArrayList.add(j);
                    }

                    adapterJogo.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }
            }
        });
    }
}
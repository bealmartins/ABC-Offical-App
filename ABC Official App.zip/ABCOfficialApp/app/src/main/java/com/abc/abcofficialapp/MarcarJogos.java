package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class MarcarJogos extends AppCompatActivity {

    private EditText Id, Nome, Dia, Hora, Local, Adversario, Descricao;
    private Button guardar, voltarJogo;
    private HashMap<String, Object> lista;
    private FirebaseFirestore fStore;
    ImageButton imageButton106, imageButton107, imageButton108, imageButton109, imageButton110;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marcar_jogos);

        fStore = FirebaseFirestore.getInstance();
        Id = findViewById(R.id.id);
        Nome = findViewById(R.id.nome);
        Dia = findViewById(R.id.diaJogo);
        Hora = findViewById(R.id.horaJogo);
        Local = findViewById(R.id.localJogo);
        Adversario = findViewById(R.id.adversario);
        Descricao = findViewById(R.id.descricaoJogo);
        guardar = findViewById(R.id.guardar);
        voltarJogo = findViewById(R.id.voltarJogo);

        imageButton106 = findViewById(R.id.imageButton106);
        imageButton107 = findViewById(R.id.imageButton107);
        imageButton108 = findViewById(R.id.imageButton108);
        imageButton109 = findViewById(R.id.imageButton109);
        imageButton110 = findViewById(R.id.imageButton110);

        voltarJogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton106.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton107.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton108.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton109.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton110.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String id = Id.getText().toString();
                String nome = Nome.getText().toString();
                String dia = Dia.getText().toString();
                String hora = Hora.getText().toString();
                String local = Local.getText().toString();
                String adversario = Adversario.getText().toString();
                String descricao = Descricao.getText().toString();

                lista = new HashMap<>();
                lista.put("Id", id);
                lista.put("Nome", nome);
                lista.put("Dia", dia);
                lista.put("Hora", hora);
                lista.put("Local", local);
                lista.put("Adversario", adversario);
                lista.put("Descricao", descricao);

                fStore.collection("Jogos").add(lista).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(MarcarJogos.this, "Jogo adicionado com sucesso", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), Jogos.class));
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MarcarJogos.this, "Jogo não adicionado!!!!", Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });

    }
}
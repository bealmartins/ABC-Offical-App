package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class MenuAdministrador extends AppCompatActivity {

    private EditText numAtletas;
    private EditText numTreinadores;
    private EditText numEquipas;
    //private TextView numJogos;
    private EditText numVit;
    private EditText numEmp;
    private EditText numDerr;
    private int iTreinadores;
    private int iAtletas;
    //private int iJogos;
    private int iVitorias;
    private int iEmpates;
    private int iDerrotas;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference userRef = db.collection("Users");
    private CollectionReference jogosRef = db.collection("Jogos");
    private DocumentReference equipasRef = db.collection("Equipas").document("jA2TAwtdjbQuFTudid1d");
    ImageButton imageButton8, imageButton9, imageButton10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_administrador);

        numAtletas = findViewById(R.id.editTextNumber);
        numTreinadores = findViewById(R.id.editTextNumber2);
        numEquipas = findViewById(R.id.editTextNumber4);
        //numJogos = findViewById(R.id.textView78);
        numVit = findViewById(R.id.editTextNumber5);
        numEmp = findViewById(R.id.editTextNumber3);
        numDerr = findViewById(R.id.editTextNumber6);
        iAtletas = 0;
        iTreinadores = 0;
        //iJogos = 0;
        iVitorias = 0;
        iEmpates = 0;
        iDerrotas = 0;

        imageButton8 = findViewById(R.id.imageButton8);
        imageButton9 = findViewById(R.id.imageButton9);
        imageButton10 = findViewById(R.id.imageButton10);

        equipasRef.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                numEquipas.setText(Long.toString(documentSnapshot.getLong("IdEquipa")));
            }
        });

        userRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    for(QueryDocumentSnapshot document : task.getResult()){
                        if("1".equals(document.getString("isTreinador"))){
                            iTreinadores = iTreinadores + 1;
                        }
                        if("1".equals(document.getString("isAtleta"))){
                            iAtletas = iAtletas + 1;
                        }
                    }
                } else {
                    Toast.makeText(MenuAdministrador.this, "Documento não existe", Toast.LENGTH_SHORT).show();//pop-up de aviso
                }
                System.out.println("Número de treinadores: " + iTreinadores);
                numTreinadores.setText(String.valueOf(iTreinadores));
                numAtletas.setText(String.valueOf(iAtletas));
            }
        });

        jogosRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    for(QueryDocumentSnapshot document : task.getResult()){
                        if("1".equals(document.getString("IsVictory"))){
                            iVitorias = iVitorias + 1;
                        }
                        if("1".equals(document.getString("IsDraw"))){
                            iEmpates= iEmpates + 1;
                        }
                        if("1".equals(document.getString("IsDefeat"))){
                            iDerrotas= iDerrotas + 1;
                        }
                        //iJogos = iJogos + 1;
                    }
                } else {
                    Toast.makeText(MenuAdministrador.this, "Documento não existe", Toast.LENGTH_SHORT).show();//pop-up de aviso
                }
                //System.out.println("Número de atletas: " + iAtletas);
                //numJogos.setText(String.valueOf(iJogos));
                numVit.setText(String.valueOf(iVitorias));
                numEmp.setText(String.valueOf(iEmpates));
                numDerr.setText(String.valueOf(iDerrotas));
            }
        });

        imageButton8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAdministrador.class));
                finish();
            }
        });

        imageButton9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                finish();
            }
        });

        imageButton10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PagamentosAtleta.class));
                finish();
            }
        });
    }
}
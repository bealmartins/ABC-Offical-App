package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MenuAtleta extends AppCompatActivity {

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;
    String idequipa;
    String idtreinador;
    ProgressDialog progressDialog;


    ArrayList<String> listatreinos;
    ArrayList<Date> listatreinosDate;
    ArrayList<LocalDate> listatreinosLocalDates;

    ArrayList<String> listajogos;
    ArrayList<Date> listajogosDates;
    ArrayList<LocalDate> listajogosLocalDates;

    ArrayList<String> empates;
    ArrayList<String> vitorias;
    ArrayList<String> derrotas;


    EditText txtProxJogo,txtProxTreino,txtPerfDerotas,txtPerfEmpates,txtPerfVitorias;
    ImageButton imageButton0, imageButton6, imageButton31, imageButton7, imageButton13;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_atleta);

        txtProxJogo = findViewById(R.id.txtProxJogo);
        txtProxTreino = findViewById(R.id.txtProxTreino);
        txtPerfDerotas = findViewById(R.id.txtPerfDerotas);
        txtPerfEmpates= findViewById(R.id.txtPerfEmpates);
        txtPerfVitorias = findViewById(R.id.txtPerfVitorias);


        empates = new ArrayList<>();
        derrotas = new ArrayList<>();
        vitorias = new ArrayList<>();

        listajogos= new ArrayList<>();
        listajogosDates = new ArrayList<>();
        listajogosLocalDates = new ArrayList<>();

        listatreinos = new ArrayList<>();
        listatreinosDate = new ArrayList<>();
        listatreinosLocalDates = new ArrayList<>();

        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();
        fStore = FirebaseFirestore.getInstance();

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Procurando Dados!!....");
        progressDialog.show();

        imageButton0 = findViewById(R.id.imageButton0);
        imageButton6 = findViewById(R.id.imageButton6);
        imageButton31 = findViewById(R.id.imageButton31);
        imageButton7 = findViewById(R.id.imageButton7);
        imageButton13 = findViewById(R.id.imageButton13);


        //Ir buscar equipa do atleta:
        DocumentReference documentReference = fStore.collection("Users").document(uid);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                String ff = documentSnapshot.getString("IdEquipa").toString();
                idequipa = idequipa.copyValueOf(ff.toCharArray());
                atualizarjogos(idequipa);
                buscartreinador(idequipa);
            }
        });

        imageButton0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAtleta.class));
                finish();
            }
        });

        imageButton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilAtleta1.class));
                finish();
            }
        });

        imageButton31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), relatorioAtleta_at.class));
                finish();
            }
        });

        imageButton7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), VerJogos_at.class));
                finish();
            }
        });

        imageButton13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), verTreinos_at.class));
                finish();
            }
        });
    }

    public void buscartreinador(String id){
        fStore = FirebaseFirestore.getInstance();
        fStore.collection("Users").whereEqualTo("IdEquipa", id).whereEqualTo("isTreinador","1").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                    for(DocumentSnapshot d : list){
                        String cc = d.getId().toString();
                        idtreinador= idtreinador.copyValueOf(cc.toCharArray());
                        atualizarTreinos(idtreinador);
                        atualizarresultados(id);
                    }
                }

            }
        });

    }


    public void atualizarjogos(String eq){
        fStore = FirebaseFirestore.getInstance();
        fStore.collection("Jogos").whereEqualTo("IdEquipa", eq).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if (!queryDocumentSnapshots.isEmpty()) {
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for (int i = 0; i < list.size(); i++) {
                        String p = list.get(i).getString("Data");
                        listajogos.add(p);
                    }

                    for(int i =0;i<listajogos.size();i++){
                        Date s = null;
                        try {
                            s = new SimpleDateFormat("dd/MM/yyyy").parse(listajogos.get(i));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        listajogosDates.add(s);
                    }


                    for (int i = 0; i < listajogosDates.size(); i++) {
                        Date input = listajogosDates.get(i);
                        LocalDate date = input.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                        listajogosLocalDates.add(date);
                    }



                    LocalDate prox= listajogosLocalDates.get(0);
                    LocalDate currentDate= LocalDate.now();

                    for (int i = 1; i < listajogosLocalDates.size(); i++) {
                        if(prox.compareTo(currentDate)==0){
                            break;
                        }else if(prox.compareTo(listajogosLocalDates.get(i))>0){
                            prox=listajogosLocalDates.get(i);
                            // prox=listajogosLocalDates.get(i+1);
                        }
                    }
                    txtProxJogo.setText(prox.toString());

                }else{
                    txtProxJogo.setText("Não tem treinos marcados!!");
                }
            }
        });
    }

    public void atualizarTreinos(String trein){
        fStore = FirebaseFirestore.getInstance();
        fStore.collection("Treinos").whereEqualTo("IdTreinador", trein).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if (!queryDocumentSnapshots.isEmpty()) {
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for (int i = 0; i < list.size(); i++) {
                        String p = list.get(i).getString("Data");
                        listatreinos.add(p);
                    }

                    for(int i =0;i<listatreinos.size();i++){
                        Date g = null;
                        try {
                            g = new SimpleDateFormat("dd/MM/yyyy").parse(listatreinos.get(i));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        listatreinosDate.add(g);
                    }

                    for (int i = 0; i < listatreinosDate.size(); i++) {
                        Date input2 = listatreinosDate.get(i);
                        LocalDate date2 = input2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                        listatreinosLocalDates.add(date2);
                    }
                    txtProxTreino.setText(listatreinosLocalDates.get(0).toString());


                    LocalDate prox2= listatreinosLocalDates.get(0);
                    LocalDate currentDate2= LocalDate.now();

                    for (int i = 1; i < listatreinosLocalDates.size(); i++) {
                        if(prox2.compareTo(currentDate2)==0){
                            break;
                        }else if(prox2.compareTo(listatreinosLocalDates.get(i))>0){
                            prox2=listatreinosLocalDates.get(i);
                        }
                    }
                    txtProxTreino.setText(prox2.toString());

                }else{
                    txtProxTreino.setText("Não tem treinos marcados!!");
                }
            }

        });
    }

    public void atualizarresultados(String eq){
        fStore.collection("Jogos").whereEqualTo("IdEquipa", eq).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for (int i = 0; i < list.size(); i++) {
                        String d = list.get(i).getString("IsDefeat");
                        String e = list.get(i).getString("IsDraw");
                        String v = list.get(i).getString("IsVictory");
                        if(d.equals("0")){
                            if (e.equals("0")) {
                                vitorias.add(v);
                            }else{
                                empates.add(e);
                            }
                        }else{
                            derrotas.add(d);
                        }
                    }
                    int contadorVitorias=0;
                    int contadorDerrotas=0;
                    int contadorEmpates=0;

                    for(int i=0;i<vitorias.size();i++){
                        contadorVitorias++;
                    }
                    for(int i=0;i<derrotas.size();i++){
                        contadorDerrotas++;
                    }
                    for(int i=0;i<empates.size();i++){
                        contadorEmpates++;
                    }
                    txtPerfDerotas.setText(String.valueOf(contadorDerrotas));
                    txtPerfEmpates.setText(String.valueOf(contadorEmpates));
                    txtPerfVitorias.setText(String.valueOf(contadorVitorias));

                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }else{
                    txtPerfDerotas.setText("Ainda não ocorreram jogos");
                    txtPerfEmpates.setText("Ainda não ocorreram jogos");
                    txtPerfVitorias.setText("Ainda não ocorreram jogos");
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }
            }
        });
    }
}
package com.abc.abcofficialapp;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterAtletasTreinador extends RecyclerView.Adapter {

    private Context mCtx;
    private ArrayList<TreinAtletaModel> listaatletas;

    public MyAdapterAtletasTreinador(Context mCtx, ArrayList<TreinAtletaModel>listaatletas){
        this.mCtx=mCtx;
        this.listaatletas=listaatletas;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(mCtx).inflate(R.layout.item_listar_atlestas_treinador,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        TreinAtletaModel treinAtletaModel = listaatletas.get(position);
        holder.Nome.setText(treinAtletaModel.getNome());
        holder.Email.setText(treinAtletaModel.getEmail());
    }

    @Override
    public int getItemCount() {
        return listaatletas.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView Nome,Email;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Nome = itemView.findViewById(R.id.tAtlNome);
            Email = itemView.findViewById(R.id.tAtlEmail);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            TreinAtletaModel treinAtletaModel = listaatletas.get(getAdapterPosition());
            Intent intent = new Intent(mCtx,PerfilAtleta.class);
            intent.putExtra("AtletaD", (Parcelable) treinAtletaModel);
            mCtx.startActivity(intent);
        }
    }
}

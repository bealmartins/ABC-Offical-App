package com.abc.abcofficialapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterPagamentos extends RecyclerView.Adapter<MyAdapterPagamentos.MyViewHolder> {

    Context context;
    ArrayList<PagamentoModel> lista;

    public MyAdapterPagamentos(Context context, ArrayList<PagamentoModel> lista) {
        this.context = context;
        this.lista = lista;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_listar_atlestas_treinador, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        PagamentoModel pag = lista.get(position);
        holder.nomeP.setText(pag.getNomePag());
        holder.emailP.setText(pag.getEmailPag());
        holder.montanteP.setText(pag.getMontantePag());
        holder.estadoP.setText(pag.getEstadoPag());
        holder.dataP.setText(pag.getDataPag());
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public static class  MyViewHolder extends RecyclerView.ViewHolder{

        TextView nomeP, emailP, montanteP, estadoP, dataP;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            nomeP = itemView.findViewById(R.id.PagNome);
            emailP = itemView.findViewById(R.id.PagEmail);
            montanteP = itemView.findViewById(R.id.PagMontante);
            estadoP = itemView.findViewById(R.id.PagEstado);
            dataP = itemView.findViewById(R.id.PagData);
        }
    }
}


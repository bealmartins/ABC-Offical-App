package com.abc.abcofficialapp;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterTreinos extends RecyclerView.Adapter<MyAdapterTreinos.MyViewHolder>{

    private Context mCtx;
    private ArrayList<TreinoModel> listaTreinos;

    public MyAdapterTreinos(Context mCtx, ArrayList<TreinoModel> listaTreinos){
        this.mCtx=mCtx;
        this.listaTreinos=listaTreinos;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(mCtx).inflate(R.layout.item_list_treinos,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        TreinoModel treinoModel = listaTreinos.get(position);
        holder.Data.setText(treinoModel.getData());
    }

    @Override
    public int getItemCount() {
        return listaTreinos.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView Data;
        // public LinearLayout linearLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Data = itemView.findViewById(R.id.tData);
            //linearLayout = (LinearLayout) itemView.findViewById(R.id.linearLayout);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            TreinoModel treinoModel = listaTreinos.get(getAdapterPosition());
            Intent intent = new Intent(mCtx,EditarTreino.class);
            intent.putExtra("Treino", (Parcelable) treinoModel);
            mCtx.startActivity(intent);

        }
    }
}

package com.abc.abcofficialapp;

public class PagamentoModel {

    private String nomePag;
    private String emailPag;
    private String montantePag;
    private String estadoPag;
    private String dataPag;

    public PagamentoModel(String nomePag, String emailPag, String montantePag, String estadoPag, String dataPag) {
        this.nomePag = nomePag;
        this.emailPag = emailPag;
        this.montantePag = montantePag;
        this.estadoPag = estadoPag;
        this.dataPag = dataPag;
    }

    public String getNomePag() {
        return nomePag;
    }

    public void setNomePag(String nomePag) {
        this.nomePag = nomePag;
    }

    public String getEmailPag() {
        return emailPag;
    }

    public void setEmailPag(String emailPag) {
        this.emailPag = emailPag;
    }

    public String getMontantePag() {
        return montantePag;
    }

    public void setMontantePag(String montantePag) {
        this.montantePag = montantePag;
    }

    public String getEstadoPag() {
        return estadoPag;
    }

    public void setEstadoPag(String estadoPag) {
        this.estadoPag = estadoPag;
    }

    public String getDataPag() {
        return dataPag;
    }

    public void setDataPag(String dataPag) {
        this.dataPag = dataPag;
    }
}

package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class PagamentosAtleta extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<PagamentoModel> listaPagamentos;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    MyAdapterPagamentos myAdapter;
    ProgressDialog pg;
    String uid;
    String pag;
    ImageButton imageButton62, imageButton63, imageButton38;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamentos_atleta);


        recyclerView = findViewById(R.id.lista);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        imageButton62 = findViewById(R.id.imageButton62);
        imageButton63 = findViewById(R.id.imageButton63);
        imageButton38 = findViewById(R.id.imageButton38);

        DocumentReference documentReference = fStore.collection("Pagamentos").document(uid);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                String ff = documentSnapshot.getString("Nome").toString();
                pag = pag.copyValueOf(ff.toCharArray());
                atualizar(pag);
            }
        });

        listaPagamentos = new ArrayList<PagamentoModel>();
        myAdapter = new MyAdapterPagamentos(this, listaPagamentos);
        recyclerView.setAdapter(myAdapter);

        imageButton62.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAdministrador.class));
                finish();
            }
        });

        imageButton63.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                finish();
            }
        });

        imageButton38.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PagamentosAtleta.class));
                finish();
            }
        });


    }
    public void atualizar (String f){

        pg = new ProgressDialog(this);
        pg.setCancelable(false);
        pg.setMessage("A procurar dados...");
        pg.show();

        fStore.collection("Pagamentos").whereEqualTo("Nome", f).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if (!queryDocumentSnapshots.isEmpty()) {
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for (DocumentSnapshot d : list) {
                        PagamentoModel obj = d.toObject(PagamentoModel.class);
                        listaPagamentos.add(obj);
                    }
                    myAdapter.notifyDataSetChanged();
                    if (pg.isShowing())
                        pg.dismiss();
                }
            }
        });
    }

    public void btnCriarPagamento(View v){
        Intent i = new Intent(this, CriarPagamento.class);
        startActivity(i);
    }
}
package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class PerfilAtleta1 extends AppCompatActivity {

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    FirebaseUser uu;
    String uid;
    boolean valid = true;

    Button voltarAtleta, guardarAtleta;

    EditText textnome, textusername, textemail, texttelefone, textdata, textmorada, textescola,
            textgenero, textCC, textSNS, textIBAN, textpassword, textpeso, textaltura, textsangue;

    ImageButton menuAtleta, perfilAtleta, relatorioAtleta, jogosAtleta, treinosAtleta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_atleta1);

        voltarAtleta = findViewById(R.id.voltarAtleta);
        guardarAtleta = findViewById(R.id.guardarAtleta);
        guardarAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updater();
                atualizar();
            }
        });

        textnome = findViewById(R.id.textnome);
        textusername = findViewById(R.id.textusername);
        textemail = findViewById(R.id.textemail);
        texttelefone = findViewById(R.id.texttelefone);
        textdata = findViewById(R.id.textdata);
        textmorada = findViewById(R.id.textmorada);
        textescola = findViewById(R.id.textescola);
        textgenero = findViewById(R.id.textgenero);
        textCC = findViewById(R.id.textCC);
        textSNS = findViewById(R.id.textSNS);
        textIBAN = findViewById(R.id.textIBAN);
        textpassword = findViewById(R.id.textpassword);
        textpeso = findViewById(R.id.textpeso);
        textaltura = findViewById(R.id.textaltura);
        textsangue = findViewById(R.id.textsangue);

        menuAtleta = findViewById(R.id.imageButton39);
        perfilAtleta = findViewById(R.id.imageButton43);
        relatorioAtleta = findViewById(R.id.imageButton45);
        jogosAtleta = findViewById(R.id.imageButton46);
        treinosAtleta = findViewById(R.id.imageButton47);

        DocumentReference dc = fStore.collection("Users").document(uid);
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                textnome.setText(documentSnapshot.getString("Nome"));
                textusername.setText(documentSnapshot.getString("Username"));
                textemail.setText(documentSnapshot.getString("Email"));
                texttelefone.setText(documentSnapshot.getString("Telemovel"));
                textdata.setText(documentSnapshot.getString("Data Nascimento"));
                textmorada.setText(documentSnapshot.getString("Morada"));
                textescola.setText(documentSnapshot.getString("Escolaridade"));
                textgenero.setText(documentSnapshot.getString("Genero"));
                textCC.setText(documentSnapshot.getString("Cartão Cidadão"));
                textSNS.setText(documentSnapshot.getString("SNS"));
                textIBAN.setText(documentSnapshot.getString("IBAN"));
                textpassword.setText(documentSnapshot.getString("Password"));
                textpeso.setText(documentSnapshot.getString("Peso"));
                textaltura.setText(documentSnapshot.getString("Altura"));
                textsangue.setText(documentSnapshot.getString("Grupo Sanguineo"));
            }
        });

        menuAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAtleta.class));
                finish();
            }
        });

        perfilAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilAtleta1.class));
                finish();
            }
        });

        relatorioAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), relatorioAtleta_at.class));
                finish();
            }
        });

        jogosAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), VerJogos_at.class));
                finish();
            }
        });

        treinosAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), verTreinos_at.class));
                finish();
            }
        });


    }

    private void atualizar() {
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("Users").document(uid);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                textnome.setText(documentSnapshot.getString("Nome"));
                textusername.setText(documentSnapshot.getString("Username"));
                textemail.setText(documentSnapshot.getString("Email"));
                texttelefone.setText(documentSnapshot.getString("Telemovel"));
                textdata.setText(documentSnapshot.getString("Data Nascimento"));
                textmorada.setText(documentSnapshot.getString("Morada"));
                textescola.setText(documentSnapshot.getString("Escolaridade"));
                textgenero.setText(documentSnapshot.getString("Genero"));
                textCC.setText(documentSnapshot.getString("Cartão Cidadão"));
                textSNS.setText(documentSnapshot.getString("SNS"));
                textIBAN.setText(documentSnapshot.getString("IBAN"));
                textpassword.setText(documentSnapshot.getString("Password"));
                textpeso.setText(documentSnapshot.getString("Peso"));
                textaltura.setText(documentSnapshot.getString("Altura"));
                textsangue.setText(documentSnapshot.getString("Grupo Sanguineo"));
            }
        });
    }

    private void updater(){
        checkField(textnome);
        checkField(textusername);
        checkField(textemail);
        checkField(texttelefone);
        checkField(textdata);
        checkField(textmorada);
        checkField(textescola);
        checkField(textgenero);
        checkField(textCC);
        checkField(textSNS);
        checkField(textIBAN);
        checkField(textpeso);
        checkField(textaltura);
        checkField(textsangue);
        checkField(textpassword);


        if(valid) {

            String UPnome = textnome.getText().toString();
            String UPUsername = textusername.getText().toString();
            String UPEmail = textemail.getText().toString();
            String UpTelefone = texttelefone.getText().toString();
            String UpDataNasc = textdata.getText().toString();
            String UpMorada = textmorada.getText().toString();
            String UpGenero = textgenero.getText().toString();
            String UpEsc = textescola.getText().toString();
            String UpCC = textCC.getText().toString();
            String UpSNS = textSNS.getText().toString();
            String UpIBAN = textIBAN.getText().toString();
            String UpPeso = textpeso.getText().toString();
            String UpAltura = textaltura.getText().toString();
            String UpSangue = textsangue.getText().toString();
            String UpPass = textpassword.getText().toString();


            fAuth = FirebaseAuth.getInstance();
            fStore = FirebaseFirestore.getInstance();
            uid= fAuth.getCurrentUser().getUid();
            uu= fAuth.getCurrentUser();
            DocumentReference documentReference = fStore.collection("Users").document(uid);
            Map<String,Object> userInfo = new HashMap<>();
            userInfo.put("Nome", UPnome);
            userInfo.put("Username", UPUsername);
            userInfo.put("Email", UPEmail);
            userInfo.put("Password", UpPass);
            if(checkEmail(textemail)){
                uu.updateEmail(UPEmail);
            }
            uu.updatePassword(UpCC);
            userInfo.put("Telemovel", UpTelefone);
            userInfo.put("Data Nascimento", UpDataNasc);
            userInfo.put("Morada", UpMorada);
            userInfo.put("Cartão Cidadão", UpCC);
            userInfo.put("Genero", UpGenero);
            userInfo.put("IBAN", UpIBAN);
            userInfo.put("isAtleta", "1");
            userInfo.put("Escolaridade", UpEsc);
            userInfo.put("SNS", UpSNS);
            userInfo.put("Peso", UpPeso);
            userInfo.put("Altura", UpAltura);
            userInfo.put("Grupo Sanguineo", UpSangue);

            documentReference.set(userInfo);


            //startActivity(new Intent(getApplicationContext(), JanelaMenuAtleta.class));
            finish();
            Toast.makeText(PerfilAtleta1.this, "Informações Atualizadas", Toast.LENGTH_SHORT).show();


        }else{
            Toast.makeText(PerfilAtleta1.this, "Parâmetros vazios", Toast.LENGTH_SHORT).show();

        }


    }

    public boolean checkEmail(EditText textField){
        if(uu.getEmail() != textField.getText().toString()){
            return true;
        }else return false;

    }

    public boolean checkField(EditText textField){
        if(textField.getText().toString().isEmpty()){
            textField.setError("Error");
            valid = false;
        }else {
            valid = true;
        }

        return valid;
    }
}
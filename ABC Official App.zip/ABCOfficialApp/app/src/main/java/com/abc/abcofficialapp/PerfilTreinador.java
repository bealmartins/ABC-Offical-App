package com.abc.abcofficialapp;
//falta o botao remover

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class PerfilTreinador extends AppCompatActivity {

    EditText txtPerfilTreiNome,txtPerfilTreinUsername,txtPerfilTreinEmail,txtPerfilTreinTelefone,
            txtPerfilTreinDataNasc,txtPerfilTreinMorada,txtPerfilTreinNCC,txtPerfilTreinIBAN,txtPerfilTreinPassword,
            txtPerfilTreinGenero;

    Button buttonPerfilTreinGuardar, voltar, remover;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;
    boolean valid = true;
    FirebaseUser uu;

    ImageButton imageButton36, imageButton35, imageButton34;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_treinador);

        imageButton36 = findViewById(R.id.imageButton36);
        imageButton36.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAdministrador.class));
                finish();
            }
        });
        imageButton35 = findViewById(R.id.imageButton35);
        imageButton35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                finish();
            }
        });

        imageButton34 = findViewById(R.id.imageButton34);
        imageButton34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PagamentosAtleta.class));
                finish();
            }
        });


        buttonPerfilTreinGuardar = findViewById(R.id.buttonPerfilAtletaGuardar);
        remover = findViewById(R.id.remover);
        voltar = findViewById(R.id.voltarPerfil);
        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAdministrador.class));
                finish();
            }
        });

        txtPerfilTreiNome = findViewById(R.id.txtPerfilTreiNome);
        txtPerfilTreinUsername = findViewById(R.id.txtPerfilTreinUsername);
        txtPerfilTreinEmail = findViewById(R.id.txtPerfilTreinEmail);
        txtPerfilTreinTelefone = findViewById(R.id.txtPerfilTreinTelefone);
        txtPerfilTreinDataNasc = findViewById(R.id.txtPerfilTreinDataNasc);
        txtPerfilTreinMorada = findViewById(R.id.txtPerfilTreinMorada);
        txtPerfilTreinNCC = findViewById(R.id.txtPerfilTreinNCC);
        txtPerfilTreinIBAN = findViewById(R.id.txtPerfilTreinIBAN);
        txtPerfilTreinPassword = findViewById(R.id.txtPerfilTreinPassword);
        txtPerfilTreinGenero = findViewById(R.id.txtPerfilTreinGenero);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid= fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("Users").document(uid);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                txtPerfilTreiNome.setText(documentSnapshot.getString("Nome"));
                txtPerfilTreinUsername.setText(documentSnapshot.getString("Username"));
                txtPerfilTreinEmail.setText(documentSnapshot.getString("Email"));
                txtPerfilTreinTelefone.setText(documentSnapshot.getString("Telemovel"));
                txtPerfilTreinDataNasc.setText(documentSnapshot.getString("Data Nascimento"));
                txtPerfilTreinMorada.setText(documentSnapshot.getString("Morada"));
                txtPerfilTreinGenero.setText(documentSnapshot.getString("Genero"));
                txtPerfilTreinNCC.setText(documentSnapshot.getString("Cartão Cidadão"));
                txtPerfilTreinIBAN.setText(documentSnapshot.getString("IBAN"));
                txtPerfilTreinPassword.setText(documentSnapshot.getString("Password"));
            }
        });

        buttonPerfilTreinGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updater();
                atualizar();
            }
        });
    }


    private void atualizar(){
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid= fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("Users").document(uid);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                txtPerfilTreiNome.setText(documentSnapshot.getString("Nome"));
                txtPerfilTreinUsername.setText(documentSnapshot.getString("Username"));
                txtPerfilTreinEmail.setText(documentSnapshot.getString("Email"));
                txtPerfilTreinTelefone.setText(documentSnapshot.getString("Telemovel"));
                txtPerfilTreinDataNasc.setText(documentSnapshot.getString("Data Nascimento"));
                txtPerfilTreinMorada.setText(documentSnapshot.getString("Morada"));
                txtPerfilTreinGenero.setText(documentSnapshot.getString("Genero"));
                txtPerfilTreinNCC.setText(documentSnapshot.getString("Cartão Cidadão"));
                txtPerfilTreinIBAN.setText(documentSnapshot.getString("IBAN"));
                txtPerfilTreinPassword.setText(documentSnapshot.getString("Password"));

            }
        });
    }


    private void updater(){
        checkField(txtPerfilTreiNome);
        checkField(txtPerfilTreinUsername);
        checkField(txtPerfilTreinEmail);
        checkField(txtPerfilTreinTelefone);
        checkField(txtPerfilTreinDataNasc);
        checkField(txtPerfilTreinMorada);
        checkField(txtPerfilTreinGenero);
        checkField(txtPerfilTreinNCC);
        checkField(txtPerfilTreinIBAN);
        checkField(txtPerfilTreinPassword);

        if(valid) {

            String UPnome = txtPerfilTreiNome.getText().toString();
            String UPUsername = txtPerfilTreinUsername.getText().toString();
            String UPEmail = txtPerfilTreinEmail.getText().toString();
            String UpTelefone = txtPerfilTreinTelefone.getText().toString();
            String UpDataNasc = txtPerfilTreinDataNasc.getText().toString();
            String UpMorada = txtPerfilTreinMorada.getText().toString();
            String UpGenero = txtPerfilTreinGenero.getText().toString();
            String UpNcc = txtPerfilTreinNCC.getText().toString();
            String UpIBAN = txtPerfilTreinIBAN.getText().toString();
            String UpPass = txtPerfilTreinPassword.getText().toString();


            fAuth = FirebaseAuth.getInstance();
            fStore = FirebaseFirestore.getInstance();
            uid= fAuth.getCurrentUser().getUid();
            uu= fAuth.getCurrentUser();
            DocumentReference documentReference = fStore.collection("Users").document(uid);
            Map<String,Object> userInfo = new HashMap<>();
            userInfo.put("Nome", UPnome);
            userInfo.put("Username", UPUsername);
            userInfo.put("Email", UPEmail);
            userInfo.put("Password", UpPass);
            if(checkEmail(txtPerfilTreinEmail)){
                uu.updateEmail(UPEmail);
            }
            uu.updatePassword(UpPass);

            userInfo.put("Telemovel", UpTelefone);
            userInfo.put("Data Nascimento", UpDataNasc);
            userInfo.put("Genero", UpGenero);
            userInfo.put("Cartão Cidadão", UpNcc);
            userInfo.put("IBAN", UpIBAN);
            userInfo.put("Morada", UpMorada);
            userInfo.put("isTreinador", "1");


            documentReference.set(userInfo);


            startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
            finish();
            Toast.makeText(PerfilTreinador.this, "Informações Atualizadas!!", Toast.LENGTH_SHORT).show();


        }else{
            Toast.makeText(PerfilTreinador.this, "Parâmetros vazios!!", Toast.LENGTH_SHORT).show();

        }


    }

    public boolean checkEmail(EditText textField){
        if(uu.getEmail() != textField.getText().toString()){
            return true;
        }else return false;

    }

    public boolean checkField(EditText textField){
        if(textField.getText().toString().isEmpty()){
            textField.setError("Error");
            valid = false;
        }else {
            valid = true;
        }

        return valid;
    }

}
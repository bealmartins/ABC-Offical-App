package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class PerfilTreinador1 extends AppCompatActivity {

    EditText txtPerfilTreinNome, txtPerfilTreinUsername, txtPerfilTreinEmail, txtPerfilTreinTelefone,
            txtPerfilTreinDataNasc, txtPerfilTreinMorada, txtPerfilTreinNcc, txtPerfilTreinIBAN, txtPerfilTreinPassword, txtPerfilTreinGenero;

    Button buttonPerfilTreinGuardar, buttonPerfilTreinVoltar;
    ImageButton imageButton44, imageButton49, imageButton50, imageButton51, imageButton52;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    FirebaseUser uu;
    String uid;
    boolean valid = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_treinador1);

        imageButton44 = findViewById(R.id.imageButton44);
        imageButton49 = findViewById(R.id.imageButton49);
        imageButton50 = findViewById(R.id.imageButton50);
        imageButton51 = findViewById(R.id.imageButton51);
        imageButton52 = findViewById(R.id.imageButton52);

        imageButton44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton49.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton50.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        txtPerfilTreinNome = findViewById(R.id.editTextTextPersonName61);
        txtPerfilTreinUsername = findViewById(R.id.editTextTextPersonName62);
        txtPerfilTreinEmail = findViewById(R.id.editTextTextPersonName63);
        txtPerfilTreinTelefone = findViewById(R.id.editTextTextPersonName64);
        txtPerfilTreinDataNasc = findViewById(R.id.editTextTextPersonName65);
        txtPerfilTreinMorada = findViewById(R.id.editTextTextPersonName66);
        txtPerfilTreinNcc = findViewById(R.id.editTextTextPersonName67);
        txtPerfilTreinIBAN = findViewById(R.id.editTextTextPersonName68);
        txtPerfilTreinPassword = findViewById(R.id.password7);
        txtPerfilTreinGenero = findViewById(R.id.genero);

        buttonPerfilTreinGuardar = findViewById(R.id.button15);
        buttonPerfilTreinVoltar = findViewById(R.id.button16);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid= fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("Users").document(uid);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                txtPerfilTreinNome.setText(documentSnapshot.getString("Nome"));
                txtPerfilTreinUsername.setText(documentSnapshot.getString("Username"));
                txtPerfilTreinEmail.setText(documentSnapshot.getString("Email"));
                txtPerfilTreinTelefone.setText(documentSnapshot.getString("Telemovel"));
                txtPerfilTreinDataNasc.setText(documentSnapshot.getString("Data Nascimento"));
                txtPerfilTreinMorada.setText(documentSnapshot.getString("Morada"));
                txtPerfilTreinGenero.setText(documentSnapshot.getString("Genero"));
                txtPerfilTreinNcc.setText(documentSnapshot.getString("Cartão Cidadão"));
                txtPerfilTreinIBAN.setText(documentSnapshot.getString("IBAN"));
                txtPerfilTreinPassword.setText(documentSnapshot.getString("Password"));
            }
        });

        buttonPerfilTreinGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updater();
                atualizar();
            }
        });

        buttonPerfilTreinVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void atualizar() {
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("Users").document(uid);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                txtPerfilTreinNome.setText(documentSnapshot.getString("Nome"));
                txtPerfilTreinUsername.setText(documentSnapshot.getString("Username"));
                txtPerfilTreinEmail.setText(documentSnapshot.getString("Email"));
                txtPerfilTreinTelefone.setText(documentSnapshot.getString("Telemovel"));
                txtPerfilTreinDataNasc.setText(documentSnapshot.getString("Data Nascimento"));
                txtPerfilTreinMorada.setText(documentSnapshot.getString("Morada"));
                txtPerfilTreinGenero.setText(documentSnapshot.getString("Genero"));
                txtPerfilTreinNcc.setText(documentSnapshot.getString("Cartão Cidadão"));
                txtPerfilTreinIBAN.setText(documentSnapshot.getString("IBAN"));
                txtPerfilTreinPassword.setText(documentSnapshot.getString("Password"));
            }
        });
    }

    private void updater(){
        checkField(txtPerfilTreinNome);
        checkField(txtPerfilTreinUsername);
        checkField(txtPerfilTreinEmail);
        checkField(txtPerfilTreinTelefone);
        checkField(txtPerfilTreinDataNasc);
        checkField(txtPerfilTreinMorada);
        checkField(txtPerfilTreinGenero);
        checkField(txtPerfilTreinNcc);
        checkField(txtPerfilTreinIBAN);
        checkField(txtPerfilTreinPassword);

        if(valid) {

            String UPnome = txtPerfilTreinNome.getText().toString();
            String UPUsername = txtPerfilTreinUsername.getText().toString();
            String UPEmail = txtPerfilTreinEmail.getText().toString();
            String UpTelefone = txtPerfilTreinTelefone.getText().toString();
            String UpDataNasc = txtPerfilTreinDataNasc.getText().toString();
            String UpMorada = txtPerfilTreinMorada.getText().toString();
            String UpGenero = txtPerfilTreinGenero.getText().toString();
            String UpNcc = txtPerfilTreinNcc.getText().toString();
            String UpIBAN = txtPerfilTreinIBAN.getText().toString();
            String UpPass = txtPerfilTreinPassword.getText().toString();

            fAuth = FirebaseAuth.getInstance();
            fStore = FirebaseFirestore.getInstance();
            uid= fAuth.getCurrentUser().getUid();
            uu= fAuth.getCurrentUser();
            DocumentReference documentReference = fStore.collection("Users").document(uid);
            Map<String,Object> userInfo = new HashMap<>();
            userInfo.put("Nome", UPnome);
            userInfo.put("Username", UPUsername);
            userInfo.put("Email", UPEmail);
            userInfo.put("Password", UpPass);
            if(checkEmail(txtPerfilTreinEmail)){
                uu.updateEmail(UPEmail);
            }
            uu.updatePassword(UpPass);
            userInfo.put("Telemovel", UpTelefone);
            userInfo.put("Data Nascimento", UpDataNasc);
            userInfo.put("Morada", UpMorada);
            userInfo.put("Cartão Cidadão", UpNcc);
            userInfo.put("Genero", UpGenero);
            userInfo.put("IBAN", UpIBAN);
            userInfo.put("istreinador", "1");


            documentReference.set(userInfo);


            //startActivity(new Intent(getApplicationContext(), JanelaMenuAtleta.class));
            finish();
            Toast.makeText(PerfilTreinador1.this, "Informações Atualizadas", Toast.LENGTH_SHORT).show();


        }else{
            Toast.makeText(PerfilTreinador1.this, "Parâmetros vazios", Toast.LENGTH_SHORT).show();

        }


    }

    public boolean checkEmail(EditText textField){
        if(uu.getEmail() != textField.getText().toString()){
            return true;
        }else return false;

    }

    public boolean checkField(EditText textField){
        if(textField.getText().toString().isEmpty()){
            textField.setError("Error");
            valid = false;
        }else {
            valid = true;
        }

        return valid;
    }
}
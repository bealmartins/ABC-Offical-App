package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class RegistoAtleta extends AppCompatActivity {

    EditText txtRegNome,txtRegUsername,txtRegEmail,txtRegTelefone,txtRegDataNasc,txtRegMorada,
            txtRegEscolaridade,txtRegGenero,txtRegNCC,txtRegSNS,txtRegIBAN,txtRegPassword,txtRegPeso,txtRegAltura,txtRegSangue;

    Button buttonGuardarAtleta;
    ImageButton imageButton19, imageButton20, imageButton21, imageButton22, imageButton23;

    boolean valid = true;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    FirebaseUser user;
    private String global;
    String uid;

    DatePickerDialog.OnDateSetListener setListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registo_atleta);

        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();
        fStore = FirebaseFirestore.getInstance();

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        buttonGuardarAtleta = findViewById(R.id.buttonGuardarAtleta);
        txtRegNome = findViewById(R.id.txtRegNome);
        txtRegUsername = findViewById(R.id.txtRegUsername);
        txtRegEmail = findViewById(R.id.txtRegEmail);
        txtRegTelefone = findViewById(R.id.txtRegTelefone);
        txtRegDataNasc = findViewById(R.id.txtRegDataNasc);
        txtRegMorada = findViewById(R.id.txtRegMorada);
        txtRegEscolaridade = findViewById(R.id.txtRegEscolaridade);
        txtRegGenero = findViewById(R.id.txtRegGenero);
        txtRegNCC = findViewById(R.id.txtRegNCC);
        txtRegSNS = findViewById(R.id.txtRegSNS);
        txtRegIBAN = findViewById(R.id.txtRegIBAN);
        txtRegPassword = findViewById(R.id.txtRegPassword);
        txtRegPeso = findViewById(R.id.txtRegPeso);
        txtRegAltura= findViewById(R.id.txtRegAltura);
        txtRegSangue = findViewById(R.id.txtRegSangue);
        global="";


        imageButton19 = findViewById(R.id.imageButton19);
        imageButton20 = findViewById(R.id.imageButton20);
        imageButton21 = findViewById(R.id.imageButton21);
        imageButton22 = findViewById(R.id.imageButton22);
        imageButton23 = findViewById(R.id.imageButton23);

        DocumentReference dc = fStore.collection("Users").document(uid);
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                String jj = documentSnapshot.getString("IdEquipa");
                global = global.copyValueOf(jj.toCharArray());
            }
        });

        /*txtRegDataNasc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(RegistoAtleta.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth
                        ,setListener,year,month,day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });*/

        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                String date = day+"/"+month+"/"+year;
                txtRegDataNasc.setText(date);
            }
        };

        txtRegDataNasc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(RegistoAtleta.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        txtRegDataNasc.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });



        buttonGuardarAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkField(txtRegNome);
                checkField(txtRegUsername);
                checkField(txtRegEmail);
                checkField(txtRegTelefone);
                checkField(txtRegDataNasc);
                checkField(txtRegMorada);
                checkField(txtRegEscolaridade);
                checkField(txtRegGenero);
                checkField(txtRegNCC);
                checkField(txtRegSNS);
                checkField(txtRegIBAN);
                checkField(txtRegPassword);
                checkField(txtRegPeso);
                checkField(txtRegAltura);
                checkField(txtRegSangue);

                if (valid) {
                    fAuth.createUserWithEmailAndPassword(txtRegEmail.getText().toString(), txtRegPassword.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {

                            user = fAuth.getCurrentUser();
                            Toast.makeText(RegistoAtleta.this, "Account created", Toast.LENGTH_SHORT).show();
                            DocumentReference df = fStore.collection("Users").document(user.getUid());
                            Map<String, Object> userInfo = new HashMap<>();
                            userInfo.put("Nome", txtRegNome.getText().toString());
                            userInfo.put("Username", txtRegUsername.getText().toString());
                            userInfo.put("Email", txtRegEmail.getText().toString());
                            userInfo.put("Password", txtRegPassword.getText().toString());
                            userInfo.put("Telemovel", txtRegTelefone.getText().toString());
                            userInfo.put("Data Nascimento", txtRegDataNasc.getText().toString());
                            userInfo.put("Morada", txtRegMorada.getText().toString());
                            userInfo.put("Escolaridade", txtRegEscolaridade.getText().toString());
                            userInfo.put("Cartão Cidadão", txtRegNCC.getText().toString());
                            userInfo.put("Genero", txtRegGenero.getText().toString());
                            userInfo.put("SNS", txtRegSNS.getText().toString());
                            userInfo.put("IBAN", txtRegIBAN.getText().toString());
                            userInfo.put("Peso", txtRegPeso.getText().toString());
                            userInfo.put("Altura", txtRegAltura.getText().toString());
                            userInfo.put("Grupo Sanguineo", txtRegSangue.getText().toString());
                            userInfo.put("Relatorio", "");
                            // userInfo.put("isDeleted", "0");


                            userInfo.put("GolosM", "0");
                            userInfo.put("GolosS", "0");
                            userInfo.put("Remates", "0");
                            userInfo.put("FaltasC", "0");
                            userInfo.put("FaltasS", "0");
                            userInfo.put("Defesas", "0");
                            userInfo.put("Total Jogos", "0");

                            userInfo.put("isAtleta", "1");
                            userInfo.put("IdEquipa", global);
                            df.set(userInfo);

                            startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(RegistoAtleta.this, "Failed to create", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        });

        imageButton19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });
    }



    public boolean checkField(EditText textField) {
        if (textField.getText().toString().isEmpty()) {
            textField.setError("Error");
            valid = false;
        } else {
            valid = true;
        }

        return valid;
    }
}
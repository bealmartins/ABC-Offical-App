package com.abc.abcofficialapp;

import com.google.firebase.firestore.Exclude;

public class TreinAtletaModel {

    @Exclude
    private String id;

    private String Nome;
    private String Email;

    public TreinAtletaModel(){}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}

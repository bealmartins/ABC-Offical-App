package com.abc.abcofficialapp;

import com.google.firebase.firestore.Exclude;

public class TreinoModel {
    @Exclude
    private String id;
    private String Data;


    public TreinoModel(){}


    public TreinoModel(String Data){
        this.Data=Data;
    }

    public String getData() {
        return Data;
    }

    public void setData(String data) {
        Data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}

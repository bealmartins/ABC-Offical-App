package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class VerJogos_at extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Jogo> jogoArrayList;
    AdapterJogo adapterJogo;
    FirebaseFirestore db;
    ProgressDialog progressDialog;
    Button adicionarJogo;
    ImageButton imageButton91, imageButton92, imageButton93, imageButton94, imageButton95;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_jogos_at);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Fetching data...");
        progressDialog.show();

        recyclerView = findViewById(R.id.rvJogos);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();
        jogoArrayList = new ArrayList<Jogo>();
        adapterJogo = new AdapterJogo(VerJogos_at.this, jogoArrayList);

        recyclerView.setAdapter(adapterJogo);

        imageButton91 = findViewById(R.id.imageButton91);
        imageButton92 = findViewById(R.id.imageButton92);
        imageButton93 = findViewById(R.id.imageButton93);
        imageButton94 = findViewById(R.id.imageButton94);
        imageButton95 = findViewById(R.id.imageButton95);

        adicionarJogo = findViewById(R.id.button17);
        adicionarJogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MarcarJogos.class));
                //finish();
            }
        });

        EventChangeListener();
    }

    private void EventChangeListener() {
        //db.collection("Jogos").orderBy("Local", Query.Direction.ASCENDING).addSnapshotListener(new EventListener<QuerySnapshot>() {
        db.collection("Jogos").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null){
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                    Log.e("Erro na BD", error.getMessage());
                    return;
                }
                for (DocumentChange dc : value.getDocumentChanges()){
                    if(dc.getType() == DocumentChange.Type.ADDED){
                        Jogo j = dc.getDocument().toObject(Jogo.class);
                        j.setId_jogo(dc.getDocument().getId());
                        jogoArrayList.add(j);
                    }

                    adapterJogo.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }
            }
        });
    }
}
package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class relatorioAtleta_at extends AppCompatActivity {

    private EditText numJogos;
    private EditText GolosM;
    private EditText GolosS;
    private EditText Remates;
    private EditText FaltasC;
    private EditText FaltasS;
    private EditText Defesas;
    private DocumentReference sauceA;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;

    ImageButton imageButton81, imageButton82, imageButton83, imageButton84, imageButton85;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relatorio_atleta_at);

        numJogos = findViewById(R.id.editTextNumber25);
        GolosM = findViewById(R.id.editTextNumber26);
        GolosS = findViewById(R.id.editTextNumber27);
        Remates = findViewById(R.id.editTextNumber28);
        FaltasC = findViewById(R.id.editTextNumber29);
        FaltasS = findViewById(R.id.editTextNumber30);
        Defesas = findViewById(R.id.editTextNumber31);

        fAuth = FirebaseAuth.getInstance();
        uid = fAuth.getCurrentUser().getUid();
        fStore = FirebaseFirestore.getInstance();
        sauceA = fStore.collection("Users").document(uid);

        imageButton81 = findViewById(R.id.imageButton81);
        imageButton82 = findViewById(R.id.imageButton82);
        imageButton83 = findViewById(R.id.imageButton83);
        imageButton84 = findViewById(R.id.imageButton84);
        imageButton85 = findViewById(R.id.imageButton85);

        sauceA.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                //numJogos.setText(documentSnapshot.getString("Total Jogos"));
                GolosM.setText(documentSnapshot.getString("GolosM"));
                GolosS.setText(documentSnapshot.getString("GolosS"));
                Remates.setText(documentSnapshot.getString("Remates"));
                FaltasC.setText(documentSnapshot.getString("FaltasC"));
                FaltasS.setText(documentSnapshot.getString("FaltasS"));
                Defesas.setText(documentSnapshot.getString("Defesas"));
            }
        });


        imageButton81.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAtleta.class));
                finish();
            }
        });

        imageButton82.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilAtleta1.class));
                finish();
            }
        });

        imageButton83.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), relatorioAtleta_at.class));
                finish();
            }
        });

        imageButton84.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), VerJogos_at.class));
                finish();
            }
        });

        imageButton85.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), verTreinos_at.class));
                finish();
            }
        });
    }
}
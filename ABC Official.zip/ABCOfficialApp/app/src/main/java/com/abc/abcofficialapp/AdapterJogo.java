package com.abc.abcofficialapp;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.Serializable;
import java.util.ArrayList;

public class AdapterJogo extends RecyclerView.Adapter<AdapterJogo.MyViewHolder> {
        private Context context;
        private ArrayList<Jogo> jogoArrayList;

    public AdapterJogo(Context context, ArrayList<Jogo> jogoArrayList) {
        this.context = context;
        this.jogoArrayList = jogoArrayList;
    }

    @NonNull
    @Override
    public AdapterJogo.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_jogo, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Jogo jogo = jogoArrayList.get(position);

        holder.dataJogo.setText(jogo.getDia());
        holder.localJogo.setText(jogo.getLocal());
        holder.hora.setText(jogo.getHora());
    }


    @Override
    public int getItemCount() {
        return jogoArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView dataJogo;
        TextView localJogo;
        TextView hora;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            dataJogo = itemView.findViewById(R.id.dataCardJogo);
            localJogo = itemView.findViewById(R.id.localCardjogo);
            hora = itemView.findViewById(R.id.HoraCardjogo);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            FirebaseAuth fAuth;
            fAuth = FirebaseAuth.getInstance();
            FirebaseFirestore fStore;
            fStore = FirebaseFirestore.getInstance();

            String uid = fAuth.getCurrentUser().getUid();

            DocumentReference df = fStore.collection("Users").document(uid);
            df.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                @Override
                public void onSuccess(DocumentSnapshot documentSnapshot) {
                    Log.d("TAG", "onSucess: " + documentSnapshot.getData());

                    //Identificar user access level
                    if (documentSnapshot.getString("isAtleta") != null) {


                    } else if (documentSnapshot.getString("isTreinador") != null) {
                        Jogo jogo = jogoArrayList.get(getAdapterPosition());
                        Intent intent = new Intent(context, EditarJogo.class);
                        intent.putExtra("JogoD", jogo);
                        intent.putExtra("JogoID", jogo.getId_jogo());
                        context.startActivity(intent);

                    }
                }
            });


          /*  Jogo jogo = jogoArrayList.get(getAdapterPosition());
            Intent intent = new Intent(context,EditarJogo.class);
            intent.putExtra("JogoD", jogo);
            context.startActivity(intent);*/
        }
    }


}

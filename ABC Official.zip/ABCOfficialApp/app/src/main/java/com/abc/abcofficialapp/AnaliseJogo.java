package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.core.Tag;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AnaliseJogo extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Button registarmarcado, registarSofrido, terminar, b_6metros, b_7metros, b_9metros, b_ca,
            B1A, B1B, B1C, B1D, B1E, B1F, B1G, B1H, B1I,
            B2A, B2B, B2C, B2D, B2E, B2F, B2G, B2H, B2I;

    ImageButton menu, perfil, treinos, jogos, atletas;

    Spinner S1, S2;

    TextView metros, balizaadv, balizaabc;
    FirebaseFirestore db;
    FirebaseAuth fAuth;

    ArrayList<String> lista = new ArrayList<>();

    ArrayList<String> lista2 = new ArrayList<>();



    String uid;
    String idEquipa;
    String docId;
    String idjogo;


    int golosSofridos = 0;
    int golosMarcados = 0;

    ArrayList<SpinnerAtletasModel> listaAtletas;

    ArrayList<SpinnerAtletasModel> listaGuardaRedes;

    SpinnerAtletasModel Filipe = new SpinnerAtletasModel();
    SpinnerAtletasModel Joao = new SpinnerAtletasModel();

    String atletaSelecionado;
    String guardaRedesSel;
    String posicao;
    String local_baliza;


    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analise_jogo);

        db = FirebaseFirestore.getInstance();

        idjogo = (String) getIntent().getSerializableExtra("JogoID");


        fAuth = FirebaseAuth.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        S1 = findViewById(R.id.spinner);
        S1.setOnItemSelectedListener(this);


        db.collection("Users").whereEqualTo("isAtleta", "1").whereEqualTo("isGuardaRedes", "0").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                for (QueryDocumentSnapshot document : task.getResult() ){
                    Map<String,Object> atleta = document.getData();
                    System.out.println(atleta.get("Nome"));
                    lista.add(atleta.get("Nome").toString());

                }
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(AnaliseJogo.this, android.R.layout.simple_spinner_item, lista);
                arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                S1.setAdapter(arrayAdapter);
            }
        });

        S2 = findViewById(R.id.spinner2);
        S2.setOnItemSelectedListener(this);

        db.collection("Users").whereEqualTo("isAtleta", "1").whereEqualTo("isGuardaRedes", "1").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                for(QueryDocumentSnapshot document : task.getResult()){
                    Map<String, Object> guardaredes = document.getData();
                    lista2.add(guardaredes.get("Nome").toString());
                }
                ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<>(AnaliseJogo.this, android.R.layout.simple_spinner_item, lista2);
                arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                S2.setAdapter(arrayAdapter2);
            }
        });

        menu = findViewById(R.id.imageButton66);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });

        perfil = findViewById(R.id.imageButton67);
        perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        treinos = findViewById(R.id.imageButton68);
        treinos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        jogos = findViewById(R.id.imageButton69);
        jogos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        atletas = findViewById(R.id.imageButton75);
        atletas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        registarmarcado = findViewById(R.id.button8);
        registarmarcado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registoGoloMarc();
            }
        });

        registarSofrido = findViewById(R.id.button5000);
        registarSofrido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registoGoloSof();
            }
        });
        terminar = findViewById(R.id.button21);
        terminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("entra aqui para terminar");
                AlertDialog.Builder builder = new AlertDialog.Builder(AnaliseJogo.this);

                builder.setTitle("Confirmar");
                builder.setMessage("Tem a certeza que pretende terminar a análise deste jogo?");

                builder.setPositiveButton("SIM", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                        Intent intent = new Intent(AnaliseJogo.this, TerminarAnalise.class);
                        intent.putExtra("JogoID", idjogo);
                        AnaliseJogo.this.startActivity(intent);

                        dialog.dismiss();
                    }
                });

                builder.setNegativeButton("NÃO", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        // Do nothing
                        dialog.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

        b_6metros = findViewById(R.id.button35);
        b_6metros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (metros.getText().equals(null) || metros.getText().equals("6M")) {
                    b_6metros.setBackgroundColor(Color.GREEN);
                    b_6metros.setTextColor(Color.BLACK);
                    metros.setText("6M");
                } else {
                    if (!metros.getText().equals("6M")) {
                        b_ca.setBackgroundColor(Color.BLACK);
                        b_7metros.setBackgroundColor(Color.BLACK);
                        b_9metros.setBackgroundColor(Color.BLACK);
                        b_ca.setTextColor(Color.WHITE);
                        b_7metros.setTextColor(Color.WHITE);
                        b_9metros.setTextColor(Color.WHITE);
                        b_6metros.setBackgroundColor(Color.GREEN);
                        b_6metros.setTextColor(Color.BLACK);
                        metros.setText("6M");
                    }
                }
            }
        });

        b_7metros = findViewById(R.id.button27);
        b_7metros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (metros.getText().equals(null) || metros.getText().equals("7M")) {
                    b_7metros.setBackgroundColor(Color.GREEN);
                    b_7metros.setTextColor(Color.BLACK);
                    metros.setText("7M");
                } else {
                    if (!metros.getText().equals("7M")) {
                        b_ca.setBackgroundColor(Color.BLACK);
                        b_6metros.setBackgroundColor(Color.BLACK);
                        b_9metros.setBackgroundColor(Color.BLACK);
                        b_ca.setTextColor(Color.WHITE);
                        b_6metros.setTextColor(Color.WHITE);
                        b_9metros.setTextColor(Color.WHITE);
                        b_7metros.setBackgroundColor(Color.GREEN);
                        b_7metros.setTextColor(Color.BLACK);
                        metros.setText("7M");
                    }
                }

            }
        });

        b_9metros = findViewById(R.id.button26);
        b_9metros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (metros.getText().equals(null) || metros.getText().equals("9M")) {
                    b_9metros.setBackgroundColor(Color.GREEN);
                    b_9metros.setTextColor(Color.BLACK);
                    metros.setText("9M");
                } else {
                    if (!metros.getText().equals("9M")) {
                        b_ca.setBackgroundColor(Color.BLACK);
                        b_6metros.setBackgroundColor(Color.BLACK);
                        b_7metros.setBackgroundColor(Color.BLACK);
                        b_ca.setTextColor(Color.WHITE);
                        b_6metros.setTextColor(Color.WHITE);
                        b_7metros.setTextColor(Color.WHITE);
                        b_9metros.setBackgroundColor(Color.GREEN);
                        b_9metros.setTextColor(Color.BLACK);
                        metros.setText("9M");
                    }
                }
            }
        });

        b_ca = findViewById(R.id.button36);
        b_ca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (metros.getText().equals(null) || metros.getText().equals("CA")) {
                    b_ca.setBackgroundColor(Color.GREEN);
                    b_ca.setTextColor(Color.BLACK);
                    metros.setText("CA");
                } else {
                    if (!metros.getText().equals("CA")) {
                        b_9metros.setBackgroundColor(Color.BLACK);
                        b_6metros.setBackgroundColor(Color.BLACK);
                        b_7metros.setBackgroundColor(Color.BLACK);
                        b_9metros.setTextColor(Color.WHITE);
                        b_6metros.setTextColor(Color.WHITE);
                        b_7metros.setTextColor(Color.WHITE);
                        b_ca.setBackgroundColor(Color.GREEN);
                        b_ca.setTextColor(Color.BLACK);
                        metros.setText("CA");
                    }
                }
            }
        });


        metros = findViewById(R.id.textView31);

        balizaabc = findViewById(R.id.textView38);
        balizaadv = findViewById(R.id.textView37);

        B1A = findViewById(R.id.button29);

        B1A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaadv.getText().equals(null) || balizaadv.getText().equals("B1A")) {
                    B1A.setBackgroundColor(Color.GREEN);
                    B1A.setText("ES");
                    B1A.setTextColor(Color.BLACK);
                    balizaadv.setText("B1A");
                } else {
                    if (!balizaadv.getText().equals("B1A")) {
                        B1B.setBackgroundColor(Color.BLACK);
                        B1C.setBackgroundColor(Color.BLACK);
                        B1D.setBackgroundColor(Color.BLACK);
                        B1E.setBackgroundColor(Color.BLACK);
                        B1F.setBackgroundColor(Color.BLACK);
                        B1G.setBackgroundColor(Color.BLACK);
                        B1H.setBackgroundColor(Color.BLACK);
                        B1I.setBackgroundColor(Color.BLACK);

                        B1A.setBackgroundColor(Color.GREEN);
                        B1A.setTextColor(Color.BLACK);
                        balizaadv.setText("B1A");
                    }
                }
            }
        });
        B1B = findViewById(R.id.button46);

        B1B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaadv.getText().equals(null) || balizaadv.getText().equals("B1B")) {
                    B1B.setBackgroundColor(Color.GREEN);
                    B1B.setText("CS");
                    B1B.setTextColor(Color.BLACK);
                    balizaadv.setText("B1B");
                } else {
                    if (!balizaadv.getText().equals("B1B")) {
                        B1A.setBackgroundColor(Color.BLACK);
                        B1C.setBackgroundColor(Color.BLACK);
                        B1D.setBackgroundColor(Color.BLACK);
                        B1E.setBackgroundColor(Color.BLACK);
                        B1F.setBackgroundColor(Color.BLACK);
                        B1G.setBackgroundColor(Color.BLACK);
                        B1H.setBackgroundColor(Color.BLACK);
                        B1I.setBackgroundColor(Color.BLACK);

                        B1B.setBackgroundColor(Color.GREEN);
                        B1B.setTextColor(Color.BLACK);
                        balizaadv.setText("B1B");
                    }
                }
            }
        });
        B1C = findViewById(R.id.button31);

        B1C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (balizaadv.getText().equals(null) || balizaadv.getText().equals("B1C")) {
                    B1C.setBackgroundColor(Color.GREEN);
                    B1C.setText("DS");
                    B1C.setTextColor(Color.BLACK);
                    balizaadv.setText("B1C");
                } else {
                    if (!balizaadv.getText().equals("B1C")) {
                        B1A.setBackgroundColor(Color.BLACK);
                        B1B.setBackgroundColor(Color.BLACK);
                        B1D.setBackgroundColor(Color.BLACK);
                        B1E.setBackgroundColor(Color.BLACK);
                        B1F.setBackgroundColor(Color.BLACK);
                        B1G.setBackgroundColor(Color.BLACK);
                        B1H.setBackgroundColor(Color.BLACK);
                        B1I.setBackgroundColor(Color.BLACK);

                        B1C.setBackgroundColor(Color.GREEN);
                        B1C.setTextColor(Color.BLACK);
                        balizaadv.setText("B1C");
                    }
                }
            }
        });
        B1D = findViewById(R.id.button34);

        B1D.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaadv.getText().equals(null) || balizaadv.getText().equals("B1D")) {
                    B1D.setBackgroundColor(Color.GREEN);
                    B1D.setText("CE");
                    B1D.setTextColor(Color.BLACK);
                    balizaadv.setText("B1D");
                } else {
                    if (!balizaadv.getText().equals("B1D")) {
                        B1A.setBackgroundColor(Color.BLACK);
                        B1B.setBackgroundColor(Color.BLACK);
                        B1C.setBackgroundColor(Color.BLACK);
                        B1E.setBackgroundColor(Color.BLACK);
                        B1F.setBackgroundColor(Color.BLACK);
                        B1G.setBackgroundColor(Color.BLACK);
                        B1H.setBackgroundColor(Color.BLACK);
                        B1I.setBackgroundColor(Color.BLACK);

                        B1D.setBackgroundColor(Color.GREEN);
                        B1D.setTextColor(Color.BLACK);
                        balizaadv.setText("B1D");
                    }
                }
            }
        });
        B1E = findViewById(R.id.button33);

        B1E.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaadv.getText().equals(null) || balizaadv.getText().equals("B1E")) {
                    B1E.setBackgroundColor(Color.GREEN);
                    B1E.setText("C");
                    B1E.setTextColor(Color.BLACK);
                    balizaadv.setText("B1E");
                } else {
                    if (!balizaadv.getText().equals("B1E")) {
                        B1A.setBackgroundColor(Color.BLACK);
                        B1B.setBackgroundColor(Color.BLACK);
                        B1C.setBackgroundColor(Color.BLACK);
                        B1D.setBackgroundColor(Color.BLACK);
                        B1F.setBackgroundColor(Color.BLACK);
                        B1G.setBackgroundColor(Color.BLACK);
                        B1H.setBackgroundColor(Color.BLACK);
                        B1I.setBackgroundColor(Color.BLACK);

                        B1E.setBackgroundColor(Color.GREEN);
                        B1E.setTextColor(Color.BLACK);
                        balizaadv.setText("B1E");
                    }
                }
            }
        });
        B1F = findViewById(R.id.button32);

        B1F.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaadv.getText().equals(null) || balizaadv.getText().equals("B1F")) {
                    B1F.setBackgroundColor(Color.GREEN);
                    B1F.setText("CD");
                    B1F.setTextColor(Color.BLACK);
                    balizaadv.setText("B1F");
                } else {
                    if (!balizaadv.getText().equals("B1F")) {
                        B1A.setBackgroundColor(Color.BLACK);
                        B1B.setBackgroundColor(Color.BLACK);
                        B1C.setBackgroundColor(Color.BLACK);
                        B1D.setBackgroundColor(Color.BLACK);
                        B1E.setBackgroundColor(Color.BLACK);
                        B1G.setBackgroundColor(Color.BLACK);
                        B1H.setBackgroundColor(Color.BLACK);
                        B1I.setBackgroundColor(Color.BLACK);

                        B1F.setBackgroundColor(Color.GREEN);
                        B1F.setTextColor(Color.BLACK);
                        balizaadv.setText("B1F");
                    }
                }
            }
        });
        B1G = findViewById(R.id.button43);

        B1G.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaadv.getText().equals(null) || balizaadv.getText().equals("B1G")) {
                    B1G.setBackgroundColor(Color.GREEN);
                    B1G.setText("EI");
                    B1G.setTextColor(Color.BLACK);
                    balizaadv.setText("B1G");
                } else {
                    if (!balizaadv.getText().equals("B1G")) {
                        B1A.setBackgroundColor(Color.BLACK);
                        B1B.setBackgroundColor(Color.BLACK);
                        B1C.setBackgroundColor(Color.BLACK);
                        B1D.setBackgroundColor(Color.BLACK);
                        B1E.setBackgroundColor(Color.BLACK);
                        B1F.setBackgroundColor(Color.BLACK);
                        B1H.setBackgroundColor(Color.BLACK);
                        B1I.setBackgroundColor(Color.BLACK);

                        B1G.setBackgroundColor(Color.GREEN);
                        B1G.setTextColor(Color.BLACK);
                        balizaadv.setText("B1G");
                    }
                }
            }
        });
        B1H = findViewById(R.id.button41);

        B1H.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaadv.getText().equals(null) || balizaadv.getText().equals("B1H")) {
                    B1H.setBackgroundColor(Color.GREEN);
                    B1H.setText("CI");
                    B1H.setTextColor(Color.BLACK);
                    balizaadv.setText("B1H");
                } else {
                    if (!balizaadv.getText().equals("B1H")) {
                        B1A.setBackgroundColor(Color.BLACK);
                        B1B.setBackgroundColor(Color.BLACK);
                        B1C.setBackgroundColor(Color.BLACK);
                        B1D.setBackgroundColor(Color.BLACK);
                        B1E.setBackgroundColor(Color.BLACK);
                        B1F.setBackgroundColor(Color.BLACK);
                        B1G.setBackgroundColor(Color.BLACK);
                        B1I.setBackgroundColor(Color.BLACK);

                        B1H.setBackgroundColor(Color.GREEN);
                        B1H.setTextColor(Color.BLACK);
                        balizaadv.setText("B1H");
                    }
                }
            }
        });
        B1I = findViewById(R.id.button42);

        B1I.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaadv.getText().equals(null) || balizaadv.getText().equals("B1I")) {
                    B1I.setBackgroundColor(Color.GREEN);
                    B1I.setText("DI");
                    B1I.setTextColor(Color.BLACK);
                    balizaadv.setText("B1I");
                } else {
                    if (!balizaadv.getText().equals("B1I")) {
                        B1A.setBackgroundColor(Color.BLACK);
                        B1B.setBackgroundColor(Color.BLACK);
                        B1C.setBackgroundColor(Color.BLACK);
                        B1D.setBackgroundColor(Color.BLACK);
                        B1E.setBackgroundColor(Color.BLACK);
                        B1F.setBackgroundColor(Color.BLACK);
                        B1G.setBackgroundColor(Color.BLACK);
                        B1H.setBackgroundColor(Color.BLACK);

                        B1I.setBackgroundColor(Color.GREEN);
                        B1I.setTextColor(Color.BLACK);
                        balizaadv.setText("B1I");
                    }
                }
            }
        });

        B2A = findViewById(R.id.button44);
        B2A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaabc.getText().equals(null) || balizaabc.getText().equals("B2A")) {
                    B2A.setBackgroundColor(Color.GREEN);
                    B2A.setText("ES");
                    B2A.setTextColor(Color.BLACK);
                    balizaabc.setText("B2A");
                } else {
                    if (!balizaabc.getText().equals("B2A")) {
                        B2B.setBackgroundColor(Color.BLACK);
                        B2C.setBackgroundColor(Color.BLACK);
                        B2D.setBackgroundColor(Color.BLACK);
                        B2E.setBackgroundColor(Color.BLACK);
                        B2F.setBackgroundColor(Color.BLACK);
                        B2G.setBackgroundColor(Color.BLACK);
                        B2H.setBackgroundColor(Color.BLACK);
                        B2I.setBackgroundColor(Color.BLACK);

                        B2A.setBackgroundColor(Color.GREEN);
                        B2A.setTextColor(Color.BLACK);
                        balizaabc.setText("B2A");
                    }
                }
            }
        });

        B2B = findViewById(R.id.button22);

        B2B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaabc.getText().equals(null) || balizaabc.getText().equals("B2B")) {
                    B2B.setBackgroundColor(Color.GREEN);
                    B2B.setText("CS");
                    B2B.setTextColor(Color.BLACK);
                    balizaabc.setText("B2B");
                } else {
                    if (!balizaabc.getText().equals("B2B")) {
                        B2A.setBackgroundColor(Color.BLACK);
                        B2C.setBackgroundColor(Color.BLACK);
                        B2D.setBackgroundColor(Color.BLACK);
                        B2E.setBackgroundColor(Color.BLACK);
                        B2F.setBackgroundColor(Color.BLACK);
                        B2G.setBackgroundColor(Color.BLACK);
                        B2H.setBackgroundColor(Color.BLACK);
                        B2I.setBackgroundColor(Color.BLACK);

                        B2B.setBackgroundColor(Color.GREEN);
                        B2B.setTextColor(Color.BLACK);
                        balizaabc.setText("B2B");
                    }
                }
            }
        });
        B2C = findViewById(R.id.button48);

        B2C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaabc.getText().equals(null) || balizaabc.getText().equals("B2C")) {
                    B2C.setBackgroundColor(Color.GREEN);
                    B2C.setText("DS");
                    B2C.setTextColor(Color.BLACK);
                    balizaabc.setText("B2C");
                } else {
                    if (!balizaabc.getText().equals("B2C")) {
                        B2A.setBackgroundColor(Color.BLACK);
                        B2B.setBackgroundColor(Color.BLACK);
                        B2D.setBackgroundColor(Color.BLACK);
                        B2E.setBackgroundColor(Color.BLACK);
                        B2F.setBackgroundColor(Color.BLACK);
                        B2G.setBackgroundColor(Color.BLACK);
                        B2H.setBackgroundColor(Color.BLACK);
                        B2I.setBackgroundColor(Color.BLACK);

                        B2C.setBackgroundColor(Color.GREEN);
                        B2C.setTextColor(Color.BLACK);
                        balizaabc.setText("B2C");
                    }
                }
            }
        });
        B2D = findViewById(R.id.button45);

        B2D.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaabc.getText().equals(null) || balizaabc.getText().equals("B2D")) {
                    B2D.setBackgroundColor(Color.GREEN);
                    B2D.setText("CE");
                    B2D.setTextColor(Color.BLACK);
                    balizaabc.setText("B2D");
                } else {
                    if (!balizaabc.getText().equals("B2D")) {
                        B2A.setBackgroundColor(Color.BLACK);
                        B2B.setBackgroundColor(Color.BLACK);
                        B2C.setBackgroundColor(Color.BLACK);
                        B2E.setBackgroundColor(Color.BLACK);
                        B2F.setBackgroundColor(Color.BLACK);
                        B2G.setBackgroundColor(Color.BLACK);
                        B2H.setBackgroundColor(Color.BLACK);
                        B2I.setBackgroundColor(Color.BLACK);

                        B2D.setBackgroundColor(Color.GREEN);
                        B2D.setTextColor(Color.BLACK);
                        balizaabc.setText("B2D");
                    }
                }
            }
        });
        B2E = findViewById(R.id.button50);

        B2E.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaabc.getText().equals(null) || balizaabc.getText().equals("B2E")) {
                    B2E.setBackgroundColor(Color.GREEN);
                    B2E.setText("C");
                    B2E.setTextColor(Color.BLACK);
                    balizaabc.setText("B2E");
                } else {
                    if (!balizaabc.getText().equals("B2E")) {
                        B2A.setBackgroundColor(Color.BLACK);
                        B2B.setBackgroundColor(Color.BLACK);
                        B2C.setBackgroundColor(Color.BLACK);
                        B2D.setBackgroundColor(Color.BLACK);
                        B2F.setBackgroundColor(Color.BLACK);
                        B2G.setBackgroundColor(Color.BLACK);
                        B2H.setBackgroundColor(Color.BLACK);
                        B2I.setBackgroundColor(Color.BLACK);

                        B2E.setBackgroundColor(Color.GREEN);
                        B2E.setTextColor(Color.BLACK);
                        balizaabc.setText("B2E");
                    }
                }
            }
        });
        B2F = findViewById(R.id.button51);

        B2F.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaabc.getText().equals(null) || balizaabc.getText().equals("B2F")) {
                    B2F.setBackgroundColor(Color.GREEN);
                    B2F.setText("CD");
                    B2F.setTextColor(Color.BLACK);
                    balizaabc.setText("B2F");
                } else {
                    if (!balizaabc.getText().equals("B2F")) {
                        B2A.setBackgroundColor(Color.BLACK);
                        B2B.setBackgroundColor(Color.BLACK);
                        B2C.setBackgroundColor(Color.BLACK);
                        B2D.setBackgroundColor(Color.BLACK);
                        B2E.setBackgroundColor(Color.BLACK);
                        B2G.setBackgroundColor(Color.BLACK);
                        B2H.setBackgroundColor(Color.BLACK);
                        B2I.setBackgroundColor(Color.BLACK);

                        B2F.setBackgroundColor(Color.GREEN);
                        B2F.setTextColor(Color.BLACK);
                        balizaabc.setText("B2F");
                    }
                }
            }
        });
        B2G = findViewById(R.id.button47);

        B2G.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaabc.getText().equals(null) || balizaabc.getText().equals("B2G")) {
                    B2G.setBackgroundColor(Color.GREEN);
                    B2G.setText("EI");
                    B2G.setTextColor(Color.BLACK);
                    balizaabc.setText("B2G");
                } else {
                    if (!balizaabc.getText().equals("B2G")) {
                        B2A.setBackgroundColor(Color.BLACK);
                        B2B.setBackgroundColor(Color.BLACK);
                        B2C.setBackgroundColor(Color.BLACK);
                        B2D.setBackgroundColor(Color.BLACK);
                        B2E.setBackgroundColor(Color.BLACK);
                        B2F.setBackgroundColor(Color.BLACK);
                        B2H.setBackgroundColor(Color.BLACK);
                        B2I.setBackgroundColor(Color.BLACK);

                        B2G.setBackgroundColor(Color.GREEN);
                        B2G.setTextColor(Color.BLACK);
                        balizaabc.setText("B2G");
                    }
                }
            }
        });
        B2H = findViewById(R.id.button52);

        B2H.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaabc.getText().equals(null) || balizaabc.getText().equals("B2H")) {
                    B2H.setBackgroundColor(Color.GREEN);
                    B2H.setText("CI");
                    B2H.setTextColor(Color.BLACK);
                    balizaabc.setText("B2H");
                } else {
                    if (!balizaabc.getText().equals("B2H")) {
                        B2A.setBackgroundColor(Color.BLACK);
                        B2B.setBackgroundColor(Color.BLACK);
                        B2C.setBackgroundColor(Color.BLACK);
                        B2D.setBackgroundColor(Color.BLACK);
                        B2E.setBackgroundColor(Color.BLACK);
                        B2F.setBackgroundColor(Color.BLACK);
                        B2G.setBackgroundColor(Color.BLACK);
                        B2I.setBackgroundColor(Color.BLACK);

                        B2H.setBackgroundColor(Color.GREEN);
                        B2H.setTextColor(Color.BLACK);
                        balizaabc.setText("B2H");
                    }
                }
            }
        });
        B2I = findViewById(R.id.button49);

        B2I.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (balizaabc.getText().equals(null) || balizaabc.getText().equals("B2I")) {
                    B2I.setBackgroundColor(Color.GREEN);
                    B2I.setText("DI");
                    B2I.setTextColor(Color.BLACK);
                    balizaabc.setText("B2I");
                } else {
                    if (!balizaabc.getText().equals("B2I")) {
                        B2A.setBackgroundColor(Color.BLACK);
                        B2B.setBackgroundColor(Color.BLACK);
                        B2C.setBackgroundColor(Color.BLACK);
                        B2D.setBackgroundColor(Color.BLACK);
                        B2E.setBackgroundColor(Color.BLACK);
                        B2F.setBackgroundColor(Color.BLACK);
                        B2G.setBackgroundColor(Color.BLACK);
                        B2H.setBackgroundColor(Color.BLACK);

                        B2I.setBackgroundColor(Color.GREEN);
                        B2I.setTextColor(Color.BLACK);
                        balizaabc.setText("B2I");
                    }
                }
            }
        });

        DocumentReference dc = db.collection("Users").document(uid);
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                idEquipa = documentSnapshot.getString("IdEquipa");
            }
        });

        atualizar(idEquipa);


    }

    public void atualizar(String idE){
                db.collection("Users").whereEqualTo("IdEquipa", idE).whereEqualTo("isAtleta", "1").whereEqualTo("isGuardaRedes", "0").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        if(!queryDocumentSnapshots.isEmpty()){
                            ArrayList<DocumentSnapshot> lista = (ArrayList<DocumentSnapshot>) queryDocumentSnapshots.getDocuments();

                            for(DocumentSnapshot d : lista){
                                SpinnerAtletasModel p = d.toObject(SpinnerAtletasModel.class);
                                listaAtletas.add(p);
                            }

                        }
                    }
                });

        db.collection("Users").whereEqualTo("IdEquipa", idE).whereEqualTo("isAtleta", "1").whereEqualTo("isGuardaRedes", "1").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty()){
                    ArrayList<DocumentSnapshot> lista = (ArrayList<DocumentSnapshot>) queryDocumentSnapshots.getDocuments();

                    for(DocumentSnapshot d : lista){
                        SpinnerAtletasModel p = d.toObject(SpinnerAtletasModel.class);
                        listaGuardaRedes.add(p);
                    }

                }
            }
        });
    }

    public void registoGoloMarc() {

        System.out.println("entrou aqui");

        golosMarcados++;

        System.out.println(S1.getSelectedItem());


        String idjogo = this.idjogo;        //receber de tras;

        posicao = metros.getText().toString();
        local_baliza = balizaadv.getText().toString();

        if(posicao.isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(),"Selecione a posição do jogador, por favor!",Toast.LENGTH_LONG);
            toast.show();
        }

        if(local_baliza.isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(),"Selecione um local da baliza adversária, por favor!",Toast.LENGTH_LONG);
            toast.show();
        }


        db.collection("Estatísticas").whereEqualTo("idJogo", idjogo).whereEqualTo("idAtleta", S1.getSelectedItem()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override


            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (!task.getResult().isEmpty()) {

                    for (QueryDocumentSnapshot document : task.getResult()) {

                        if (document.exists()) {
                            System.out.println("documento existe");

                            Map<String, Object> estatistica = document.getData();

                            DocumentReference doc = db.collection("Estatísticas").document(document.getId());
                            Map<String, Object> data = new HashMap<>();


                            if (posicao == "6M") {
                                int Xmetros = Integer.parseInt(estatistica.get("6metros").toString());
                                Xmetros = Xmetros + 1;

                                doc.update("6metros", String.valueOf(Xmetros));

                                int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                golos = golos +1;
                                doc.update("golosMarcados", String.valueOf(golos));
                            } else {
                                if (posicao == "7M") {
                                    int Xmetros = Integer.parseInt(estatistica.get("7metros").toString());
                                    Xmetros = Xmetros + 1;

                                    doc.update("7metros", String.valueOf(Xmetros));

                                    int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                    golos = golos +1;
                                    doc.update("golosMarcados", String.valueOf(golos));
                                } else {
                                    if (posicao == "9M") {
                                        int Xmetros = Integer.parseInt(estatistica.get("9metros").toString());
                                        Xmetros = Xmetros + 1;

                                        doc.update("9metros", String.valueOf(Xmetros));

                                        int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                        golos = golos +1;
                                        doc.update("golosMarcados", String.valueOf(golos));
                                    } else {
                                        if (posicao == "CA") {
                                            int Xmetros = Integer.parseInt(estatistica.get("contraAtaque").toString());
                                            Xmetros = Xmetros + 1;

                                            doc.update("contraAtaque", String.valueOf(Xmetros));

                                            int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                            golos = golos +1;
                                            doc.update("golosMarcados", String.valueOf(golos));
                                        }
                                    }
                                }
                            }

                            if (local_baliza == "B1A") {
                                int XgolosM = Integer.parseInt(estatistica.get("1cantoSupEsq").toString());
                                XgolosM = XgolosM + 1;

                                String golosM = String.valueOf(XgolosM);
                                doc.update("1cantoSupEsq", golosM);

                                int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                golos = golos +1;
                                doc.update("golosMarcados", String.valueOf(golos));
                            } else {
                                if (local_baliza == "B1B") {
                                    int XgolosM = Integer.parseInt(estatistica.get("1centroSup").toString());
                                    XgolosM = XgolosM + 1;

                                    String golosM = String.valueOf(XgolosM);
                                    doc.update("1centroSup", golosM);

                                    int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                    golos = golos +1;
                                    doc.update("golosMarcados", String.valueOf(golos));
                                } else {
                                    if (local_baliza == "B1C") {
                                        int XgolosM = Integer.parseInt(estatistica.get("1cantoSupDir").toString());
                                        XgolosM = XgolosM + 1;

                                        String golosM = String.valueOf(XgolosM);
                                        doc.update("1cantoSupDir", golosM);

                                        int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                        golos = golos +1;
                                        doc.update("golosMarcados", String.valueOf(golos));
                                    } else {
                                        if (local_baliza == "B1D") {
                                            int XgolosM = Integer.parseInt(estatistica.get("1centroEsq").toString());
                                            XgolosM = XgolosM + 1;

                                            String golosM = String.valueOf(XgolosM);
                                            doc.update("1centroEsq", golosM);

                                            int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                            golos = golos +1;
                                            doc.update("golosMarcados", String.valueOf(golos));
                                        } else {
                                            if (local_baliza == "B1E") {
                                                int XgolosM = Integer.parseInt(estatistica.get("1centro").toString());
                                                XgolosM = XgolosM + 1;

                                                String golosM = String.valueOf(XgolosM);
                                                doc.update("1centro", golosM);

                                                int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                                golos = golos +1;
                                                doc.update("golosMarcados", String.valueOf(golos));
                                            } else {
                                                if (local_baliza == "B1F") {
                                                    int XgolosM = Integer.parseInt(estatistica.get("1centroDir").toString());
                                                    XgolosM = XgolosM + 1;

                                                    String golosM = String.valueOf(XgolosM);
                                                    doc.update("1centroDir", golosM);

                                                    int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                                    golos = golos +1;
                                                    doc.update("golosMarcados", String.valueOf(golos));
                                                } else {
                                                    if (local_baliza == "B1G") {
                                                        int XgolosM = Integer.parseInt(estatistica.get("1cantoInfEsq").toString());
                                                        XgolosM = XgolosM + 1;

                                                        String golosM = String.valueOf(XgolosM);
                                                        doc.update("1cantoInfEsq", golosM);

                                                        int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                                        golos = golos +1;
                                                        doc.update("golosMarcados", String.valueOf(golos));
                                                    } else {
                                                        if (local_baliza == "B1H") {
                                                            int XgolosM = Integer.parseInt(estatistica.get("1centroInf").toString());
                                                            XgolosM = XgolosM + 1;

                                                            String golosM = String.valueOf(XgolosM);
                                                            doc.update("1centroInf", golosM);

                                                            int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                                            golos = golos +1;
                                                            doc.update("golosMarcados", String.valueOf(golos));
                                                        } else {
                                                            if (local_baliza == "B1I") {
                                                                int XgolosM = Integer.parseInt(estatistica.get("1cantoInfDir").toString());
                                                                XgolosM = XgolosM + 1;

                                                                String golosM = String.valueOf(XgolosM);
                                                                doc.update("1cantoInfDir", golosM);

                                                                int golos = Integer.parseInt(estatistica.get("golosMarcados").toString());
                                                                golos = golos +1;
                                                                doc.update("golosMarcados", String.valueOf(golos));
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }else{
                    System.out.println("temos de criar aqui");

                    Map<String, Object> data = new HashMap<>();
                    data.put("idJogo", idjogo);
                    data.put("idAtleta", S1.getSelectedItem());
                    data.put("golosMarcados", "1");
                    data.put("golosSofridos", "0");

                    if (posicao == "6M") {
                        data.put("6metros", "1");
                        data.put("7metros", "0");
                        data.put("9metros", "0");
                        data.put("contraAtaque", "0");
                    } else {
                        if (posicao == "7M") {
                            data.put("6metros", "0");
                            data.put("7metros", "1");
                            data.put("9metros", "0");
                            data.put("contraAtaque", "0");
                        } else {
                            if (posicao == "9M") {
                                data.put("6metros", "0");
                                data.put("7metros", "0");
                                data.put("9metros", "1");
                                data.put("contraAtaque", "0");
                            } else {
                                if (posicao == "CA") {
                                    data.put("6metros", "0");
                                    data.put("7metros", "0");
                                    data.put("9metros", "0");
                                    data.put("contraAtaque", "1");
                                }
                            }
                        }
                    }

                    if (local_baliza == "B1A") {
                        data.put("1cantoSupEsq", "1");
                        data.put("1centroSup", "0");
                        data.put("1cantoSupDir", "0");
                        data.put("1centroEsq", "0");
                        data.put("1centro", "0");
                        data.put("1centroDir", "0");
                        data.put("1cantoInfEsq", "0");
                        data.put("1centroInf", "0");
                        data.put("1cantoInfDir", "0");
                    } else {
                        if (local_baliza == "B1B") {
                            data.put("1cantoSupEsq", "0");
                            data.put("1centroSup", "1");
                            data.put("1cantoSupDir", "0");
                            data.put("1centroEsq", "0");
                            data.put("1centro", "0");
                            data.put("1centroDir", "0");
                            data.put("1cantoInfEsq", "0");
                            data.put("1centroInf", "0");
                            data.put("1cantoInfDir", "0");
                        } else {
                            if (local_baliza == "B1C") {
                                data.put("1cantoSupEsq", "0");
                                data.put("1centroSup", "0");
                                data.put("1cantoSupDir", "1");
                                data.put("1centroEsq", "0");
                                data.put("1centro", "0");
                                data.put("1centroDir", "0");
                                data.put("1cantoInfEsq", "0");
                                data.put("1centroInf", "0");
                                data.put("1cantoInfDir", "0");
                            } else {
                                if (local_baliza == "B1D") {
                                    data.put("1cantoSupEsq", "0");
                                    data.put("1centroSup", "0");
                                    data.put("1cantoSupDir", "0");
                                    data.put("1centroEsq", "1");
                                    data.put("1centro", "0");
                                    data.put("1centroDir", "0");
                                    data.put("1cantoInfEsq", "0");
                                    data.put("1centroInf", "0");
                                    data.put("1cantoInfDir", "0");
                                } else {
                                    if (local_baliza == "B1E") {
                                        data.put("1cantoSupEsq", "0");
                                        data.put("1centroSup", "0");
                                        data.put("1cantoSupDir", "0");
                                        data.put("1centroEsq", "0");
                                        data.put("1centro", "1");
                                        data.put("1centroDir", "0");
                                        data.put("1cantoInfEsq", "0");
                                        data.put("1centroInf", "0");
                                        data.put("1cantoInfDir", "0");
                                    } else {
                                        if (local_baliza == "B1F") {
                                            data.put("1cantoSupEsq", "0");
                                            data.put("1centroSup", "0");
                                            data.put("1cantoSupDir", "0");
                                            data.put("1centroEsq", "0");
                                            data.put("1centro", "0");
                                            data.put("1centroDir", "1");
                                            data.put("1cantoInfEsq", "0");
                                            data.put("1centroInf", "0");
                                            data.put("1cantoInfDir", "0");
                                        } else {
                                            if (local_baliza == "B1G") {
                                                data.put("1cantoSupEsq", "0");
                                                data.put("1centroSup", "0");
                                                data.put("1cantoSupDir", "0");
                                                data.put("1centroEsq", "0");
                                                data.put("1centro", "0");
                                                data.put("1centroDir", "0");
                                                data.put("1cantoInfEsq", "1");
                                                data.put("1centroInf", "0");
                                                data.put("1cantoInfDir", "0");
                                            } else {
                                                if (local_baliza == "B1H") {
                                                    data.put("1cantoSupEsq", "0");
                                                    data.put("1centroSup", "0");
                                                    data.put("1cantoSupDir", "0");
                                                    data.put("1centroEsq", "0");
                                                    data.put("1centro", "0");
                                                    data.put("1centroDir", "0");
                                                    data.put("1cantoInfEsq", "0");
                                                    data.put("1centroInf", "1");
                                                    data.put("1cantoInfDir", "0");
                                                } else {
                                                    if (local_baliza == "B1I") {
                                                        data.put("1cantoSupEsq", "0");
                                                        data.put("1centroSup", "0");
                                                        data.put("1cantoSupDir", "0");
                                                        data.put("1centroEsq", "0");
                                                        data.put("1centro", "0");
                                                        data.put("1centroDir", "0");
                                                        data.put("1cantoInfEsq", "0");
                                                        data.put("1centroInf", "0");
                                                        data.put("1cantoInfDir", "1");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    db.collection("Estatísticas").add(data).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            System.out.println("criado com sucessoooooo");
                        }
                    });

                }
            }
        });


    }

    public void registoGoloSof(){

        golosSofridos++;

        String idjogo = this.idjogo;        //receber de tras;

        local_baliza = balizaabc.getText().toString();

        if(local_baliza.isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(),"Selecione um local da baliza, por favor!",Toast.LENGTH_LONG);
            toast.show();
        }

        db.collection("Estatísticas").whereEqualTo("idJogo", idjogo).whereEqualTo("idAtleta",S2.getSelectedItem()).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (!task.getResult().isEmpty()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {

                        if (document.exists()) {

                            Map<String, Object> estatistica = document.getData();

                            DocumentReference doc = db.collection("Estatísticas").document(document.getId());
                            Map<String, Object> data = new HashMap<>();

                            if (local_baliza == "B2A") {
                                int XgolosSof = Integer.parseInt(estatistica.get("2cantoSupEsq").toString());
                                XgolosSof = XgolosSof + 1;

                                String golosS = String.valueOf(XgolosSof);
                                doc.update("2cantoSupEsq", golosS);

                                int golos = Integer.parseInt(estatistica.get("golosSofridos").toString());
                                golos = golos +1;
                                doc.update("golosSofridos", String.valueOf(golos));
                            } else {
                                if (local_baliza == "B2B") {
                                    int XgolosSof = Integer.parseInt(estatistica.get("2centroSup").toString());
                                    XgolosSof = XgolosSof + 1;

                                    String golosS = String.valueOf(XgolosSof);
                                    doc.update("2centroSup", golosS);

                                    int golos = Integer.parseInt(estatistica.get("golosSofridos").toString());
                                    golos = golos +1;
                                    doc.update("golosSofridos", String.valueOf(golos));
                                } else {
                                    if (local_baliza == "B2C") {
                                        int XgolosSof = Integer.parseInt(estatistica.get("2cantoSupDir").toString());
                                        XgolosSof = XgolosSof + 1;

                                        String golosS = String.valueOf(XgolosSof);
                                        doc.update("2cantoSupDir", golosS);

                                        int golos = Integer.parseInt(estatistica.get("golosSofridos").toString());
                                        golos = golos +1;
                                        doc.update("golosSofridos", String.valueOf(golos));
                                    } else {
                                        if (local_baliza == "B2D") {
                                            int XgolosSof = Integer.parseInt(estatistica.get("2centroEsq").toString());
                                            XgolosSof = XgolosSof + 1;

                                            String golosS = String.valueOf(XgolosSof);
                                            doc.update("2centroEsq", golosS);

                                            int golos = Integer.parseInt(estatistica.get("golosSofridos").toString());
                                            golos = golos +1;
                                            doc.update("golosSofridos", String.valueOf(golos));
                                        } else {
                                            if (local_baliza == "B2E") {
                                                int XgolosSof = Integer.parseInt(estatistica.get("2centro").toString());
                                                XgolosSof = XgolosSof + 1;

                                                String golosS = String.valueOf(XgolosSof);
                                                doc.update("2centro", golosS);

                                                int golos = Integer.parseInt(estatistica.get("golosSofridos").toString());
                                                golos = golos +1;
                                                doc.update("golosSofridos", String.valueOf(golos));
                                            } else {
                                                if (local_baliza == "B2F") {
                                                    int XgolosSof = Integer.parseInt(estatistica.get("2centroDir").toString());
                                                    XgolosSof = XgolosSof + 1;

                                                    String golosS = String.valueOf(XgolosSof);
                                                    doc.update("2centroDir", golosS);

                                                    int golos = Integer.parseInt(estatistica.get("golosSofridos").toString());
                                                    golos = golos +1;
                                                    doc.update("golosSofridos", String.valueOf(golos));
                                                } else {
                                                    if (local_baliza == "B2G") {
                                                        int XgolosSof = Integer.parseInt(estatistica.get("2cantoInfEsq").toString());
                                                        XgolosSof = XgolosSof + 1;

                                                        String golosS = String.valueOf(XgolosSof);
                                                        doc.update("2cantoInfEsq", golosS);

                                                        int golos = Integer.parseInt(estatistica.get("golosSofridos").toString());
                                                        golos = golos +1;
                                                        doc.update("golosSofridos", String.valueOf(golos));
                                                    } else {
                                                        if (local_baliza == "B2H") {
                                                            int XgolosSof = Integer.parseInt(estatistica.get("2centroInf").toString());
                                                            XgolosSof = XgolosSof + 1;

                                                            String golosS = String.valueOf(XgolosSof);
                                                            doc.update("2centroInf", golosS);

                                                            int golos = Integer.parseInt(estatistica.get("golosSofridos").toString());
                                                            golos = golos +1;
                                                            doc.update("golosSofridos", String.valueOf(golos));
                                                        } else {
                                                            if (local_baliza == "B2I") {
                                                                int XgolosSof = Integer.parseInt(estatistica.get("2cantoInfDir").toString());
                                                                XgolosSof = XgolosSof + 1;

                                                                String golosS = String.valueOf(XgolosSof);
                                                                doc.update("2cantoInfDir", golosS);

                                                                int golos = Integer.parseInt(estatistica.get("golosSofridos").toString());
                                                                golos = golos +1;
                                                                doc.update("golosSofridos", String.valueOf(golos));
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    System.out.println("temos de criar aqui");

                    Map<String, Object> data = new HashMap<>();
                    data.put("idJogo", idjogo);
                    data.put("idAtleta", S2.getSelectedItem());
                    data.put("golosSofridos", "1");
                    data.put("golosMarcados", "0admin");

                    if (local_baliza == "B2A") {
                        data.put("2cantoSupEsq", "1");
                        data.put("2centroSup", "0");
                        data.put("2cantoSupDir", "0");
                        data.put("2centroEsq", "0");
                        data.put("2centro", "0");
                        data.put("2centroDir", "0");
                        data.put("2cantoInfEsq", "0");
                        data.put("2centroInf", "0");
                        data.put("2cantoInfDir", "0");
                    } else {
                        if (local_baliza == "B2B") {
                            data.put("2cantoSupEsq", "0");
                            data.put("2centroSup", "1");
                            data.put("2cantoSupDir", "0");
                            data.put("2centroEsq", "0");
                            data.put("2centro", "0");
                            data.put("2centroDir", "0");
                            data.put("2cantoInfEsq", "0");
                            data.put("2centroInf", "0");
                            data.put("2cantoInfDir", "0");
                        } else {
                            if (local_baliza == "B2C") {
                                data.put("2cantoSupEsq", "0");
                                data.put("2centroSup", "0");
                                data.put("2cantoSupDir", "1");
                                data.put("2centroEsq", "0");
                                data.put("2centro", "0");
                                data.put("2centroDir", "0");
                                data.put("2cantoInfEsq", "0");
                                data.put("2centroInf", "0");
                                data.put("2cantoInfDir", "0");
                            } else {
                                if (local_baliza == "B2D") {
                                    data.put("2cantoSupEsq", "0");
                                    data.put("2centroSup", "0");
                                    data.put("2cantoSupDir", "0");
                                    data.put("2centroEsq", "1");
                                    data.put("2centro", "0");
                                    data.put("2centroDir", "0");
                                    data.put("2cantoInfEsq", "0");
                                    data.put("2centroInf", "0");
                                    data.put("2cantoInfDir", "0");
                                } else {
                                    if (local_baliza == "B2E") {
                                        data.put("2cantoSupEsq", "0");
                                        data.put("2centroSup", "0");
                                        data.put("2cantoSupDir", "0");
                                        data.put("2centroEsq", "0");
                                        data.put("2centro", "1");
                                        data.put("2centroDir", "0");
                                        data.put("2cantoInfEsq", "0");
                                        data.put("2centroInf", "0");
                                        data.put("2cantoInfDir", "0");
                                    } else {
                                        if (local_baliza == "B2F") {
                                            data.put("2cantoSupEsq", "0");
                                            data.put("2centroSup", "0");
                                            data.put("2cantoSupDir", "0");
                                            data.put("2centroEsq", "0");
                                            data.put("2centro", "0");
                                            data.put("2centroDir", "1");
                                            data.put("2cantoInfEsq", "0");
                                            data.put("2centroInf", "0");
                                            data.put("2cantoInfDir", "0");
                                        } else {
                                            if (local_baliza == "B2G") {
                                                data.put("2cantoSupEsq", "0");
                                                data.put("2centroSup", "0");
                                                data.put("2cantoSupDir", "0");
                                                data.put("2centroEsq", "0");
                                                data.put("2centro", "0");
                                                data.put("2centroDir", "0");
                                                data.put("2cantoInfEsq", "1");
                                                data.put("2centroInf", "0");
                                                data.put("2cantoInfDir", "0");
                                            } else {
                                                if (local_baliza == "B2H") {
                                                    data.put("2cantoSupEsq", "0");
                                                    data.put("2centroSup", "0");
                                                    data.put("2cantoSupDir", "0");
                                                    data.put("2centroEsq", "0");
                                                    data.put("2centro", "0");
                                                    data.put("2centroDir", "0");
                                                    data.put("2cantoInfEsq", "0");
                                                    data.put("2centroInf", "1");
                                                    data.put("2cantoInfDir", "0");
                                                } else {
                                                    if (local_baliza == "B2I") {
                                                        data.put("2cantoSupEsq", "0");
                                                        data.put("2centroSup", "0");
                                                        data.put("2cantoSupDir", "0");
                                                        data.put("2centroEsq", "0");
                                                        data.put("2centro", "0");
                                                        data.put("2centroDir", "0");
                                                        data.put("2cantoInfEsq", "0");
                                                        data.put("2centroInf", "0");
                                                        data.put("2cantoInfDir", "1");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    db.collection("Estatísticas").add(data).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            System.out.println("criado com sucessoooooo");
                        }
                    });
                }
            }
        });
    }

    public int getGolosSofridos(){
        if(golosSofridos == 0){
            return  0;
        }
        return golosSofridos;
    }

    public int getGolosMarcados(){
        if(golosMarcados == 0){
            return  0;
        }
        return golosMarcados;
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
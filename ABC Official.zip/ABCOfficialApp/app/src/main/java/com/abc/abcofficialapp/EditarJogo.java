package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Calendar;

public class EditarJogo  extends AppCompatActivity implements View.OnClickListener{

    private EditText idequipa;
    private EditText nome;
    private EditText dia;
    private EditText hora;
    private EditText local;
    private EditText adversario;
    private EditText descr;
    private Button voltar;
    private Button analise;
    private Button buttonrem;
    private Button button40,buttonEditarJogoCal;
    private FirebaseFirestore db;
    private Jogo jogo;
    private String idjogo;
    ImageButton imageButton111, imageButton112, imageButton113, imageButton114, imageButton115;
    DatePickerDialog.OnDateSetListener setListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_jogo);


        buttonEditarJogoCal = findViewById(R.id.buttonEditarJogoCal);
        idequipa = findViewById(R.id.editTextTextPersonName76);
        nome = findViewById(R.id.editTextTextPersonName77);
        dia = findViewById(R.id.editTextTextPersonName78);
        hora = findViewById(R.id.editTextTextPersonName79);
        local = findViewById(R.id.editTextTextPersonName80);
        adversario = findViewById(R.id.editTextTextPersonName81);
        descr = findViewById(R.id.editTextTextMultiLine3);
        voltar = findViewById(R.id.button53);
        analise = findViewById(R.id.button28);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        jogo = (Jogo) getIntent().getSerializableExtra("JogoD");
        idjogo = (String) getIntent().getSerializableExtra("JogoID");

        System.out.println("o id dom jogo e " + idjogo);

        db = FirebaseFirestore.getInstance();

        DocumentReference dc = db.collection("Jogos").document(jogo.getId_jogo());
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                nome.setText(documentSnapshot.getString("Nome"));
                idequipa.setText(documentSnapshot.getString("IdEquipa"));
                dia.setText(documentSnapshot.getString("Dia"));
                hora.setText(documentSnapshot.getString("Hora"));
                local.setText(documentSnapshot.getString("Local"));
                adversario.setText(documentSnapshot.getString("Adversario"));
                descr.setText(documentSnapshot.getString("Descricao"));
            }
        });
        


        imageButton111 = findViewById(R.id.imageButton111);
        imageButton112 = findViewById(R.id.imageButton112);
        imageButton113 = findViewById(R.id.imageButton113);
        imageButton114 = findViewById(R.id.imageButton114);
        imageButton115 = findViewById(R.id.imageButton115);


        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        analise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( EditarJogo.this, AnaliseJogo.class);
                intent.putExtra("JogoID", jogo.getId_jogo());
                EditarJogo.this.startActivity(intent);


            }
        });

        imageButton111.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });

        imageButton112.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton113.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton114.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton115.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                String date = day+"/"+month+"/"+year;
                dia.setText(date);
            }
        };

        buttonEditarJogoCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(EditarJogo.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        dia.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });


        findViewById(R.id.button40).setOnClickListener((View.OnClickListener) this);
        findViewById(R.id.buttonrem).setOnClickListener((View.OnClickListener) this);
    }

    private void deleteJogo(){
        db.collection("Jogos").document(jogo.getId_jogo()).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(EditarJogo.this,"Jogo Eliminado!!",Toast.LENGTH_SHORT).show();
                    finish();
                    startActivity(new Intent(EditarJogo.this,Jogos.class));
                }
            }
        });
    }


    private boolean hasValidationErrors(String Nome, String Dia, String Hora, String Local, String Adver) {
        if (Nome.isEmpty()) {
            nome.setError("Insira um Nome");
            nome.requestFocus();
            return true;
        }
        if (Dia.isEmpty()) {
            dia.setError("Insira um Dia");
            dia.requestFocus();
            return true;
        }
        if (Hora.isEmpty()) {
            hora.setError("Insira uma Hora");
            hora.requestFocus();
            return true;
        }
        if (Local.isEmpty()) {
            local.setError("Insira um Local");
            local.requestFocus();
            return true;
        }
        if (Adver.isEmpty()) {
            adversario.setError("Insira um Adversário");
            adversario.requestFocus();
            return true;
        }
        return false;
    }


    private void guardar() {
        String Nome = nome.getText().toString().trim();
        String Dia = dia.getText().toString().trim();
        String Hora = hora.getText().toString().trim();
        String Local = local.getText().toString().trim();
        String Adver = adversario.getText().toString().trim();
        String Descr = descr.getText().toString().trim();


        if(!hasValidationErrors(Nome, Dia, Hora, Local, Adver)){
            DocumentReference dd = db.collection("Jogos").document(jogo.getId_jogo());
            dd.update("Nome", nome.getText().toString());
            dd.update("Data", dia.getText().toString());
            dd.update("Hora", hora.getText().toString());
            dd.update("Local", local.getText().toString());
            dd.update("Adversario", adversario.getText().toString());
            dd.update("Descricao", descr.getText().toString());
            Toast.makeText(EditarJogo.this,"Jogo Atualizado!",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(), Jogos.class));
            finish();
        }
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button40:
                guardar();
                break;
            case R.id.buttonrem:
                AlertDialog.Builder builder= new AlertDialog.Builder(this);
                builder.setTitle("Tem certeza que quer eliminar?");
                builder.setMessage("Irá eliminar...");
                builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        deleteJogo();
                    }
                });
                builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                AlertDialog add = builder.create();
                add.show();
                break;
           /* case R.id.buttonEditTreinRelatorio:
                Intent intent = new Intent(PerfilAtleta.this,relatorioAtleta_tr.class);
                intent.putExtra("rel", treinAtletaModel);
                startActivity(intent);
                break;*/
        }
    }
/*
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }*/
}
package com.abc.abcofficialapp;

import com.google.firebase.firestore.Exclude;

import java.io.Serializable;

public class Jogo implements Serializable {

    @Exclude private String id_jogo;

    private String nome_jogo;
    private String adversario;
    private String Dia;
    private String Hora;
    private String Local;
    private String descricao;
    private String IdEquipa;

    public Jogo(){}
   /* public Jogo(String id_jogo, String nome_jogo, String adversario, String dia, String hora, String local, String descricao) {
        this.id_jogo = id_jogo;
        this.nome_jogo = nome_jogo;
        this.adversario = adversario;
        this.dia = dia;
        this.hora = hora;
        this.local = local;
        this.descricao = descricao;
    }*/

    public String getId_jogo() {
        return id_jogo;
    }

    public void setId_jogo(String id_jogo) {
        this.id_jogo = id_jogo;
    }

    public String getDia() {
        return Dia;
    }

    public void setDia(String dia) {
        Dia = dia;
    }

    public String getLocal() {
        return Local;
    }

    public void setLocal(String local) {
        Local = local;
    }

    public String getIdEquipa() {
        return IdEquipa;
    }

    public void setIdEquipa(String IdEquipa) {
        this.IdEquipa = IdEquipa;
    }

    public String getNome_jogo() {
        return nome_jogo;
    }

    public void setNome_jogo(String nome_jogo) {
        this.nome_jogo = nome_jogo;
    }

    public String getAdversario() {
        return adversario;
    }

    public void setAdversario(String adversario) {
        this.adversario = adversario;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}

package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class Jogos extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Jogo> jogoArrayList;
    AdapterJogo adapterJogo;
    FirebaseFirestore db;
    FirebaseAuth fAuth;
    ProgressDialog progressDialog;
    String uid;
    private String global;


    Button buttonAdicionarJogo;
    ImageButton imageButton70, imageButton71, imageButton72, imageButton73, imageButton74;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jogos);


        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();


        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Procurando Dados...");
        progressDialog.show();

        recyclerView = findViewById(R.id.rvJogos);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();
        jogoArrayList = new ArrayList<Jogo>();
        adapterJogo = new AdapterJogo(Jogos.this, jogoArrayList);

        recyclerView.setAdapter(adapterJogo);

        buttonAdicionarJogo = findViewById(R.id.buttonAdicionarJogo);
        imageButton70 = findViewById(R.id.imageButton70);
        imageButton71 = findViewById(R.id.imageButton71);
        imageButton72 = findViewById(R.id.imageButton72);
        imageButton73 = findViewById(R.id.imageButton73);
        imageButton74 = findViewById(R.id.imageButton74);


        buttonAdicionarJogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MarcarJogos.class));
                finish();
            }
        });

        imageButton70.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });

        imageButton71.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton72.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton73.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton74.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        DocumentReference dc = db.collection("Users").document(uid);
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                String jj = documentSnapshot.getString("IdEquipa");
                global = global.copyValueOf(jj.toCharArray());
                EventChangeListener(global);
            }
        });

    }

    private void EventChangeListener(String eq) {
        db.collection("Jogos").whereEqualTo("IdEquipa",eq).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for(DocumentSnapshot d : list){
                        Jogo p = d.toObject(Jogo.class);
                        p.setId_jogo(d.getId());
                        jogoArrayList.add(p);
                    }
                    adapterJogo.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }

            }
        });
    }

    /*
     db.collection("Jogos").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null){
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                    Log.e("Erro na BD", error.getMessage());
                    return;
                }
                for (DocumentChange dc : value.getDocumentChanges()){
                    if(dc.getType() == DocumentChange.Type.ADDED){
                        Jogo j = dc.getDocument().toObject(Jogo.class);
                        j.setId_jogo(dc.getDocument().getId());
                        jogoArrayList.add(j);
                    }

                    adapterJogo.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }
            }
        });
     */
}
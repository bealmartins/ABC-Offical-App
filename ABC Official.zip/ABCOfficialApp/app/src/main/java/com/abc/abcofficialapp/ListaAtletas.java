package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class ListaAtletas extends AppCompatActivity {

    Button buttonAdicionarAtleta;

    RecyclerView recyclerView4;
    ArrayList<TreinAtletaModel> listaatletas;
    MyAdapterAtletasTreinador myAdapterAtletasTreinador;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    ProgressDialog progressDialog;
    String uid;
    String equipa;
    ImageButton imageButton14, imageButton15, imageButton16, imageButton17, imageButton18;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_atletas);

        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();
        fStore = FirebaseFirestore.getInstance();

        buttonAdicionarAtleta = findViewById(R.id.buttonAdicionarAtleta);
        imageButton14 = findViewById(R.id.imageButton14);
        imageButton15 = findViewById(R.id.imageButton15);
        imageButton16 = findViewById(R.id.imageButton16);
        imageButton17 = findViewById(R.id.imageButton17);
        imageButton18 = findViewById(R.id.imageButton18);

        buttonAdicionarAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), RegistoAtleta.class));
                finish();
            }
        });

        DocumentReference documentReference = fStore.collection("Users").document(uid);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                String ff = documentSnapshot.getString("IdEquipa").toString();
                equipa = equipa.copyValueOf(ff.toCharArray());
                atualizar(equipa);
            }
        });

        imageButton14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        recyclerView4 = findViewById(R.id.recyclerView4);
        recyclerView4.setHasFixedSize(true);
        recyclerView4.setLayoutManager(new LinearLayoutManager(this));
        fStore = FirebaseFirestore.getInstance();

        listaatletas = new ArrayList<TreinAtletaModel>();
        myAdapterAtletasTreinador = new MyAdapterAtletasTreinador(this,listaatletas); ///Alterei

        recyclerView4.setAdapter(myAdapterAtletasTreinador);
    }

    public void atualizar(String f){

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Procurando Dados!!....");
        progressDialog.show();

        fStore.collection("Users").whereEqualTo("IdEquipa", f).whereEqualTo("isAtleta","1").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for(DocumentSnapshot d : list){
                        TreinAtletaModel p = d.toObject(TreinAtletaModel.class);
                        p.setId(d.getId());
                        listaatletas.add(p);
                    }
                    myAdapterAtletasTreinador.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }

            }
        });


    }
}
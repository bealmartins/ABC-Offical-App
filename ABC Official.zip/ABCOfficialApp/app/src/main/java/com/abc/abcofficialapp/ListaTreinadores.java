package com.abc.abcofficialapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class ListaTreinadores extends AppCompatActivity {
    RecyclerView recyclerView10;
    ArrayList<TreinAtletaModel> listaatletas;
    MyAdapterAtletasTreinador myAdapterAtletasTreinador;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    ProgressDialog progressDialog;
    String uid;
    Button button4;

    ImageButton imageButton54, imageButton55, imageButton11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_treinadores);

        button4 = findViewById(R.id.button4);
        imageButton54 = findViewById(R.id.imageButton54);
        imageButton55 = findViewById(R.id.imageButton55);
        imageButton11 = findViewById(R.id.imageButton11);

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), RegistoTreinador.class));
                finish();
            }
        });

        imageButton54.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAdministrador.class));
                finish();
            }
        });

        imageButton55.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                finish();
            }
        });

        imageButton11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PagamentosAtleta.class));
                finish();
            }
        });
        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();
        fStore = FirebaseFirestore.getInstance();


        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Procurando Dados!!....");
        progressDialog.show();

        recyclerView10 = findViewById(R.id.recyclerView10);
        recyclerView10.setHasFixedSize(true);
        recyclerView10.setLayoutManager(new LinearLayoutManager(this));
        fStore = FirebaseFirestore.getInstance();

        listaatletas = new ArrayList<TreinAtletaModel>();
        myAdapterAtletasTreinador = new MyAdapterAtletasTreinador(this,listaatletas); ///Alterei

        fStore.collection("Users").whereEqualTo("isTreinador", "1").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for(DocumentSnapshot d : list){
                        TreinAtletaModel p = d.toObject(TreinAtletaModel.class);
                        p.setId(d.getId());
                        listaatletas.add(p);
                    }
                    myAdapterAtletasTreinador.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }

            }
        });
        recyclerView10.setAdapter(myAdapterAtletasTreinador);
    }

}
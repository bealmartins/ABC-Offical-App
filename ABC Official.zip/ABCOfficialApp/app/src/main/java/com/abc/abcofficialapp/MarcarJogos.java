package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class MarcarJogos extends AppCompatActivity {

    private EditText Id, nomeJogo, diaJogo, localJogo, adversariojogo6, descricaoJogo2, horaJogo;
    private Button guardarJogo, voltarJogo;
    private HashMap<String, Object> lista;
    private FirebaseFirestore fStore;
    ImageButton imageButton106, imageButton107, imageButton108, imageButton109, imageButton110;
    private String global;
    String uid;
    FirebaseAuth fAuth;
    DatePickerDialog.OnDateSetListener setListener;
    Button buttoncallMarcJo;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marcar_jogos);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        fAuth = FirebaseAuth.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        fStore = FirebaseFirestore.getInstance();
        Id = findViewById(R.id.id);

        buttoncallMarcJo = findViewById(R.id.buttoncallMarcJo);
        nomeJogo = findViewById(R.id.nomeJogo);
        diaJogo = findViewById(R.id.diaJogo);
        horaJogo = findViewById(R.id.horaJogo);
        localJogo = findViewById(R.id.localJogo);
        adversariojogo6 = findViewById(R.id.adversariojogo6);
        descricaoJogo2 = findViewById(R.id.descricaoJogo2);
        guardarJogo = findViewById(R.id.guardarJogo);
        voltarJogo = findViewById(R.id.voltarJogo);
        global = "";

        imageButton106 = findViewById(R.id.imageButton106);
        imageButton107 = findViewById(R.id.imageButton107);
        imageButton108 = findViewById(R.id.imageButton108);
        imageButton109 = findViewById(R.id.imageButton109);
        imageButton110 = findViewById(R.id.imageButton110);

        DocumentReference dc = fStore.collection("Users").document(uid);
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                String jj = documentSnapshot.getString("IdEquipa");
                global = global.copyValueOf(jj.toCharArray());
                Id.setText(global);
            }
        });



        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                String date = day+"/"+month+"/"+year;
                diaJogo.setText(date);
            }
        };

        buttoncallMarcJo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(MarcarJogos.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        diaJogo.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        voltarJogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton106.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton107.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton108.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton109.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton110.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        guardarJogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nome = nomeJogo.getText().toString();
                String dia = diaJogo.getText().toString();
                String hora = horaJogo.getText().toString();
                String local = localJogo.getText().toString();
                String adversario = adversariojogo6.getText().toString();
                String descricao = descricaoJogo2.getText().toString();

                if (!hasValidationErrors(nomeJogo.getText().toString()) && !hasValidationErrors(diaJogo.getText().toString()) && !hasValidationErrors(horaJogo.getText().toString()) && !hasValidationErrors(localJogo.getText().toString()) && !hasValidationErrors(adversariojogo6.getText().toString())) {
                    CollectionReference df = fStore.collection("Jogos");
                    Map<String, Object> jogoINf = new HashMap<>();
                    jogoINf.put("IdEquipa",global);
                    jogoINf.put("Nome",nome);
                    jogoINf.put("Dia", dia);
                    jogoINf.put("Hora", hora);
                    jogoINf.put("Local", local);
                    jogoINf.put("Adversario", adversario);
                    jogoINf.put("Descricao", descricao);
                   /* jogoINf.put("IsDraw", "");
                    jogoINf.put("IsDefeat", "");
                    jogoINf.put("IsVictory", "");
                    jogoINf.put("Resultado", "");*/

                    df.add(jogoINf);
                    Toast.makeText(MarcarJogos.this, "Jogo adicionado com sucesso", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Jogos.class));
                    finish();
                }
            }
        });

    }
    private boolean hasValidationErrors (String d){
        if (d.isEmpty()) {

            Toast.makeText(MarcarJogos.this, "Preencha todos os parâmetros execeto->à escolha descrição!!", Toast.LENGTH_SHORT).show();

            return true;
        }
        return false;
    }
}

package com.abc.abcofficialapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class MarcarTreinos extends AppCompatActivity {

    EditText txtMarcarTreinoId,txtMarcarTreinoDura,txtMarcacaoTreinosDia,txtMarcacaoTreinHora
            ,txtMarcacaoTreinLocal,editTextTextMultiLine4;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;

    Button buttonGuardarMarcacao,buttonVoltarMarcacao2,buttonCriarTCal;
    DatePickerDialog.OnDateSetListener setListener;
    ImageButton imageButton101, imageButton102, imageButton103, imageButton104, imageButton105;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marcar_treinos);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        fAuth = FirebaseAuth.getInstance();
        uid = fAuth.getCurrentUser().getUid();
        fStore =FirebaseFirestore.getInstance();

        buttonCriarTCal = findViewById(R.id.buttonCriarTCal);
        txtMarcarTreinoId= findViewById(R.id.txtMarcarTreinoId);
        txtMarcarTreinoDura= findViewById(R.id.txtMarcarTreinoDura);
        txtMarcacaoTreinosDia = findViewById(R.id.txtMarcacaoTreinosDia);
        txtMarcacaoTreinHora = findViewById(R.id.txtMarcacaoTreinHora);
        txtMarcacaoTreinLocal = findViewById(R.id.txtMarcacaoTreinLocal);
        editTextTextMultiLine4 = findViewById(R.id.editTextTextMultiLine4);
        buttonGuardarMarcacao = findViewById(R.id.buttonGuardarMarcacao);
        buttonVoltarMarcacao2 = findViewById(R.id.buttonVoltarMarcacao2);

        txtMarcarTreinoId.setText(uid);


        imageButton101 = findViewById(R.id.imageButton101);
        imageButton102 = findViewById(R.id.imageButton102);
        imageButton103 = findViewById(R.id.imageButton103);
        imageButton104 = findViewById(R.id.imageButton104);
        imageButton105 = findViewById(R.id.imageButton105);

        buttonGuardarMarcacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!hasValidationErrors(txtMarcarTreinoDura.getText().toString()) && !hasValidationErrors(txtMarcacaoTreinosDia.getText().toString()) && !hasValidationErrors(txtMarcacaoTreinHora.getText().toString()) && !hasValidationErrors(txtMarcacaoTreinLocal.getText().toString())){
                    CollectionReference df = fStore.collection("Treinos");
                    Map<String, Object> userInfo = new HashMap<>();
                    userInfo.put("Data",txtMarcacaoTreinosDia.getText().toString());
                    userInfo.put("Duracao",txtMarcarTreinoDura.getText().toString());
                    userInfo.put("Hora",txtMarcacaoTreinHora.getText().toString());
                    userInfo.put("Local",txtMarcacaoTreinLocal.getText().toString());
                    userInfo.put("Descricao",editTextTextMultiLine4.getText().toString());
                    userInfo.put("IdTreinador", uid);
                    df.add(userInfo);
                    Toast.makeText(MarcarTreinos.this,"Treino Agendado!!",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(),Treinos.class));
                    finish();
                }

            }
        });

        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                String date = day+"/"+month+"/"+year;
                txtMarcacaoTreinosDia.setText(date);
            }
        };

        buttonCriarTCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(MarcarTreinos.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        txtMarcacaoTreinosDia.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        buttonVoltarMarcacao2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Treinos.class));
                finish();
            }
        });

        imageButton101.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton102.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton103.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton104.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton105.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

    }

   /* @RequiresApi(api = Build.VERSION_CODES.O)
    public Timestamp convertStringToTimestamp(String strDate) {
        try {
            String pattern = "dd/MM/yyyy";
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
            LocalDateTime localDateTime = LocalDateTime.from(formatter.parse(strDate));
            Timestamp timestamp = Timestamp..valueOf(localDateTime);

            return timestamp;
        } catch (ParseException e) {
            System.out.println("Exception :" + e);
            return null;
        }
    }*/

    private boolean hasValidationErrors(String d) {
        if (d.isEmpty()) {
           /* txtMarcarTreinoDura.setError("Erro");
            txtMarcarTreinoDura.requestFocus();*/
            Toast.makeText(MarcarTreinos.this,"Preencha todos os parâmetros à esquerda!!",Toast.LENGTH_SHORT).show();

            return true;
        }
     /*   if (d.isEmpty()) {
            txtMarcacaoTreinosDia.setError("Erro");
            txtMarcacaoTreinosDia.requestFocus();
            return true;
        }
        if (d.isEmpty()) {
            txtMarcacaoTreinLocal.setError("Erro");
            txtMarcacaoTreinLocal.requestFocus();
            return true;
        }
        if (d.isEmpty()) {
            txtMarcacaoTreinHora.setError("Erro");
            txtMarcacaoTreinHora.requestFocus();
            return true;
        }*/

        return false;
    }
}
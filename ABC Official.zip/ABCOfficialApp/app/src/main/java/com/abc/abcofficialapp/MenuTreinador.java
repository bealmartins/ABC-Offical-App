package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MenuTreinador extends AppCompatActivity {

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;
    String idequipa;
    String idtreinador;
    ProgressDialog progressDialog;

    int iVitorias;
    int iEmpates;
    int iDerrotas;

    int golosMar;
    int golosSof;
    int totalGol;


    ArrayList<String> listatreinos;
    ArrayList<Date> listatreinosDate;
    ArrayList<LocalDate> listatreinosLocalDates;

    ArrayList<String> listajogos;
    ArrayList<Date> listajogosDates;
    ArrayList<LocalDate> listajogosLocalDates;

    ArrayList<String> empates;
    ArrayList<String> vitorias;
    ArrayList<String> derrotas;

    EditText proxJogo, proxTreino, golosMarcados, golosSofridos, txtvitorias, txtderrotas, txtempates;

    ImageButton imageButton5, imageButton4, imageButton12, imageButton2, imageButton3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_treinador);


        imageButton5 = findViewById(R.id.imageButton5);
        imageButton4 = findViewById(R.id.imageButton4);
        imageButton12 = findViewById(R.id.imageButton12);
        imageButton2 = findViewById(R.id.imageButton2);
        imageButton3 = findViewById(R.id.imageButton3);

        iVitorias=0;
        iEmpates=0;
        iDerrotas = 0;

         golosMar=0;
         golosSof=0;
         totalGol=0;

        imageButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent log = new Intent(getApplicationContext(),Login.class);
                finishAffinity();
                startActivity(log);
            }
        });
        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        proxJogo = findViewById(R.id.proxJogo);
        proxTreino = findViewById(R.id.proxTreino);
        golosMarcados = findViewById(R.id.golosMarcados);
        golosSofridos = findViewById(R.id.golosSofridos);
        txtvitorias = findViewById(R.id.vitorias);
        txtderrotas = findViewById(R.id.derrotas);
        txtempates = findViewById(R.id.empates);

        /*totalGolos.setText("5");
        golosMarcados.setText("2");
        golosSofridos.setText("3");*/


        empates = new ArrayList<>();
        derrotas = new ArrayList<>();
        vitorias = new ArrayList<>();

        listajogos = new ArrayList<>();
        listajogosDates = new ArrayList<>();
        listajogosLocalDates = new ArrayList<>();

        listatreinos = new ArrayList<>();
        listatreinosDate = new ArrayList<>();
        listatreinosLocalDates = new ArrayList<>();

        fAuth = FirebaseAuth.getInstance();
        uid = fAuth.getCurrentUser().getUid();
        fStore = FirebaseFirestore.getInstance();

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Procurando Dados!!....");
        progressDialog.show();

        DocumentReference documentReference = fStore.collection("Users").document(uid);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                String ff = documentSnapshot.getString("IdEquipa").toString();
                idequipa = idequipa.copyValueOf(ff.toCharArray());
                atualizarjogos(idequipa);
                atualizarresultados(idequipa);
            }
        });


    }

    public void atualizarjogos(String eq){
        fStore = FirebaseFirestore.getInstance();
        fStore.collection("Jogos").whereEqualTo("IdEquipa", eq).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if (!queryDocumentSnapshots.isEmpty()) {
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for (int i = 0; i < list.size(); i++) {
                        String p = list.get(i).getString("Dia");
                        listajogos.add(p);
                    }

                    for(int i =0;i<listajogos.size();i++){
                        Date s = null;
                        try {
                            s = new SimpleDateFormat("dd/MM/yyyy").parse(listajogos.get(i));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        listajogosDates.add(s);
                    }


                    for (int i = 0; i < listajogosDates.size(); i++) {
                        Date input = listajogosDates.get(i);
                        LocalDate date = input.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                        listajogosLocalDates.add(date);
                    }



                    LocalDate prox= listajogosLocalDates.get(0);
                    LocalDate currentDate= LocalDate.now();

                    for (int i = 1; i < listajogosLocalDates.size(); i++) {
                        if(prox.compareTo(currentDate)==0){
                            break;
                        }else if(prox.compareTo(listajogosLocalDates.get(i))>0){
                            prox=listajogosLocalDates.get(i);
                            // prox=listajogosLocalDates.get(i+1);
                        }
                    }
                    proxJogo.setText(prox.toString());
                    atualizarTreinos(uid);

                }else{
                    proxJogo.setText("Não tem treinos marcados!!");
                }
            }
        });
    }

    public void atualizarTreinos(String trein){
        fStore = FirebaseFirestore.getInstance();
        fStore.collection("Treinos").whereEqualTo("IdTreinador", trein).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if (!queryDocumentSnapshots.isEmpty()) {
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for (int i = 0; i < list.size(); i++) {
                        String p = list.get(i).getString("Data");
                        listatreinos.add(p);
                    }

                    for(int i =0;i<listatreinos.size();i++){
                        Date g = null;
                        try {
                            g = new SimpleDateFormat("dd/MM/yyyy").parse(listatreinos.get(i));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        listatreinosDate.add(g);
                    }

                    for (int i = 0; i < listatreinosDate.size(); i++) {
                        Date input2 = listatreinosDate.get(i);
                        LocalDate date2 = input2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                        listatreinosLocalDates.add(date2);
                    }
                    proxTreino.setText(listatreinosLocalDates.get(0).toString());


                    LocalDate prox2= listatreinosLocalDates.get(0);
                    LocalDate currentDate2= LocalDate.now();

                    for (int i = 1; i < listatreinosLocalDates.size(); i++) {
                        if(prox2.compareTo(currentDate2)==0){
                            break;
                        }else if(prox2.compareTo(listatreinosLocalDates.get(i))>0){
                            prox2=listatreinosLocalDates.get(i);
                        }
                    }
                    proxTreino.setText(prox2.toString());

                }else{
                    proxTreino.setText("Não tem treinos marcados!!");
                }
            }

        });
    }

    public void atualizarresultados(String eq){
       /* fStore.collection("Jogos").whereEqualTo("IdEquipa", eq).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for (int i = 0; i < list.size(); i++) {
                        String d = list.get(i).getString("IsDefeat");
                        String e = list.get(i).getString("IsDraw");
                        String v = list.get(i).getString("IsVictory");
                        if(d.equals("0")){
                            if (e.equals("0")) {
                                vitorias.add(v);
                            }else{
                                empates.add(e);
                            }
                        }else{
                            derrotas.add(d);
                        }
                    }
                    int contadorVitorias=0;
                    int contadorDerrotas=0;
                    int contadorEmpates=0;

                    for(int i=0;i<vitorias.size();i++){
                        contadorVitorias++;
                    }
                    for(int i=0;i<derrotas.size();i++){
                        contadorDerrotas++;
                    }
                    for(int i=0;i<empates.size();i++){
                        contadorEmpates++;
                    }
                    txtderrotas.setText(String.valueOf(contadorDerrotas));
                    txtempates.setText(String.valueOf(contadorEmpates));
                    txtvitorias.setText(String.valueOf(contadorVitorias));

                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }else{
                    txtderrotas.setText("Ainda não ocorreram jogos");
                    txtempates.setText("Ainda não ocorreram jogos");
                    txtvitorias.setText("Ainda não ocorreram jogos");
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }
            }
        });*/
        // FirebaseFirestore db = FirebaseFirestore.getInstance();
        fStore.collection("Estatísticas").whereEqualTo("IdEquipa",eq).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    for(QueryDocumentSnapshot document : task.getResult()){
                        if(document.getLong("golosMarcados") > document.getLong("golosSofridos")){
                            iVitorias = iVitorias + 1;

                            golosMar += Integer.valueOf(document.get("golosMarcados").toString());
                            golosSof += Integer.valueOf(document.get("golosSofridos").toString());



                        }
                        if(document.getLong("golosMarcados") == document.getLong("golosSofridos")){
                            iEmpates= iEmpates + 1;
                            golosMar += Integer.valueOf(document.get("golosMarcados").toString());
                            golosSof += Integer.valueOf(document.get("golosSofridos").toString());


                        }
                        if(document.getLong("golosMarcados") < document.getLong("golosSofridos")){
                            iDerrotas= iDerrotas + 1;
                            golosMar += Integer.valueOf(document.get("golosMarcados").toString());
                            golosSof += Integer.valueOf(document.get("golosSofridos").toString());


                        }
                    }
                } else {
                    Toast.makeText(MenuTreinador.this, "Documento não existe", Toast.LENGTH_SHORT).show();//pop-up de aviso
                }
                //System.out.println("Número de atletas: " + iAtletas);

                golosMarcados.setText(String.valueOf(golosMar));
                golosSofridos.setText(String.valueOf(golosSof));

                txtvitorias.setText(String.valueOf(iVitorias));
                txtempates.setText(String.valueOf(iEmpates));
                txtderrotas.setText(String.valueOf(iDerrotas));
                if(progressDialog.isShowing())
                    progressDialog.dismiss();
            }

        });

    }
}
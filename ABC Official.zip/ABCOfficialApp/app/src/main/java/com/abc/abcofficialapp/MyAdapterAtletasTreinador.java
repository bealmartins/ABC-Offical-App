package com.abc.abcofficialapp;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.ArrayList;

public class MyAdapterAtletasTreinador extends RecyclerView.Adapter<MyAdapterAtletasTreinador.MyViewHolder> {
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;
    DocumentReference user;
    private Context mCtx;
    private ArrayList<TreinAtletaModel> listaatletas;

    public MyAdapterAtletasTreinador(Context mCtx, ArrayList<TreinAtletaModel>listaatletas){
        this.mCtx=mCtx;
        this.listaatletas=listaatletas;
        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();
        fStore = FirebaseFirestore.getInstance();
        user = fStore.collection("Users").document(uid);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(mCtx).inflate(R.layout.item_listar_atletas_treinador,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        TreinAtletaModel treinAtletaModel = listaatletas.get(position);
        holder.Nome.setText(treinAtletaModel.getNome());
        holder.Email.setText(treinAtletaModel.getEmail());
    }

    @Override
    public int getItemCount() {
        return listaatletas.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView Nome,Email;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Nome = itemView.findViewById(R.id.tAtlNome);
            Email = itemView.findViewById(R.id.tAtlEmail);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            user.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                @Override
                public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                      if("1".equals(value.getString("isAdmin"))){
                        TreinAtletaModel treinAtletaModel = listaatletas.get(getAdapterPosition());
                        Intent intent = new Intent(mCtx,PerfilTreinador.class);
                        intent.putExtra("TreinadorD", treinAtletaModel);
                        mCtx.startActivity(intent);
                    }else{
                        TreinAtletaModel treinAtletaModel = listaatletas.get(getAdapterPosition());
                        Intent intent = new Intent(mCtx,PerfilAtleta.class);
                        intent.putExtra("AtletaD", treinAtletaModel);
                        mCtx.startActivity(intent);
                    }
                }
            });
          /*  TreinAtletaModel treinAtletaModel = listaatletas.get(getAdapterPosition());
            Intent intent = new Intent(mCtx,PerfilAtleta.class);
            intent.putExtra("AtletaD", treinAtletaModel);
            mCtx.startActivity(intent);*/
        }
    }
}

package com.abc.abcofficialapp;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class MyAdapterTreinos extends RecyclerView.Adapter<MyAdapterTreinos.MyViewHolder>{

    private Context mCtx;
    private ArrayList<TreinoModel> listaTreinos;

    public MyAdapterTreinos(Context mCtx, ArrayList<TreinoModel> listaTreinos){
        this.mCtx=mCtx;
        this.listaTreinos=listaTreinos;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(mCtx).inflate(R.layout.item_list_treinos,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        TreinoModel treinoModel = listaTreinos.get(position);
        holder.Data.setText(treinoModel.getData());
        holder.Hora.setText(treinoModel.getHora());
        holder.Local.setText(treinoModel.getLocal());

    }

    @Override
    public int getItemCount() {
        return listaTreinos.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView Data;
        TextView Local;
        TextView Hora;


        // public LinearLayout linearLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Data = itemView.findViewById(R.id.tData);
            Local = itemView.findViewById(R.id.localCardtreinoAt);
            Hora = itemView.findViewById(R.id.HoraCardTreinoAtl);
            //linearLayout = (LinearLayout) itemView.findViewById(R.id.linearLayout);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
         /*   TreinoModel treinoModel = listaTreinos.get(getAdapterPosition());
            Intent intent = new Intent(mCtx,EditarTreino.class);
            intent.putExtra("Treino", treinoModel);
            mCtx.startActivity(intent);*/

            FirebaseAuth fAuth;
            fAuth = FirebaseAuth.getInstance();
            FirebaseFirestore fStore;
            fStore = FirebaseFirestore.getInstance();

            String uid = fAuth.getCurrentUser().getUid();

            DocumentReference df = fStore.collection("Users").document(uid);
            df.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                @Override
                public void onSuccess(DocumentSnapshot documentSnapshot) {
                    Log.d("TAG", "onSucess: " + documentSnapshot.getData());

                    //Identificar user access level
                    if (documentSnapshot.getString("isAtleta") != null) {


                    } else if (documentSnapshot.getString("isTreinador") != null) {
                        TreinoModel treinoModel = listaTreinos.get(getAdapterPosition());
                        Intent intent = new Intent(mCtx,EditarTreino.class);
                        intent.putExtra("Treino", treinoModel);
                        mCtx.startActivity(intent);
                    }
                }
            });
        }
    }
}

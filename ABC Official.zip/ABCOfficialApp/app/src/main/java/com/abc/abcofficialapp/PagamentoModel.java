package com.abc.abcofficialapp;

public class PagamentoModel {

    private String Nome;
    private String E_mail;
    private String Montante;
    private String Data;

    public PagamentoModel(String Nome, String E_mail, String Montante, String Data) {
        this.Nome = Nome;
        this.E_mail = E_mail;
        this.Montante = Montante;
        this.Data = Data;
    }

    public PagamentoModel() {
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getE_mail() {
        return E_mail;
    }

    public void setE_mail(String e_mail) {
        E_mail = e_mail;
    }

    public String getMontante() {
        return Montante;
    }

    public void setMontante(String montante) {
        Montante = montante;
    }

    public String getData() {
        return Data;
    }

    public void setData(String data) {
        Data = data;
    }
}

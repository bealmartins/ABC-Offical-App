package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class PagamentosAtleta extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<PagamentoModel> listaPagamentos;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    MyAdapterPagamentos myAdapter;
    String uid;
    String pag;
    ImageButton imageButton62, imageButton63, imageButton38;
    Button addpayment;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamentos_atleta);


        recyclerView = findViewById(R.id.lista);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        addpayment = findViewById(R.id.addpayment);
        imageButton62 = findViewById(R.id.imageButton62);
        imageButton63 = findViewById(R.id.imageButton63);
        imageButton38 = findViewById(R.id.imageButton38);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Fetching data...");
        progressDialog.show();

        listaPagamentos = new ArrayList<PagamentoModel>();
        myAdapter = new MyAdapterPagamentos(this, listaPagamentos);
        recyclerView.setAdapter(myAdapter);

       /* DocumentReference documentReference = fStore.collection("Pagamentos").document(uid);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                String ff = documentSnapshot.getString("Nome").toString();
                pag = pag.copyValueOf(ff.toCharArray());
                atualizar(pag);
            }
        });*/
        EventChangeListener();

        addpayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), CriarPagamento.class));
                finish();
            }
        });


        imageButton62.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAdministrador.class));
                finish();
            }
        });

        imageButton63.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                finish();
            }
        });

        imageButton38.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PagamentosAtleta.class));
                finish();
            }
        });


    }


    private void EventChangeListener() {
        fStore.collection("Pagamentos").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null){
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                    Log.e("Erro", error.getMessage());
                    return;
                }
                for (DocumentChange dc: value.getDocumentChanges()){
                    if(dc.getType() == DocumentChange.Type.ADDED){
                        listaPagamentos.add(dc.getDocument().toObject(PagamentoModel.class));
                    }
                    myAdapter.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }
            }
        });
    }
}
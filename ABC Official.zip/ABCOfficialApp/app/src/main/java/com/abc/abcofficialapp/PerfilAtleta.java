package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.io.Serializable;
import java.util.Calendar;

public class PerfilAtleta extends AppCompatActivity implements View.OnClickListener {

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;
    private TreinAtletaModel treinAtletaModel;
    boolean valid = true;
    ImageButton imageButton25, imageButton26, imageButton29, imageButton32, imageButton33;
    DatePickerDialog.OnDateSetListener setListener;


    //private Context context;


    Button buttonEditTreinRelatorio,buttonEditAtleTreinGuardar,buttonEditAtlTreinVoltar,buttonEditTreinRemover,buttonCalEditPerfAtTrei;
    EditText txtEditPerfTreinAtNome,txtEditPerfTreinAtUsername,txtEditPerfTreinAtTelefone
            ,txtEditPerfTreinAtDataNasc,txtEditPerfTreinAtMorada,txtEditPerfTreinAtEscolaridade,txtEditPerfTreinAtGenero
            ,txtEditPerfTreinAtCC,txtEditPerfTreinAtSNS,txtEditPerfTreinAtIBAN,txtEditPerfTreinAtPeso
            ,txtEditPerfTreinAtSangue,txtEditPerfTreinAtAltura;

    TextView textViewEmail,textViewPassAt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_atleta);


        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        treinAtletaModel = (TreinAtletaModel) getIntent().getSerializableExtra("AtletaD");
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        buttonEditTreinRelatorio = findViewById(R.id.buttonEditTreinRelatorio);
        buttonEditAtleTreinGuardar = findViewById(R.id.buttonEditAtleTreinGuardar);
        buttonEditAtlTreinVoltar = findViewById(R.id.buttonEditAtlTreinVoltar);
        buttonEditTreinRemover = findViewById(R.id.buttonEditTreinRemover);

        buttonCalEditPerfAtTrei = findViewById(R.id.buttonCalEditPerfAtTrei);
        txtEditPerfTreinAtNome = findViewById(R.id.txtEditPerfTreinAtNome);
        txtEditPerfTreinAtUsername = findViewById(R.id.txtEditPerfTreinAtUsername);
        textViewEmail = findViewById(R.id.textViewEmail);
        txtEditPerfTreinAtTelefone = findViewById(R.id.txtEditPerfTreinAtTelefone);
        txtEditPerfTreinAtDataNasc = findViewById(R.id.txtEditPerfTreinAtDataNasc);
        txtEditPerfTreinAtMorada = findViewById(R.id.txtEditPerfTreinAtMorada);
        txtEditPerfTreinAtEscolaridade = findViewById(R.id.txtEditPerfTreinAtEscolaridade);
        txtEditPerfTreinAtGenero = findViewById(R.id.txtEditPerfTreinAtGenero);
        txtEditPerfTreinAtCC = findViewById(R.id.txtEditPerfTreinAtCC);
        txtEditPerfTreinAtSNS = findViewById(R.id.txtEditPerfTreinAtSNS);
        txtEditPerfTreinAtIBAN = findViewById(R.id.txtEditPerfTreinAtIBAN);
        textViewPassAt = findViewById(R.id.textViewPassAt);
        txtEditPerfTreinAtPeso = findViewById(R.id.txtEditPerfTreinAtPeso);
        txtEditPerfTreinAtSangue = findViewById(R.id.txtEditPerfTreinAtSangue);
        txtEditPerfTreinAtAltura = findViewById(R.id.txtEditPerfTreinAtAltura);

        imageButton25 = findViewById(R.id.imageButton25);
        imageButton26 = findViewById(R.id.imageButton26);
        imageButton29 = findViewById(R.id.imageButton29);
        imageButton32 = findViewById(R.id.imageButton32);
        imageButton33 = findViewById(R.id.imageButton33);


        //txtEditPerfTreinAtEmail.setText(treinAtletaModel.getEmail());
        DocumentReference dc = fStore.collection("Users").document(treinAtletaModel.getId());
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                txtEditPerfTreinAtNome.setText(documentSnapshot.getString("Nome"));
                txtEditPerfTreinAtUsername.setText(documentSnapshot.getString("Username"));
                textViewEmail.setText(documentSnapshot.getString("Email"));
                txtEditPerfTreinAtTelefone.setText(documentSnapshot.getString("Telemovel"));
                txtEditPerfTreinAtDataNasc.setText(documentSnapshot.getString("Data Nascimento"));
                txtEditPerfTreinAtMorada.setText(documentSnapshot.getString("Morada"));
                txtEditPerfTreinAtEscolaridade.setText(documentSnapshot.getString("Escolaridade"));
                txtEditPerfTreinAtGenero.setText(documentSnapshot.getString("Genero"));
                txtEditPerfTreinAtCC.setText(documentSnapshot.getString("Cartão Cidadão"));
                txtEditPerfTreinAtSNS.setText(documentSnapshot.getString("SNS"));
                txtEditPerfTreinAtIBAN.setText(documentSnapshot.getString("IBAN"));
                textViewPassAt.setText(documentSnapshot.getString("Password")+"  <-- Password");
                txtEditPerfTreinAtPeso.setText(documentSnapshot.getString("Peso"));
                txtEditPerfTreinAtAltura.setText(documentSnapshot.getString("Altura"));
                txtEditPerfTreinAtSangue.setText(documentSnapshot.getString("Grupo Sanguineo"));
            }
        });

        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                String date = day+"/"+month+"/"+year;
                txtEditPerfTreinAtDataNasc.setText(date);
            }
        };

        buttonCalEditPerfAtTrei.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(PerfilAtleta.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        txtEditPerfTreinAtDataNasc.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        buttonEditAtlTreinVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PerfilAtleta.this,ListaAtletas.class));
                finish();
            }
        });

        imageButton25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        findViewById(R.id.buttonEditAtleTreinGuardar).setOnClickListener((View.OnClickListener) this);
        findViewById(R.id.buttonEditTreinRemover).setOnClickListener((View.OnClickListener) this);
        findViewById(R.id.buttonEditTreinRelatorio).setOnClickListener((View.OnClickListener) this);
    }

    public boolean checkField(EditText textField) {
        if (textField.getText().toString().isEmpty()) {
            Toast.makeText(PerfilAtleta.this, "Preencha todos os espaços!", Toast.LENGTH_SHORT).show();
            valid = false;
        } else {
            valid = true;
        }

        return valid;
    }


    private void guardar(){
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        checkField(txtEditPerfTreinAtNome);
        checkField(txtEditPerfTreinAtUsername);
        //  checkField(txtEditPerfTreinAtEmail);
        checkField(txtEditPerfTreinAtTelefone);
        checkField(txtEditPerfTreinAtDataNasc);
        checkField(txtEditPerfTreinAtMorada);
        checkField(txtEditPerfTreinAtEscolaridade);
        checkField(txtEditPerfTreinAtGenero);
        checkField(txtEditPerfTreinAtCC);
        checkField(txtEditPerfTreinAtSNS);
        checkField(txtEditPerfTreinAtIBAN);
        // checkField(txtEditPerfTreinAtPassword);
        checkField(txtEditPerfTreinAtPeso);
        checkField(txtEditPerfTreinAtSangue);
        checkField(txtEditPerfTreinAtAltura);

        if(valid) {
            DocumentReference dd = fStore.collection("Users").document(treinAtletaModel.getId());
            dd.update("Nome", txtEditPerfTreinAtNome.getText().toString());
            dd.update("Username", txtEditPerfTreinAtUsername.getText().toString());
            //  dd.update("Email", txtRegEmail.getText().toString());
            // dd.update("Password", txtEditPerfTreinAtPassword.getText().toString());
            dd.update("Telemovel", txtEditPerfTreinAtTelefone.getText().toString());
            dd.update("Data Nascimento", txtEditPerfTreinAtDataNasc.getText().toString());
            dd.update("Morada", txtEditPerfTreinAtMorada.getText().toString());
            dd.update("Escolaridade", txtEditPerfTreinAtEscolaridade.getText().toString());
            dd.update("Cartão Cidadão", txtEditPerfTreinAtCC.getText().toString());
            dd.update("Genero", txtEditPerfTreinAtGenero.getText().toString());
            dd.update("SNS", txtEditPerfTreinAtSNS.getText().toString());
            dd.update("IBAN", txtEditPerfTreinAtIBAN.getText().toString());
            dd.update("Peso", txtEditPerfTreinAtPeso.getText().toString());
            dd.update("Altura", txtEditPerfTreinAtAltura.getText().toString());
            dd.update("Grupo Sanguineo", txtEditPerfTreinAtSangue.getText().toString());
            Toast.makeText(PerfilAtleta.this, "Perfil Atualizado!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(PerfilAtleta.this,ListaAtletas.class));
            finish();
        }

    }

    private void deleteAtleta(){
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        fStore.collection("Users").document(treinAtletaModel.getId()).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(PerfilAtleta.this,"Atleta Eliminado!",Toast.LENGTH_SHORT).show();
                    finish();
                    startActivity(new Intent(PerfilAtleta.this,ListaAtletas.class));
                }
            }
        });
    }



   /* private void deleteAtleta(){
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        DocumentReference dc = fStore.collection("Users").document(treinAtletaModel.getId());
        dc.update("isDeleted","1");
        Toast.makeText(PerfilAtleta.this,"Atleta Eliminado!",Toast.LENGTH_SHORT).show();
        finish();
        startActivity(new Intent(PerfilAtleta.this,ListaAtletas.class));
    }*/


        public void onClick(View view) {
        switch (view.getId()) {
            case R.id.buttonEditAtleTreinGuardar:
                guardar();
                break;
            case R.id.buttonEditTreinRemover:
                AlertDialog.Builder builder= new AlertDialog.Builder(this);
                builder.setTitle("Tem certeza que quer eliminar?");
                builder.setMessage("Irá eliminar...");
                builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        deleteAtleta();
                    }
                });
                builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                AlertDialog add = builder.create();
                add.show();
                break;
            case R.id.buttonEditTreinRelatorio:
                Intent intent = new Intent(PerfilAtleta.this,relatorioAtleta_tr.class);
                intent.putExtra("rel", treinAtletaModel);
                startActivity(intent);
                break;
        }
    }

   /* @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }*/
}
package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class PerfilAtleta1 extends AppCompatActivity {

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    FirebaseUser uu;
    String uid;
    boolean valid = true;

    Button voltarAtleta, guardarAtleta,button;

    DatePickerDialog.OnDateSetListener setListener;

    EditText textnome, textusername, textemail, texttelefone, textdata, textmorada, textescola,
            textgenero, textCC, textSNS, textIBAN, textpassword, textpeso, textaltura, textsangue;

    ImageButton menuAtleta, perfilAtleta, relatorioAtleta, jogosAtleta, treinosAtleta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_atleta1);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        fStore = FirebaseFirestore.getInstance();
        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();

        button = findViewById(R.id.button);
        textnome = findViewById(R.id.textnome);
        textusername = findViewById(R.id.textusername);
        textemail = findViewById(R.id.textemail);
        texttelefone = findViewById(R.id.texttelefone);
        textdata = findViewById(R.id.textdata);
        textmorada = findViewById(R.id.textmorada);
        textescola = findViewById(R.id.textescola);
        textgenero = findViewById(R.id.textgenero);
        textCC = findViewById(R.id.textCC);
        textSNS = findViewById(R.id.textSNS);
        textIBAN = findViewById(R.id.textIBAN);
        textpassword = findViewById(R.id.textpassword);
        textpeso = findViewById(R.id.textpeso);
        textaltura = findViewById(R.id.textaltura);
        textsangue = findViewById(R.id.textsangue);

        menuAtleta = findViewById(R.id.imageButton39);
        perfilAtleta = findViewById(R.id.imageButton43);
        relatorioAtleta = findViewById(R.id.imageButton45);
        jogosAtleta = findViewById(R.id.imageButton46);
        treinosAtleta = findViewById(R.id.imageButton47);

        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                String date = day+"/"+month+"/"+year;
                textdata.setText(date);
            }
        };

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(PerfilAtleta1.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        textdata.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        voltarAtleta = findViewById(R.id.voltarAtleta);
        guardarAtleta = findViewById(R.id.guardarAtleta);
        guardarAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updater();
                atualizar();
            }
        });

        voltarAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAtleta.class));
                finish();
            }
        });


        DocumentReference dc = fStore.collection("Users").document(fAuth.getCurrentUser().getUid());
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                textnome.setText(documentSnapshot.getString("Nome"));
                textusername.setText(documentSnapshot.getString("Username"));
                textemail.setText(documentSnapshot.getString("Email"));
                texttelefone.setText(documentSnapshot.getString("Telemovel"));
                textdata.setText(documentSnapshot.getString("Data Nascimento"));
                textmorada.setText(documentSnapshot.getString("Morada"));
                textescola.setText(documentSnapshot.getString("Escolaridade"));
                textgenero.setText(documentSnapshot.getString("Genero"));
                textCC.setText(documentSnapshot.getString("Cartão Cidadão"));
                textSNS.setText(documentSnapshot.getString("SNS"));
                textIBAN.setText(documentSnapshot.getString("IBAN"));
                textpassword.setText(documentSnapshot.getString("Password"));
                textpeso.setText(documentSnapshot.getString("Peso"));
                textaltura.setText(documentSnapshot.getString("Altura"));
                textsangue.setText(documentSnapshot.getString("Grupo Sanguineo"));
            }
        });

        menuAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAtleta.class));
                finish();
            }
        });

        perfilAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilAtleta1.class));
                finish();
            }
        });

        relatorioAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), relatorioAtleta_at.class));
                finish();
            }
        });

        jogosAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), VerJogos_at.class));
                finish();
            }
        });

        treinosAtleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), verTreinos_at.class));
                finish();
            }
        });


    }

    private void atualizar() {
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("Users").document(uid);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                textnome.setText(documentSnapshot.getString("Nome"));
                textusername.setText(documentSnapshot.getString("Username"));
                textemail.setText(documentSnapshot.getString("Email"));
                texttelefone.setText(documentSnapshot.getString("Telemovel"));
                textdata.setText(documentSnapshot.getString("Data Nascimento"));
                textmorada.setText(documentSnapshot.getString("Morada"));
                textescola.setText(documentSnapshot.getString("Escolaridade"));
                textgenero.setText(documentSnapshot.getString("Genero"));
                textCC.setText(documentSnapshot.getString("Cartão Cidadão"));
                textSNS.setText(documentSnapshot.getString("SNS"));
                textIBAN.setText(documentSnapshot.getString("IBAN"));
                textpassword.setText(documentSnapshot.getString("Password"));
                textpeso.setText(documentSnapshot.getString("Peso"));
                textaltura.setText(documentSnapshot.getString("Altura"));
                textsangue.setText(documentSnapshot.getString("Grupo Sanguineo"));
            }
        });
    }

    private void updater(){
        checkField(textnome);
        checkField(textusername);
        checkField(textemail);
        checkField(texttelefone);
        checkField(textdata);
        checkField(textmorada);
        checkField(textescola);
        checkField(textgenero);
        checkField(textCC);
        checkField(textSNS);
        checkField(textIBAN);
        checkField(textpeso);
        checkField(textaltura);
        checkField(textsangue);
        checkField(textpassword);


        if(valid) {

            String UPnome = textnome.getText().toString();
            String UPUsername = textusername.getText().toString();
            String UPEmail = textemail.getText().toString();
            String UpTelefone = texttelefone.getText().toString();
            String UpDataNasc = textdata.getText().toString();
            String UpMorada = textmorada.getText().toString();
            String UpGenero = textgenero.getText().toString();
            String UpEsc = textescola.getText().toString();
            String UpCC = textCC.getText().toString();
            String UpSNS = textSNS.getText().toString();
            String UpIBAN = textIBAN.getText().toString();
            String UpPeso = textpeso.getText().toString();
            String UpAltura = textaltura.getText().toString();
            String UpSangue = textsangue.getText().toString();
            String UpPass = textpassword.getText().toString();


            fAuth = FirebaseAuth.getInstance();
            fStore = FirebaseFirestore.getInstance();
            uid= fAuth.getCurrentUser().getUid();
            uu= fAuth.getCurrentUser();
            DocumentReference documentReference = fStore.collection("Users").document(uid);
            //Map<String,Object> userInfo = new HashMap<>();
            documentReference.update("Nome", UPnome);
            documentReference.update("Username", UPUsername);
            documentReference.update("Email", UPEmail);
            documentReference.update("Password", UpPass);
            if(checkEmail(textemail)){
                uu.updateEmail(UPEmail);
            }
            uu.updatePassword(UpPass);
            documentReference.update("Telemovel", UpTelefone);
            documentReference.update("Data Nascimento", UpDataNasc);
            documentReference.update("Morada", UpMorada);
            documentReference.update("Cartão Cidadão", UpCC);
            documentReference.update("Genero", UpGenero);
            documentReference.update("IBAN", UpIBAN);
           // documentReference.update("isAtleta", "1");
            documentReference.update("Escolaridade", UpEsc);
            documentReference.update("SNS", UpSNS);
            documentReference.update("Peso", UpPeso);
            documentReference.update("Altura", UpAltura);
            documentReference.update("Grupo Sanguineo", UpSangue);
            //documentReference.set(userInfo);


            startActivity(new Intent(getApplicationContext(), MenuAtleta.class));
            finish();
            Toast.makeText(PerfilAtleta1.this, "Informações Atualizadas", Toast.LENGTH_SHORT).show();


        }else{
            Toast.makeText(PerfilAtleta1.this, "Parâmetros vazios", Toast.LENGTH_SHORT).show();

        }


    }

    public boolean checkEmail(EditText textField){
        if(uu.getEmail() != textField.getText().toString()){
            return true;
        }else return false;

    }

    public boolean checkField(EditText textField){
        if(textField.getText().toString().isEmpty()){
            textField.setError("Error");
            valid = false;
        }else {
            valid = true;
        }

        return valid;
    }
}
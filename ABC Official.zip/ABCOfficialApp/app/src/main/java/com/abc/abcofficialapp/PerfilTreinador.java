package com.abc.abcofficialapp;
//falta o botao remover

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class PerfilTreinador extends AppCompatActivity implements View.OnClickListener{

    EditText txtPerfilTreiNome,txtPerfilTreinUsername,txtPerfilTreinTelefone,
            txtPerfilTreinDataNasc,txtPerfilTreinMorada,txtPerfilTreinNCC,txtPerfilTreinIBAN,
            txtPerfilTreinGenero;

    TextView txtPerfilTreinPassword,txtPerfilTreinEmail;

    Button buttonPerfilTreinGuardar, voltar, remover,buttonCalPerfiTreiADm;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;
    boolean valid = true;
    FirebaseUser uu;

    ImageButton imageButton36, imageButton35, imageButton34;
    private TreinAtletaModel treinAtletaModel;
    DatePickerDialog.OnDateSetListener setListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_treinador);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);


        imageButton36 = findViewById(R.id.imageButton36);
        imageButton36.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAdministrador.class));
                finish();
            }
        });
        imageButton35 = findViewById(R.id.imageButton35);
        imageButton35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                finish();
            }
        });

        imageButton34 = findViewById(R.id.imageButton34);
        imageButton34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PagamentosAtleta.class));
                finish();
            }
        });


        buttonPerfilTreinGuardar = findViewById(R.id.buttonPerfilAtletaGuardar);
        remover = findViewById(R.id.remover);
        voltar = findViewById(R.id.voltarPerfil);
        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startActivity(new Intent(getApplicationContext(), MenuAdministrador.class));
                finish();
            }
        });

        buttonCalPerfiTreiADm = findViewById(R.id.buttonCalPerfiTreiADm);
        txtPerfilTreiNome = findViewById(R.id.txtPerfilTreiNome);
        txtPerfilTreinUsername = findViewById(R.id.txtPerfilTreinUsername);
        txtPerfilTreinEmail = findViewById(R.id.txtPerfilTreinEmail);
        txtPerfilTreinTelefone = findViewById(R.id.txtPerfilTreinTelefone);
        txtPerfilTreinDataNasc = findViewById(R.id.txtPerfilTreinDataNasc);
        txtPerfilTreinMorada = findViewById(R.id.txtPerfilTreinMorada);
        txtPerfilTreinNCC = findViewById(R.id.txtPerfilTreinNCC);
        txtPerfilTreinIBAN = findViewById(R.id.txtPerfilTreinIBAN);
        txtPerfilTreinPassword = findViewById(R.id.txtPerfilTreinPassword);
        txtPerfilTreinGenero = findViewById(R.id.txtPerfilTreinGenero);

        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                String date = day+"/"+month+"/"+year;
                txtPerfilTreinDataNasc.setText(date);
            }
        };

        buttonCalPerfiTreiADm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(PerfilTreinador.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        txtPerfilTreinDataNasc.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid= fAuth.getCurrentUser().getUid();
        treinAtletaModel = (TreinAtletaModel) getIntent().getSerializableExtra("TreinadorD");

        DocumentReference dc = fStore.collection("Users").document(treinAtletaModel.getId());
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                txtPerfilTreiNome.setText(documentSnapshot.getString("Nome"));
                txtPerfilTreinUsername.setText(documentSnapshot.getString("Username"));
                txtPerfilTreinEmail.setText(documentSnapshot.getString("Email"));
                txtPerfilTreinTelefone.setText(documentSnapshot.getString("Telemovel"));
                txtPerfilTreinDataNasc.setText(documentSnapshot.getString("Data Nascimento"));
                txtPerfilTreinMorada.setText(documentSnapshot.getString("Morada"));
                txtPerfilTreinGenero.setText(documentSnapshot.getString("Genero"));
                txtPerfilTreinNCC.setText(documentSnapshot.getString("Cartão Cidadão"));
                txtPerfilTreinIBAN.setText(documentSnapshot.getString("IBAN"));
                txtPerfilTreinPassword.setText(documentSnapshot.getString("Password")+ " <--Password");
            }
        });

        buttonPerfilTreinGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updater();
                atualizar();
            }
        });

        remover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fAuth = FirebaseAuth.getInstance();
                fStore = FirebaseFirestore.getInstance();
                fStore.collection("Users").document(treinAtletaModel.getId()).delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(PerfilTreinador.this,"Treinador Eliminado!",Toast.LENGTH_SHORT).show();
                            finish();
                            startActivity(new Intent(PerfilTreinador.this,ListaTreinadores.class));
                        }
                    }
                });
            }
        });
    }


    private void atualizar(){
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        //uid= fAuth.getCurrentUser().getUid();
        treinAtletaModel = (TreinAtletaModel) getIntent().getSerializableExtra("TreinadorD");

        DocumentReference documentReference = fStore.collection("Users").document(treinAtletaModel.getId());
        documentReference.addSnapshotListener( new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                txtPerfilTreiNome.setText(documentSnapshot.getString("Nome"));
                txtPerfilTreinUsername.setText(documentSnapshot.getString("Username"));
                txtPerfilTreinEmail.setText(documentSnapshot.getString("Email"));
                txtPerfilTreinTelefone.setText(documentSnapshot.getString("Telemovel"));
                txtPerfilTreinDataNasc.setText(documentSnapshot.getString("Data Nascimento"));
                txtPerfilTreinMorada.setText(documentSnapshot.getString("Morada"));
                txtPerfilTreinGenero.setText(documentSnapshot.getString("Genero"));
                txtPerfilTreinNCC.setText(documentSnapshot.getString("Cartão Cidadão"));
                txtPerfilTreinIBAN.setText(documentSnapshot.getString("IBAN"));
                txtPerfilTreinPassword.setText(documentSnapshot.getString("Password"));

            }
        });
    }


    private void updater(){
        checkField(txtPerfilTreiNome);
        checkField(txtPerfilTreinUsername);
        checkField(txtPerfilTreinTelefone);
        checkField(txtPerfilTreinDataNasc);
        checkField(txtPerfilTreinMorada);
        checkField(txtPerfilTreinGenero);
        checkField(txtPerfilTreinNCC);
        checkField(txtPerfilTreinIBAN);


        if(valid) {

            String UPnome = txtPerfilTreiNome.getText().toString();
            String UPUsername = txtPerfilTreinUsername.getText().toString();
            String UpTelefone = txtPerfilTreinTelefone.getText().toString();
            String UpDataNasc = txtPerfilTreinDataNasc.getText().toString();
            String UpMorada = txtPerfilTreinMorada.getText().toString();
            String UpGenero = txtPerfilTreinGenero.getText().toString();
            String UpNcc = txtPerfilTreinNCC.getText().toString();
            String UpIBAN = txtPerfilTreinIBAN.getText().toString();



            fAuth = FirebaseAuth.getInstance();
            fStore = FirebaseFirestore.getInstance();
            uid= fAuth.getCurrentUser().getUid();
           // uu= fAuth.getCurrentUser();
            treinAtletaModel = (TreinAtletaModel) getIntent().getSerializableExtra("TreinadorD");


            DocumentReference documentReference = fStore.collection("Users").document(treinAtletaModel.getId());
            documentReference.update("Nome", UPnome);
            documentReference.update("Username", UPUsername);

            documentReference.update("Telemovel", UpTelefone);
            documentReference.update("Data Nascimento", UpDataNasc);
            documentReference.update("Genero", UpGenero);
            documentReference.update("Cartão Cidadão", UpNcc);
            documentReference.update("IBAN", UpIBAN);
            documentReference.update("Morada", UpMorada);
            documentReference.update("isTreinador", "1");


            //documentReference.set(userInfo);


            //startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
            finish();
            Toast.makeText(PerfilTreinador.this, "Informações Atualizadas!!", Toast.LENGTH_SHORT).show();


        }else{
            Toast.makeText(PerfilTreinador.this, "Parâmetros vazios!!", Toast.LENGTH_SHORT).show();

        }


    }


    public boolean checkField(EditText textField){
        if(textField.getText().toString().isEmpty()){
            textField.setError("Error");
            valid = false;
        }else {
            valid = true;
        }

        return valid;
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}
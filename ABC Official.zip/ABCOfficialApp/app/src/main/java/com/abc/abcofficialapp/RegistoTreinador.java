package com.abc.abcofficialapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class RegistoTreinador extends AppCompatActivity {

    boolean valid = true;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore = FirebaseFirestore.getInstance();
    FirebaseUser user;
    private String global;
    String uid;
    EditText txtNometre,txtUsernameTrei,txtEmailtrein,txtContactoTelTrein,txtdataNAscTre,txtMoardaTrein,
            txtNccTrein,txtIbanTrin,txtPassTre,txtGeneroTrein;

    Button button6,calregTR;

    ImageButton imageButton24, imageButton27, imageButton28;
    private CollectionReference usersRef = fStore.collection("Users");


    int numEquipas; //numero de equipas na collection equipas
    int idProxEquipa;
    int statusLoop = 0; //numero de loops
    int numUsers = 0; //tamanho da collection
    int loopCompl = 0;

    DatePickerDialog.OnDateSetListener setListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registo_treinador);

        DocumentReference eqRef = fStore.collection("Equipas").document("jA2TAwtdjbQuFTudid1d");
        eqRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                numEquipas = value.getLong("IdEquipa").intValue();
            }
        });

        usersRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        numUsers = numUsers + 1;
                    }
                    st:
                    for (int c = 1; c <= numEquipas; c = c + 1) {
                        statusLoop = 0;
                        nd:
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            statusLoop = statusLoop + 1;
                            if (document.getString("isTreinador") != null) {
                                //System.out.println("nome: "+document.getString("Nome")+" IdEquipa: "+document.getString("IdEquipa")+"verificador: "+c);
                                if (Integer.valueOf(document.getString("IdEquipa")) == c){
                                    statusLoop = 0;
                                    break nd;
                                }
                            }
                            if(statusLoop == numUsers){
                                loopCompl = 1;
                            }
                        }
                        if (loopCompl == 1 && c < numEquipas){
                            if(c < numEquipas){
                                idProxEquipa = c;
                                break st;
                            }else if(loopCompl == 1 && c == numEquipas){
                                idProxEquipa = c + 1;
                                //somar mais um às equipas
                                break st;
                            }
                        }
                    }//fim o for do contador
                }
            }
        });

        System.out.println("ANTES BD: Há "+ numEquipas +" Equipas");
        System.out.println("ANTES BD: Vai ser atribuída a equipa: "+ idProxEquipa);

        calregTR = findViewById(R.id.calregTR);
        imageButton24 = findViewById(R.id.imageButton24);
        imageButton27 = findViewById(R.id.imageButton27);
        imageButton28 = findViewById(R.id.imageButton28);

        imageButton24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAdministrador.class));
                finish();
            }
        });

        imageButton27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                finish();
            }
        });

        imageButton28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PagamentosAtleta.class));
                finish();
            }
        });

        button6= findViewById(R.id.button6);
        txtNometre= findViewById(R.id.txtNometre);
        txtUsernameTrei = findViewById(R.id.txtUsernameTrei);
        txtEmailtrein = findViewById(R.id.txtEmailtrein);
        txtContactoTelTrein = findViewById(R.id.txtContactoTelTrein);
        txtdataNAscTre = findViewById(R.id.txtdataNAscTre);
        txtMoardaTrein = findViewById(R.id.txtMoardaTrein);
        txtNccTrein = findViewById(R.id.txtNccTrein);
        txtIbanTrin = findViewById(R.id.txtIbanTrin);
        txtPassTre = findViewById(R.id.txtPassTre);
        txtGeneroTrein = findViewById(R.id.txtGeneroTrein);

        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();
        fStore = FirebaseFirestore.getInstance();

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        calregTR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(RegistoTreinador.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month=month+1;
                        String date = day+"/"+month+"/"+year;
                        txtdataNAscTre.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gg();
             /*   startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                finish();*/
            }
        });

      /*  button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkField(txtNometre);
                checkField(txtUsernameTrei);
                checkField(txtEmailtrein);
                checkField(txtContactoTelTrein);
                checkField(txtdataNAscTre);
                checkField(txtMoardaTrein);
                checkField(txtNccTrein);
                checkField(txtIbanTrin);
                checkField(txtPassTre);
                checkField(txtGeneroTrein);

                if (valid) {
                    fAuth.createUserWithEmailAndPassword(txtEmailtrein.getText().toString(), txtPassTre.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {

                            user = fAuth.getCurrentUser();
                            Toast.makeText(RegistoAtleta.this, "Account created", Toast.LENGTH_SHORT).show();
                            DocumentReference df = fStore.collection("Users").document(user.getUid());
                            Map<String, Object> userInfo = new HashMap<>();
                            userInfo.put("Nome", txtNometre.getText().toString());
                            userInfo.put("Username", txtUsernameTrei.getText().toString());
                            userInfo.put("Email", txtEmailtrein.getText().toString());
                            userInfo.put("Password", txtPassTre.getText().toString());
                            userInfo.put("Telemovel", txtContactoTelTrein.getText().toString());
                            userInfo.put("Data Nascimento", txtdataNAscTre.getText().toString());
                            userInfo.put("Morada", txtMoardaTrein.getText().toString());
                            userInfo.put("Cartão Cidadão", txtNccTrein.getText().toString());
                            userInfo.put("Genero", txtGeneroTrein.getText().toString());
                            userInfo.put("IBAN", txtIbanTrin.getText().toString());

                            userInfo.put("isTreinador", "1");
                            userInfo.put("IdEquipa", global);
                            df.set(userInfo);

                            startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(RegistoTreinador.this, "Failed to create", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        });*/
    }

    public void atualizarBD(){
        DocumentReference documentReference = fStore.collection("Equipas").document("jA2TAwtdjbQuFTudid1d");
        documentReference.update("IdEquipa", FieldValue.increment(1));
    }

    public void gg(){
        if(idProxEquipa>numEquipas){
            atualizarBD();
            DocumentReference jj = fStore.collection("Equipas").document("jA2TAwtdjbQuFTudid1d");
            jj.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                @Override
                public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                    String hh = Long.toString(documentSnapshot.getLong("IdEquipa"));
                    global= global.copyValueOf(hh.toCharArray());

                    checkField(txtNometre);
                    checkField(txtUsernameTrei);
                    checkField(txtEmailtrein);
                    checkField(txtContactoTelTrein);
                    checkField(txtdataNAscTre);
                    checkField(txtMoardaTrein);
                    checkField(txtNccTrein);
                    checkField(txtIbanTrin);
                    checkField(txtPassTre);
                    checkField(txtGeneroTrein);

                    if (valid) {
                        fAuth.createUserWithEmailAndPassword(txtEmailtrein.getText().toString(), txtPassTre.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {

                                user = fAuth.getCurrentUser();
                                Toast.makeText(RegistoTreinador.this, "Account created", Toast.LENGTH_SHORT).show();
                                DocumentReference df = fStore.collection("Users").document(user.getUid());
                                Map<String, Object> userInfo = new HashMap<>();
                                userInfo.put("Nome", txtNometre.getText().toString());
                                userInfo.put("Username", txtUsernameTrei.getText().toString());
                                userInfo.put("Email", txtEmailtrein.getText().toString());
                                userInfo.put("Password", txtPassTre.getText().toString());
                                userInfo.put("Telemovel", txtContactoTelTrein.getText().toString());
                                userInfo.put("Data Nascimento", txtdataNAscTre.getText().toString());
                                userInfo.put("Morada", txtMoardaTrein.getText().toString());
                                userInfo.put("Cartão Cidadão", txtNccTrein.getText().toString());
                                userInfo.put("Genero", txtGeneroTrein.getText().toString());
                                userInfo.put("IBAN", txtIbanTrin.getText().toString());

                                userInfo.put("isTreinador", "1");
                                userInfo.put("IdEquipa", global);
                                df.set(userInfo);

                                startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                                finish();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(RegistoTreinador.this, "Failed to create", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            });
        }else{
            checkField(txtNometre);
            checkField(txtUsernameTrei);
            checkField(txtEmailtrein);
            checkField(txtContactoTelTrein);
            checkField(txtdataNAscTre);
            checkField(txtMoardaTrein);
            checkField(txtNccTrein);
            checkField(txtIbanTrin);
            checkField(txtPassTre);
            checkField(txtGeneroTrein);

            if (valid) {
                fAuth.createUserWithEmailAndPassword(txtEmailtrein.getText().toString(), txtPassTre.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {

                        user = fAuth.getCurrentUser();
                        Toast.makeText(RegistoTreinador.this, "Account created", Toast.LENGTH_SHORT).show();
                        DocumentReference df = fStore.collection("Users").document(user.getUid());
                        Map<String, Object> userInfo = new HashMap<>();
                        userInfo.put("Nome", txtNometre.getText().toString());
                        userInfo.put("Username", txtUsernameTrei.getText().toString());
                        userInfo.put("Email", txtEmailtrein.getText().toString());
                        userInfo.put("Password", txtPassTre.getText().toString());
                        userInfo.put("Telemovel", txtContactoTelTrein.getText().toString());
                        userInfo.put("Data Nascimento", txtdataNAscTre.getText().toString());
                        userInfo.put("Morada", txtMoardaTrein.getText().toString());
                        userInfo.put("Cartão Cidadão", txtNccTrein.getText().toString());
                        userInfo.put("Genero", txtGeneroTrein.getText().toString());
                        userInfo.put("IBAN", txtIbanTrin.getText().toString());

                        System.out.println("Inserir BD: Há "+ numEquipas +" Equipas");
                        System.out.println("Inserir BD: Vai ser atribuída a equipa: "+ idProxEquipa);

                        userInfo.put("isTreinador", "1");
                        userInfo.put("IdEquipa", String.valueOf(idProxEquipa));
                        df.set(userInfo);

                        startActivity(new Intent(getApplicationContext(), ListaTreinadores.class));
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(RegistoTreinador.this, "Failed to create", Toast.LENGTH_SHORT).show();
                    }
                });
            }

        }

    }


    public boolean checkField(EditText textField) {
        if (textField.getText().toString().isEmpty()) {
            textField.setError("Error");
            valid = false;
        } else {
            valid = true;
        }

        return valid;
    }
}
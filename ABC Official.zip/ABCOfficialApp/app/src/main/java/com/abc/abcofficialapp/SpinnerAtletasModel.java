package com.abc.abcofficialapp;

public class SpinnerAtletasModel {

    private String Nome;

    public SpinnerAtletasModel(String nome) {
        this.Nome = Nome;
    }
    public SpinnerAtletasModel(){}

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        this.Nome = Nome;
    }
}

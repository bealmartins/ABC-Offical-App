package com.abc.abcofficialapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Map;

public class TerminarAnalise extends AppCompatActivity {

    Button confirmar;
    EditText equipaABC, equipaAdv;
    String id_jogo;
    int golosmarcados ;
    int golosSofridos;

    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terminar_analise);
       db = FirebaseFirestore.getInstance();
        id_jogo = (String) getIntent().getSerializableExtra("JogoID");

        confirmar = findViewById(R.id.button2);
        confirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                atualizar(golosSofridos, golosmarcados);
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });

        equipaABC = findViewById(R.id.editTextNumberSigned);
        equipaAdv = findViewById(R.id.editTextNumberS);

        somarGolosMarcados(id_jogo);
        somarGolosSofridos(id_jogo);


    }

    public void atualizar(int resultadoAdv, int resultadoABC){


        System.out.println(resultadoABC + resultadoAdv);
        if(resultadoABC > resultadoAdv){

            db.collection("Jogos").document(id_jogo).update("isVictory", "1");
            db.collection("Jogos").document(id_jogo).update("isDefeat", "0");
            db.collection("Jogos").document(id_jogo).update("isDraw", "0");
        } else {
            if(resultadoABC == resultadoAdv){
                db.collection("Jogos").document(id_jogo).update("isVictory", "0");
                db.collection("Jogos").document(id_jogo).update("isDefeat", "0");
                db.collection("Jogos").document(id_jogo).update("isDraw", "1");
            } else {
                db.collection("Jogos").document(id_jogo).update("isVictory", "0");
                db.collection("Jogos").document(id_jogo).update("isDefeat", "1");
                db.collection("Jogos").document(id_jogo).update("isDraw", "0");
            }
        }
    }

    public void somarGolosMarcados(String idjogo){

        db.collection("Estatísticas").whereEqualTo("idJogo", idjogo).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if ( task.isSuccessful()){
                  int numGolos= 0;
                    for (QueryDocumentSnapshot document : task.getResult()) {

                        if (document.exists()) {

                            Map<String, Object> estatistica = document.getData();
if (estatistica.containsKey("6metros")) {
    numGolos += Integer.parseInt(estatistica.get("6metros").toString()) + Integer.parseInt(estatistica.get("7metros").toString()) + Integer.parseInt(estatistica.get("9metros").toString()) + Integer.parseInt(estatistica.get("contraAtaque").toString());
}


                }
            }
                    equipaABC.setText(String.valueOf(numGolos));
                    System.out.println(numGolos);
                    golosmarcados = numGolos;
        }
    }
} );

        }


    public void somarGolosSofridos(String idjogo){

        //String idjogo = "T88vAb1wkyG0w9uhrjYU";        //receber de tras;

        db.collection("Estatísticas").whereEqualTo("idJogo", idjogo).get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if ( task.isSuccessful()){
                    int numGolos= 0;
                    for (QueryDocumentSnapshot document : task.getResult()) {

                        if (document.exists()) {

                            Map<String, Object> estatistica = document.getData();
                            if (estatistica.containsKey("2cantoSupEsq")) {
                                numGolos += Integer.parseInt(estatistica.get("2cantoSupEsq").toString()) + Integer.parseInt(estatistica.get("2centroSup").toString()) + Integer.parseInt(estatistica.get("2cantoSupDir").toString()) + Integer.parseInt(estatistica.get("2centroEsq").toString())
                                        + Integer.parseInt(estatistica.get("2centro").toString()) + Integer.parseInt(estatistica.get("2centroDir").toString()) + Integer.parseInt(estatistica.get("2cantoInfEsq").toString()) + Integer.parseInt(estatistica.get("2centroInf").toString()) + Integer.parseInt(estatistica.get("2cantoInfDir").toString());
                                ;

                            }
                        }
                    }
                    equipaAdv.setText(String.valueOf(numGolos));
                    golosSofridos = numGolos;

                }
            }
        } );

    }


}
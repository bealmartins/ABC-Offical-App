package com.abc.abcofficialapp;

import com.google.firebase.firestore.Exclude;

import java.io.Serializable;

public class TreinoModel implements Serializable {
    @Exclude
    private String id;
    private String Data;
    private String Hora;
    private String Local;


    public TreinoModel(){}

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getLocal() {
        return Local;
    }

    public void setLocal(String local) {
        Local = local;
    }

    public TreinoModel(String Data){
        this.Data=Data;
    }

    public String getData() {
        return Data;
    }

    public void setData(String data) {
        Data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}

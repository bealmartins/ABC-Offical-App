package com.abc.abcofficialapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class Treinos extends AppCompatActivity {

    RecyclerView recyclerView33;
    ArrayList<TreinoModel> listatreinos;
    MyAdapterTreinos myadaptertreinos;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    ProgressDialog progressDialog;
    String uid;

    Button buttonMarcarTreino2;
    //ImageButton imageButton86, imageButton87, imageButton88, imageButton89, imageButton90;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treinos);

        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();
        fStore = FirebaseFirestore.getInstance();

        buttonMarcarTreino2 = findViewById(R.id.buttonMarcarTreino2);
        ImageButton imageButton86 = (ImageButton) this.findViewById(R.id.imageButton86);
        ImageButton  imageButton87 = (ImageButton) this.findViewById(R.id.imageButton87);
        ImageButton  imageButton88 = (ImageButton) this.findViewById(R.id.imageButton88);
        ImageButton  imageButton89 = (ImageButton) this.findViewById(R.id.imageButton89);
        ImageButton imageButton90 = (ImageButton) this.findViewById(R.id.imageButton90);

        buttonMarcarTreino2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MarcarTreinos.class));
                finish();
            }
        });

        imageButton86.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton87.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton88.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton89.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton90.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Procurando Dados!!....");
        progressDialog.show();


        recyclerView33 = findViewById(R.id.recyclerView33);
        recyclerView33.setHasFixedSize(true);
        recyclerView33.setLayoutManager(new LinearLayoutManager(this));
        fStore = FirebaseFirestore.getInstance();

        listatreinos = new ArrayList<TreinoModel>();
        myadaptertreinos = new MyAdapterTreinos(this,listatreinos);

        recyclerView33.setAdapter(myadaptertreinos);

        fStore.collection("Treinos").whereEqualTo("IdTreinador", uid).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for(DocumentSnapshot d : list){
                        TreinoModel p = d.toObject(TreinoModel.class);
                        p.setId(d.getId());
                        listatreinos.add(p);
                    }
                    myadaptertreinos.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }

            }
        });

    }
}
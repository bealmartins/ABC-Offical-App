package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class VerJogos_at extends AppCompatActivity {

    RecyclerView recyclerView55;
    ArrayList<Jogo> jogoArrayList;
    AdapterJogo adapterJogo;
    FirebaseFirestore db;
    FirebaseAuth fAuth;
    ProgressDialog progressDialog;
    String uid;
    private String global;


    ImageButton imageButton91, imageButton92, imageButton93, imageButton94, imageButton95;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_jogos_at);
        fAuth = FirebaseAuth.getInstance();
        uid= fAuth.getCurrentUser().getUid();
        db = FirebaseFirestore.getInstance();

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Fetching data...");
        progressDialog.show();

        recyclerView55 = findViewById(R.id.recyclerView55);
        recyclerView55.setHasFixedSize(true);
        recyclerView55.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();
        jogoArrayList = new ArrayList<Jogo>();
        adapterJogo = new AdapterJogo(VerJogos_at.this, jogoArrayList);

        recyclerView55.setAdapter(adapterJogo);

        imageButton91 = findViewById(R.id.imageButton91);
        imageButton92 = findViewById(R.id.imageButton92);
        imageButton93 = findViewById(R.id.imageButton93);
        imageButton94 = findViewById(R.id.imageButton94);
        imageButton95 = findViewById(R.id.imageButton95);



        DocumentReference dc = db.collection("Users").document(uid);
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                String jj = documentSnapshot.getString("IdEquipa");
                global = global.copyValueOf(jj.toCharArray());
                EventChangeListener(global);
            }
        });

        imageButton95.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), verTreinos_at.class));
                finish();
            }
        });

        imageButton91.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAtleta.class));
                finish();
            }
        });

        imageButton92.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilAtleta1.class));
                finish();
            }
        });

        imageButton93.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), relatorioAtleta_at.class));
                finish();
            }
        });

        imageButton94.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), VerJogos_at.class));
                finish();
            }
        });
    }

    private void EventChangeListener(String eq) {

        db.collection("Jogos").whereEqualTo("IdEquipa", eq).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for(DocumentSnapshot d : list){
                        Jogo  p = d.toObject(Jogo.class);
                        p.setId_jogo(d.getId());
                        jogoArrayList.add(p);
                    }
                    adapterJogo.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }

            }
        });
    }
}
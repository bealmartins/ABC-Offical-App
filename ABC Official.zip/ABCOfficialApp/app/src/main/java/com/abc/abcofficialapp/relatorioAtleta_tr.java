package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class relatorioAtleta_tr extends AppCompatActivity {

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String uid;
    private TreinAtletaModel treinAtletaModel;

    Button buttonRelGuardar,button59;
    EditText txtRelaGolosMarcados,txtRelGolosSofridos,txtRelRemates,txtRelFaltasCometidas,
            txtRelatorioFaltasSofridas,txtRelDefesas,editTextTextMultiLine;
    ImageButton imageButton76, imageButton77, imageButton78, imageButton79, imageButton80;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relatorio_atleta_tr);

        treinAtletaModel = (TreinAtletaModel) getIntent().getSerializableExtra("rel");
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        uid = fAuth.getCurrentUser().getUid();

        button59= findViewById(R.id.button59);
        buttonRelGuardar = findViewById(R.id.buttonRelGuardar);
        txtRelaGolosMarcados = findViewById(R.id.txtRelaGolosMarcados);
        txtRelGolosSofridos = findViewById(R.id.txtRelGolosSofridos);
        txtRelRemates = findViewById(R.id.txtRelRemates);
        txtRelFaltasCometidas = findViewById(R.id.txtRelFaltasCometidas);
        txtRelatorioFaltasSofridas = findViewById(R.id.txtRelatorioFaltasSofridas);
        txtRelDefesas = findViewById(R.id.txtRelDefesas);
        editTextTextMultiLine = findViewById(R.id.editTextTextMultiLine);

        imageButton76 = findViewById(R.id.imageButton76);
        imageButton77 = findViewById(R.id.imageButton77);
        imageButton78 = findViewById(R.id.imageButton78);
        imageButton79 = findViewById(R.id.imageButton79);
        imageButton80 = findViewById(R.id.imageButton80);

        button59.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(relatorioAtleta_tr.this,ListaAtletas.class));
                finish();
            }
        });

        DocumentReference dc = fStore.collection("Users").document(treinAtletaModel.getId());
        dc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                txtRelaGolosMarcados.setText(documentSnapshot.getString("Golos Marcados"));
                txtRelGolosSofridos.setText(documentSnapshot.getString("Golos Sofridos"));
                txtRelRemates.setText(documentSnapshot.getString("Remates"));
                txtRelFaltasCometidas.setText(documentSnapshot.getString("Faltas Cometidas"));
                txtRelatorioFaltasSofridas.setText(documentSnapshot.getString("Faltas Sofridas"));
                txtRelDefesas.setText(documentSnapshot.getString("Defesas"));
                editTextTextMultiLine.setText(documentSnapshot.getString("Relatorio"));
            }
        });

        buttonRelGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String golosMarcados = txtRelaGolosMarcados.getText().toString();
                String golosSofridos = txtRelGolosSofridos.getText().toString();
                String Remates = txtRelRemates.getText().toString();
                String FaltasCometidas = txtRelFaltasCometidas.getText().toString();
                String FaltasSofridas = txtRelatorioFaltasSofridas.getText().toString();
                String Defesas = txtRelDefesas.getText().toString();
                String Relatorio = editTextTextMultiLine.getText().toString();

                if(!hasValidationErrors((golosMarcados)) && !hasValidationErrors((golosSofridos)) && !hasValidationErrors((Remates)) && !hasValidationErrors((FaltasCometidas)) && !hasValidationErrors((Defesas)) && !hasValidationErrors((FaltasSofridas))) {
                    DocumentReference dd = fStore.collection("Users").document(treinAtletaModel.getId());
                    dd.update("Relatorio", Relatorio);
                    dd.update("GolosM", golosMarcados);
                    dd.update("GolosS", golosSofridos);
                    dd.update("Remates", Remates);
                    dd.update("FaltasC", FaltasCometidas);
                    dd.update("FaltasS", FaltasSofridas);
                    dd.update("Defesas", Defesas);
                    Toast.makeText(relatorioAtleta_tr.this, "Relatorio Submetido!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(relatorioAtleta_tr.this,ListaAtletas.class));
                    finish();
                }
            }

        });

        imageButton76.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuTreinador.class));
                finish();
            }
        });
        imageButton77.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilTreinador1.class));
                finish();
            }
        });

        imageButton78.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Treinos.class));
                finish();
            }
        });

        imageButton79.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Jogos.class));
                finish();
            }
        });

        imageButton80.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ListaAtletas.class));
                finish();
            }
        });
    }


    private boolean hasValidationErrors(String d) {
        if (d.isEmpty()) {
            Toast.makeText(relatorioAtleta_tr.this,"Preencha todos os campos!!", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }
}
package com.abc.abcofficialapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class verTreinos_at extends AppCompatActivity {

    RecyclerView recyclerView44;
    ArrayList<TreinoModel> listatreinos;
    MyAdapterTreinos myadaptertreinos;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    ProgressDialog progressDialog;
    String idequipa;
    String idtrein;

    ImageButton imageButton96, imageButton97, imageButton98,imageButton99, imageButton100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_treinos_at);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        imageButton96 = findViewById(R.id.imageButton96);
        imageButton97 = findViewById(R.id.imageButton97);
        imageButton98 = findViewById(R.id.imageButton98);
        imageButton99 = findViewById(R.id.imageButton99);
        imageButton100 = findViewById(R.id.imageButton100);


        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Procurando Dados!!....");
        progressDialog.show();


        recyclerView44 = findViewById(R.id.recyclerView44);
        recyclerView44.setHasFixedSize(true);
        recyclerView44.setLayoutManager(new LinearLayoutManager(this));
        fStore = FirebaseFirestore.getInstance();

        listatreinos = new ArrayList<TreinoModel>();
        myadaptertreinos = new MyAdapterTreinos(this,listatreinos);

        recyclerView44.setAdapter(myadaptertreinos);


        DocumentReference ds =fStore.collection("Users").document(fAuth.getCurrentUser().getUid());
        ds.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                String dd = value.getString("IdEquipa");
                idequipa = idequipa.copyValueOf(dd.toCharArray());
                idreinador(idequipa);
            }
        });


        imageButton96.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MenuAtleta.class));
                finish();
            }
        });

        imageButton97.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), PerfilAtleta1.class));
                finish();
            }
        });

        imageButton98.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), relatorioAtleta_at.class));
                finish();
            }
        });
        imageButton99.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), VerJogos_at.class));
                finish();
            }
        });
        imageButton100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), verTreinos_at.class));
                finish();
            }
        });
    }

    public void idreinador(String id){
        Task<QuerySnapshot> dd= fStore.collection("Users").whereEqualTo("isTreinador","1").whereEqualTo("IdEquipa", id).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                    idtrein = idtrein.copyValueOf(list.get(0).getId().toCharArray());
                    idr(idtrein);
                }
            }
        });
    }

    public void idr(String id){
        fStore.collection("Treinos").whereEqualTo("IdTreinador", id).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                if(!queryDocumentSnapshots.isEmpty()){
                    List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();

                    for(DocumentSnapshot d : list){
                        TreinoModel p = d.toObject(TreinoModel.class);
                        p.setId(d.getId());
                        listatreinos.add(p);
                    }
                    myadaptertreinos.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }

            }
        });

    }
}